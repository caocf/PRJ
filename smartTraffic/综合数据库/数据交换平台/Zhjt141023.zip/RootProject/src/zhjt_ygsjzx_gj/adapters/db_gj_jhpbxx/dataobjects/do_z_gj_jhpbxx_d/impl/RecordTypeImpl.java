package zhjt_ygsjzx_gj.adapters.db_gj_jhpbxx.dataobjects.do_z_gj_jhpbxx_d.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_jhpbxx.dataobjects.do_z_gj_jhpbxx_d.RecordType {
  private java.math.BigDecimal _bH;


  public java.math.BigDecimal getBH() {
    return _bH;
  }

  public void setBH(java.math.BigDecimal pBH) {
    _bH = pBH;
  }

}
