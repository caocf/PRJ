/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.outbound.ao_z_gj_zdjbxx_iu;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import com.tongtech.ti.adapter.jdbc.util.midprocess.LobCreator;
import com.tongtech.ti.adapter.jdbc.util.midprocess.OracleLobHandler;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterBase;

/**
 * ���³�վ�������Ĺ�����
 */
public class AOZ_gj_zdjbxx_iuBase extends JdbcAdapterBase {

	SimpleDateFormat sdf = null;

	/**
	 * ���ݶ��󹤳�
	 */
	protected static zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.ObjectFactory z_gj_zdjbxx_doZGjZdjbxxIu_doOF = null;

	/**
	 * ���ʼ��ʱ�������ݶ��󹤳���ʵ��
	 */
	static {
		try {
			z_gj_zdjbxx_doZGjZdjbxxIu_doOF = new zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.ObjectFactory();
		} catch(Exception e) {
			classLogger.error("�������ݶ��󹤳�ʧ��",e);
		}
	}

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 */
	public AOZ_gj_zdjbxx_iuBase(InterfaceComponent ic) {
		super(ic);
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 * @param aoname, ���������������
	 */
	public AOZ_gj_zdjbxx_iuBase(InterfaceComponent ic, String aoname) {
		super(ic, aoname);
		
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public boolean z_gj_zdjbxx(zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.DoZGjZdjbxxIu doZGjZdjbxxIu ) {
		String sqlStr = "update ZHJTADMIN.\"Z_GJ_ZDJBXX\" set \"ZDBH\"=?,\"ZDMC\"=?,\"ZDBM\"=?,\"ZDJD\"=?,\"ZDWD\"=?,\"ZDLX\"=?,\"FWJ\"=?,\"ZDEWM\"=?,\"BZ\"=?,\"GS\"=?,\"QY\"=?,\"GYZT\"=? where  (\"ZDBH\" = ?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("update SQL : " + sqlStr);
		String sqlInsert = "insert into ZHJTADMIN.\"Z_GJ_ZDJBXX\"(\"ZDBH\",\"ZDMC\",\"ZDBM\",\"ZDJD\",\"ZDWD\",\"ZDLX\",\"FWJ\",\"ZDEWM\",\"BZ\",\"GS\",\"QY\",\"GYZT\") values(?,?,?,?,?,?,?,?,?,?,?,?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("INSERT FOR UPDATE SQL : " + sqlInsert);
		zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.Record record = null;
		int idx=0;
		int paramIdx = 1;
		PreparedStatement pstmt = null;
		PreparedStatement pcyclestmt = null;			
		try {
			pstmt = conn.prepareStatement(sqlStr);
			for (Iterator iter = doZGjZdjbxxIu.getRecord().iterator(); iter.hasNext();) {
				record = (zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.Record)iter.next();
		
				pstmt.clearParameters();	
		paramIdx = 1;

		pstmt.setBigDecimal(paramIdx++,record.getZDBH());
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZDMC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZDBM(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJD(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getWD(),fromCharSet,toCharSet));			
		pstmt.setBigDecimal(paramIdx++,record.getZDLX());
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getFWJ(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZDEWM(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getBZ(),fromCharSet,toCharSet));			
		pstmt.setBigDecimal(paramIdx++,record.getGS());
		pstmt.setBigDecimal(paramIdx++,record.getQY());
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getGYZT(),fromCharSet,toCharSet));			
		pstmt.setBigDecimal(paramIdx++,record.getZDBH());
				int rst = -1;
				int n = 0;
				java.sql.SQLException sqlException = null;
				while (n<maxDeadlockRetry) {
					try {
						rst = pstmt.executeUpdate();
						break;
					} catch (java.sql.SQLException sqle){
						if (isCanRetry(sqle)){
							n++;
							try	{
								ic.getLogger().warn(sqle);
								ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
								Thread.sleep(deadlockRetryDelay);
							} catch (Exception ex) {
							} 
						} else {
							ic.getLogger().error("ִ��SQL���["+sqlStr+"]����",sqle);
							throw sqle;
						}
					}
				}
				if (n== maxDeadlockRetry) {
					ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
					throw sqlException;
				}	
				
				if (rst==0) {
					PreparedStatement pstmtIns = null;
					try {
					pstmtIns = conn.prepareStatement(sqlInsert);
		paramIdx = 1;

		pstmtIns.setBigDecimal(paramIdx++,record.getZDBH());
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZDMC(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZDBM(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJD(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getWD(),fromCharSet,toCharSet));			
		pstmtIns.setBigDecimal(paramIdx++,record.getZDLX());
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getFWJ(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZDEWM(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getBZ(),fromCharSet,toCharSet));			
		pstmtIns.setBigDecimal(paramIdx++,record.getGS());
		pstmtIns.setBigDecimal(paramIdx++,record.getQY());
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getGYZT(),fromCharSet,toCharSet));			
					
					n = 0;
					while (n<maxDeadlockRetry) {
						try {
							pstmtIns.execute();
							break;
						} catch (java.sql.SQLException sqle) {
							sqlException = sqle;
							if (isCanRetry(sqle)) {
								n++;
								try	{
									ic.getLogger().warn(sqle);
									ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
									Thread.sleep(deadlockRetryDelay);
								} catch (Exception ex) {
								} 
							} else {
								ic.getLogger().warn("ִ��SQL���["+sqlInsert+"]����",sqle);
								throw sqle;
							}
						}
					}
					if (n == maxDeadlockRetry) {
						ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
						throw sqlException;
					}	
					} finally {
						if (pstmtIns!=null){
							try {
								pstmtIns.close();
							} catch (Exception e){
								ic.getLogger().warn("Close PreparedStatement[pstmtIns] error",e);
				}
						}
					}
				}
				
				
				idx++;
			}
			
			return true;//�ɹ�����true
		} catch (Exception e) {
			//ic.getLogger().error(e.getMessage(),e);
			this.faultMsg = e.toString()+";SQL:"+sqlStr+";ErrorData: "+Do2String(record);
			this.faultMsg = this.faultMsg.replaceAll("\n", "");

			boolean isAutoCommit = false;
			zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.DoZGjZdjbxxIu errorDO = null ;
			try {
				if (isStopProcessOnException(e)) {
					isAutoCommit = conn.getAutoCommit();
					if (isAutoCommit) {
						int count=0;
						errorDO = z_gj_zdjbxx_doZGjZdjbxxIu_doOF.createDoZGjZdjbxxIu();
						for (java.util.Iterator iter = doZGjZdjbxxIu.getRecord().iterator(); iter.hasNext();) {
							zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.Record rec = (zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.Record)iter.next();
							if (count>=idx) {
								List records = errorDO.getRecord();
								if (records==null) records = new ArrayList();
								records.add(rec);
							}
							count++;
						}
						
						com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"doZGjZdjbxxIu",ic,e);
						this.faultCode = -3;
						return false;//ʧ�ܣ��Զ��ύ��ֹͣ����
					} else {
						if (isRollbackOnException()) {
							this.faultCode = -2;
							return false;//ʧ�ܣ��ع���ֹͣ����
						} else {
							int count=0;
							errorDO = z_gj_zdjbxx_doZGjZdjbxxIu_doOF.createDoZGjZdjbxxIu();
							for (java.util.Iterator iter = doZGjZdjbxxIu.getRecord().iterator(); iter.hasNext();) {
								zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.Record rec = (zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.Record)iter.next();
								if (count>=idx) {
									List records = errorDO.getRecord();
									if (records==null) records = new ArrayList();
									records.add(rec);
								}
								count++;
							}
							com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"doZGjZdjbxxIu",ic,e);
							this.faultCode = -3;
							return false;//ʧ�ܣ����ع���ֹͣ����
						}
						//errorDO = doZGjZdjbxxIu;
					}
				} else {//���ǿ�ֹͣ�ķ���-1
					this.faultCode = -1;
					return false;
				}
			} catch(Exception e1) {
				ic.getLogger().error(e1.getMessage(),e1);
				this.faultCode = -1;
				return false;
			}
		} finally {
			if (pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					ic.getLogger().error("close pstmt error.",e);
				}
			}
				}
	} 
	
	
}
