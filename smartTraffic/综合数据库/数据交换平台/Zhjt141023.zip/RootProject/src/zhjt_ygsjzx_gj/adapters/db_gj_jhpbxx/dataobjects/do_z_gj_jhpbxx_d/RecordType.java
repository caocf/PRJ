package zhjt_ygsjzx_gj.adapters.db_gj_jhpbxx.dataobjects.do_z_gj_jhpbxx_d;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getBH();

  public void setBH(java.math.BigDecimal pBH);

}
