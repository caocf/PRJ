package zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.impl;

public class DoZGjXlzxbDTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.DoZGjXlzxbDType {
  private java.util.List _record = new java.util.ArrayList();


  public java.util.List getRecord() {
    return _record;
  }

  public int getRecordCount() {
      return _record.size();
  }

  public zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record[] getRecordAsArray() {
    java.util.List list = getRecord();
    int size = list.size();
    zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record[] valuesInArray = new zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record[size];
    for (int index = 0; index < size; index++) {
          valuesInArray[index] = (zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record)list.get(index);
      }
      return valuesInArray;
  }

  public zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException {
    java.util.List list = getRecord(); // check bounds for index
    if ((index < 0) || (index >= list.size())) {
    	throw new IndexOutOfBoundsException("getRecord: Index value '"+index+"' not in range [0.."+(list.size() - 1) + "]");
    }
    return (zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record)list.get(index);
  }

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record[] valuesInArray) {
    java.util.List list = getRecord();
    list.clear();
    if(valuesInArray == null) {
    	  return;
    }
    //-- copy array
    for (int i = 0; i < valuesInArray.length; i++) {
    	list.add(valuesInArray[i]);
    }
  }

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record value, int index) throws java.lang.IndexOutOfBoundsException {
    java.util.List list = getRecord();
    //-- check bounds for index
    if ((index < 0) || (index >= list.size())) {
    	throw new IndexOutOfBoundsException("getRecord: Index value '"+index+"' not in range [0.."+(list.size() - 1) + "]");
    }
    list.set(index, value);
  }

  public void addRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.Record value) {
    java.util.List list = getRecord();
    list.add(value);
  }

}
