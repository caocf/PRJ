package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu.RecordType {
  private java.math.BigDecimal _bH;

  private java.lang.String _cPH;

  private java.math.BigDecimal _cPYS;

  private java.math.BigDecimal _xLBH;

  private java.math.BigDecimal _fX;

  private java.math.BigDecimal _rQ;

  private java.util.Calendar _fCSJ;

  private java.util.Calendar _dZSJ;

  private java.math.BigDecimal _jHBH;


  public java.math.BigDecimal getBH() {
    return _bH;
  }

  public void setBH(java.math.BigDecimal pBH) {
    _bH = pBH;
  }

  public java.lang.String getCPH() {
    return _cPH;
  }

  public void setCPH(java.lang.String pCPH) {
    _cPH = pCPH;
  }

  public java.math.BigDecimal getCPYS() {
    return _cPYS;
  }

  public void setCPYS(java.math.BigDecimal pCPYS) {
    _cPYS = pCPYS;
  }

  public java.math.BigDecimal getXLBH() {
    return _xLBH;
  }

  public void setXLBH(java.math.BigDecimal pXLBH) {
    _xLBH = pXLBH;
  }

  public java.math.BigDecimal getFX() {
    return _fX;
  }

  public void setFX(java.math.BigDecimal pFX) {
    _fX = pFX;
  }

  public java.math.BigDecimal getRQ() {
    return _rQ;
  }

  public void setRQ(java.math.BigDecimal pRQ) {
    _rQ = pRQ;
  }

  public java.util.Calendar getFCSJ() {
    return _fCSJ;
  }

  public void setFCSJ(java.util.Calendar pFCSJ) {
    _fCSJ = pFCSJ;
  }

  public java.util.Calendar getDZSJ() {
    return _dZSJ;
  }

  public void setDZSJ(java.util.Calendar pDZSJ) {
    _dZSJ = pDZSJ;
  }

  public java.math.BigDecimal getJHBH() {
    return _jHBH;
  }

  public void setJHBH(java.math.BigDecimal pJHBH) {
    _jHBH = pJHBH;
  }

}
