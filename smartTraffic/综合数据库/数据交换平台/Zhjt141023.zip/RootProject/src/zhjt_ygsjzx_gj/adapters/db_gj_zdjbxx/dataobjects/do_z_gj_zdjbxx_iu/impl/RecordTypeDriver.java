package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.RecordType _1 = (zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.RecordType) pObject;
    java.math.BigDecimal _2 = _1.getZDBH();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "ZDBH", pController.getDatatypeConverter().printDecimal(_1.getZDBH()));
    }
    java.lang.String _3 = _1.getZDMC();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "ZDMC", _1.getZDMC());
    }
    java.lang.String _4 = _1.getZDBM();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "ZDBM", _1.getZDBM());
    }
    java.math.BigDecimal _5 = _1.getZDLX();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "ZDLX", pController.getDatatypeConverter().printDecimal(_1.getZDLX()));
    }
    java.lang.String _6 = _1.getFWJ();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "FWJ", _1.getFWJ());
    }
    java.lang.String _7 = _1.getZDEWM();
    if (_7 != null) {
      pController.marshalSimpleChild(this, "", "ZDEWM", _1.getZDEWM());
    }
    java.lang.String _8 = _1.getBZ();
    if (_8 != null) {
      pController.marshalSimpleChild(this, "", "BZ", _1.getBZ());
    }
    java.math.BigDecimal _9 = _1.getGS();
    if (_9 != null) {
      pController.marshalSimpleChild(this, "", "GS", pController.getDatatypeConverter().printDecimal(_1.getGS()));
    }
    java.math.BigDecimal _10 = _1.getQY();
    if (_10 != null) {
      pController.marshalSimpleChild(this, "", "QY", pController.getDatatypeConverter().printDecimal(_1.getQY()));
    }
    java.lang.String _11 = _1.getGYZT();
    if (_11 != null) {
      pController.marshalSimpleChild(this, "", "GYZT", _1.getGYZT());
    }
    java.lang.String _12 = _1.getJD();
    if (_12 != null) {
      pController.marshalSimpleChild(this, "", "JD", _1.getJD());
    }
    java.lang.String _13 = _1.getWD();
    if (_13 != null) {
      pController.marshalSimpleChild(this, "", "WD", _1.getWD());
    }
  }

}
