/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt_ygsjzx_gj.adapters.db_gj_jhpbxx.outbound.out_gj_jhpbxx_d;

import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.sql.Connection;
import javax.naming.NamingException;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterService;

import com.tongtech.ti.management.jms.AlertConstants;

/**
 * ���³�վ����������
 */
public class Out_gj_jhpbxx_d extends JdbcAdapterService{

	/**
	 * ���캯��
	 * 
	 * @param ic,
	 */
	public Out_gj_jhpbxx_d(InterfaceComponent ic) {
		super(ic);
	}
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public int gj_jhpbxx(zhjt_ygsjzx_gj.adapters.db_gj_jhpbxx.dataobjects.do_z_gj_jhpbxx_d.DoZGjJhpbxxD doZGjJhpbxxD,default_project.adaptors.database.dataobjects.opresult.OPResultDO oPResultDO,default_project.adaptors.database.dataobjects.dbfault.DBFaultDO dBFaultDO) throws java.lang.Exception{
	
		zhjt_ygsjzx_gj.adapters.db_gj_jhpbxx.outbound.out_gj_jhpbxx_d.Out_gj_jhpbxx_dBase base = null;
		
		try {
		
			startProcessInfo("gj_jhpbxx", "delete", "gj_jhpbxx", doZGjJhpbxxD);
			
			base = new zhjt_ygsjzx_gj.adapters.db_gj_jhpbxx.outbound.out_gj_jhpbxx_d.Out_gj_jhpbxx_dBase(ic);
			base.init();
			base.connect();
			   base.setAutoCommit(false);
			boolean baseResult = base.gj_jhpbxx(doZGjJhpbxxD);
			if (baseResult){
				base.commit();
				oPResultDO.setSuccess(true);
				
				endProcessInfo("gj_jhpbxx", "delete", "gj_jhpbxx", 0, 0, true);
				return 0;//�ɹ�
			} else {
				int errorCode = base.getFaultCode();
				base.rollback();
				oPResultDO.setSuccess(false);
				dBFaultDO.setFaultMessage(base.getFaultMsg());
				
				//endProcessInfo("gj_jhpbxx", "delete", "gj_jhpbxx", 0, 0, false);
				Exception exception = new Exception(base.getFaultMsg());
				errorProcessInfo("gj_jhpbxx", "delete", "gj_jhpbxx", exception);
				
				return errorCode;//ʧ��
			}
		} catch (Exception e) {
			//alert
			ic.alert(AlertConstants.ALERT_TYPE_ADAPTER_DB, AlertConstants.ALERT_LEVEL_CRITICAL, "���³�վ����ʧ��",e);
			
			ic.getLogger().error(e.getMessage(),e);
			oPResultDO.setSuccess(false);
			dBFaultDO.setFaultMessage(e.toString());
			ic.getLogger().error(e.getMessage(),e);
			
			errorProcessInfo("gj_jhpbxx", "delete", "gj_jhpbxx", e);
			
			return -1;//�쳣��ʧ�ܷ���-1
		} finally {
			try {
				base.closeConn();
			} catch (Exception e) {
				ic.getLogger().error(e.getMessage(),e);
			}
		}
	}
	
}
