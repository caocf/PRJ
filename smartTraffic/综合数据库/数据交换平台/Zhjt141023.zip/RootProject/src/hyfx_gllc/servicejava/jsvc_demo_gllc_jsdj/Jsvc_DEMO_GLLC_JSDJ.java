package hyfx_gllc.servicejava.jsvc_demo_gllc_jsdj;

import hyfx_gllc.adapters.excel_gllc.outbound.aoxls_gllc_jsdj.AOxls_gllc_jsdj;
import default_project.adaptors.file.outbound.fileadapterobject.FileAOParameter;
import default_project.adaptors.file.outbound.fileadapterobject.FileAdapterObject;
import com.tongtech.ti.javaservice.BaseService;
import hyfx_gllc.adapters.db_hyfxxt.outbound.ao_hyfxxt_demo_gllc_jsdj.AOHyfxxt_DEMO_GLLC_JSDJ;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import default_project.adaptors.file.dataobjects.nameinbound.FileNameInboundDO;
public class Jsvc_DEMO_GLLC_JSDJ extends BaseService{
	private InterfaceComponent ic = null;


	private void saveErrorData(default_project.adaptors.file.outbound.fileadapterobject.FileAdapterObject fileAO,
		String errorMsg, String errorData) throws Exception{
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String sDate = sdf.format(new java.util.Date());
		String errorContents = "ERROR TIME:" + sDate + "\r\nERROR MESSAGE: " + errorMsg + "\r\nERROR DATA:\r\n" + errorData + "\r\n";
		fileAO.connect();
		fileAO.writeText(null,null,errorContents);
		fileAO.disconnect();
	}
/*METHODS BEGIN*/
	public Jsvc_DEMO_GLLC_JSDJ(InterfaceComponent ic) {
		this.ic = ic;
	}
	public  int OnFileName(FileNameInboundDO filenameinbounddo,AOHyfxxt_DEMO_GLLC_JSDJ aohyfxxt_demo_gllc_jsdj,AOxls_gllc_jsdj aoxls_gllc_jsdj,FileAdapterObject fileadapterobject) {
		/*���ڴ��޸����ԣ�ȷ���������ɴ���ʱ�Ƿ񸲸�ԭ�д��룬�Ϸ�ֵΪtrue����false��CoverOldCode:false*/

		hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdj doQueryResult = null;
		String filename = null;
		com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject dbAO = aohyfxxt_demo_gllc_jsdj;
		try {
			filename = filenameinbounddo.getPath()+"/"+filenameinbounddo.getName();
			aoxls_gllc_jsdj.setFileName(filenameinbounddo.getPath(),filenameinbounddo.getTemFileName());
			//aoxls_gllc_jsdj.setSheetName("result");
			aoxls_gllc_jsdj.connectToDB();
			dbAO.connectToDB();
			try {
				dbAO.setAutoCommit(false);
				aoxls_gllc_jsdj.query();
				doQueryResult = aoxls_gllc_jsdj.nextQuery();
				while (doQueryResult!=null){
					boolean execResult  = dbAO.executeInsert("DEMO_GLLC_JSDJ",doQueryResult);
					if (!execResult){
						ic.getLogger().error("�������ݵ����ݿ����: " + dbAO.getFaultMsg());
						saveErrorData(fileadapterobject,dbAO.getFaultMsg(),doQueryResult.marshal2String());
						dbAO.rollback();
					} else {
						dbAO.commit();
					}
					doQueryResult = aoxls_gllc_jsdj.nextQuery();
				}
 
			} catch (Exception e) {
				dbAO.rollback();
				throw e;
			}
			aoxls_gllc_jsdj.closeConnection();
			return 0;
		} catch (Exception e) {
			ic.getLogger().error("��Excel�ļ�["+filename+"]�������ݿ����,",e);
			ic.alert("��Excel�ļ�["+filename+"]�������ݿ����",e);
			return -1;
		} finally {
			try {
				dbAO.setAutoCommit(true);
				dbAO.closeConnection();
			} catch(Exception e1){
				ic.getLogger().error("�ر����ݿ��վAO[aohyfxxt_demo_gllc_jsdj]����,",e1);
			}	
			try {
				aoxls_gllc_jsdj.closeQuery();
				aoxls_gllc_jsdj.closeConnection();
			} catch (Exception e1){
				ic.getLogger().error("�ر�Excel��ѯ��վ[aoxls_gllc_jsdj]����,",e1);
			}
		}

	}
/*METHODS END*/
}
