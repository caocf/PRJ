package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj;

public interface ExceldoGllcJsdjType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record[] getRecordAsArray();

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record[] valuesInArray);

  public void setRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record value);

}
