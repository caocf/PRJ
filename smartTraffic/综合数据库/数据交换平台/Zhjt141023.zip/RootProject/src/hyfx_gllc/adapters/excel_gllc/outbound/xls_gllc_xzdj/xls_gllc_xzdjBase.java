/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package hyfx_gllc.adapters.excel_gllc.outbound.xls_gllc_xzdj;

import com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet;
import com.tongtech.ti.adapter.jdbc.util.JdbcUtil;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.util.*;
import java.sql.*;
import com.tongtech.ti.adapter.excel.ColumnExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelColumn;
import com.tongtech.ti.adapter.excel.ExcelAdapterBase;
import com.tongtech.ti.adapter.excel.ExcelValueException;
/**
 * ��ѯ��վ�������Ĺ�����
 */
public class xls_gllc_xzdjBase extends ExcelAdapterBase{

	/**
	 * ��ý����
	 */
	private java.sql.ResultSet resultSet_Query= null;
	/**
	 * ���泬��BatchSize�ļ�¼�Ļ���
	 */
	private java.util.ArrayList BufQuery = new ArrayList();

	/**
	 * �����������õĹ��캯�� 
	 * @param ic,
	 */		
	public xls_gllc_xzdjBase(InterfaceComponent ic) {
		this.ic = ic;
	}	
    public java.sql.ResultSet getResultSet_Query(){
		return resultSet_Query;
	}
	/**
	 * ������е�һ����¼ת��Ϊ���ݶ����е�Record
	 */		
	public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record RSRecord2DO4Query( TongResultSet rs, hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record recordDO) throws Exception{
		try {
				recordDO.setRowNumber(rs.getString(-1));
		recordDO.setYEAR(rs.getString(1));
		recordDO.setXZQH(rs.getBigDecimal(2));
		recordDO.setZXDJ(rs.getBigDecimal(3));
		recordDO.setGLLC(rs.getBigDecimal(4));
			return recordDO;
	}
		catch(ExcelValueException e){
			ic.getLogger().warn("Excelֵ��ȡʧ�ܣ����Ը�������", e);
			reportValueException(e);
			return null;
		}
	}
	
	/**
	 * �����ת��Ϊ���ݶ���
	 **/
	public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj RS2DO4Query(TongResultSet rs, hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj dataObj ) throws Exception{
		try{
		    hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ObjectFactory  of = new hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ObjectFactory();
			
			while(rs.next()){
				  hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record recordDO = of.createRecord();
				 dataObj.getRecord().add(RSRecord2DO4Query(rs,recordDO));
				}
				return dataObj;
			} catch (Exception e){
				ic.getLogger().error(e.getMessage(),e);
				throw new Exception("�ӽ�����γ�DOʧ��");
			}
	}
  
  
	/**
	 * ִ�в�ѯ
	 */			
	 public  void query()  throws Exception{

	    ExcelColumn[] columnMap = new ExcelColumn[4+1];
			columnMap[1] = new ExcelColumn(0, 12, "");
			columnMap[2] = new ExcelColumn(1, 3, "");
			columnMap[3] = new ExcelColumn(2, 3, "");
			columnMap[4] = new ExcelColumn(3, 3, "");
		
			resultSet_Query = new ExcelResultSet(fileName, sheetName, columnMap, head, first, last, maxBlank);
	 }
	 
	/**
	 * ���ز�ѯ�������һ����
	 * @return ���ݶ��� 
	 */	
	public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj nextQuery() throws Exception{
		return nextQuery(this.getBatchCount(),this.getBatchSize());
	}
	
	
	/**
	 * ���ز�ѯ�������һ����
	 * @param BatchCount, ���ļ�¼����
	 * @param BatchSize, ���Ĵ�С
	 * @return ���ݶ���
	 */			
	public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj nextQuery(int BatchCount,int BatchSize) throws Exception{
		BatchSize = BatchSize*1024;
		int sizeflag = 0;
		if (resultSet_Query==null){
            return null;
		}
		hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ObjectFactory of = new hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ObjectFactory(); 
		hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj exceldoGllcXzdj = of.createExceldoGllcXzdj();
		int rows = 0;
		for(int i = 0; i < BufQuery.size();i++){
			exceldoGllcXzdj.getRecord().add(BufQuery.get(i));
			sizeflag +=((hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record)BufQuery.get(i)).MarshalSize();
			rows++;
			BufQuery.clear();
		}
		
		TongResultSet tongRS = new TongResultSet(resultSet_Query,dbType);
		while (tongRS.next()){
			hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record record = of.createRecord();
			record = RSRecord2DO4Query(tongRS,record);
			
			//������ؿգ��ͺ�����һ��
			if(record == null){
				continue;
			}
			
				int thisrecordsize=0;
				if(BatchSize <= 0)
					thisrecordsize = 0;
				else
					thisrecordsize = (record).MarshalSize();
				if(BatchSize > 0 && sizeflag + thisrecordsize > BatchSize){
					BufQuery.add(record);
				    break;
				}
				rows++;
				exceldoGllcXzdj.getRecord().add(record);
				sizeflag += thisrecordsize;
				if(rows == BatchCount)
					break;
			}
		if (rows == 0) {
			return null;
		}else{
			ic.getLogger().debug("This BatchSize :" + sizeflag);
			ic.getLogger().debug("This BatchCount :" + rows);
			return exceldoGllcXzdj;
		}
	}

	/**
	 * �رղ�ѯ�����
	 */		
	public void closeQuery() throws SQLException{
		if (this.resultSet_Query!=null){
			this.resultSet_Query.close();
		}
	}	

}
