package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj;

public interface Record extends javax.xml.bind.Element , hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.RecordType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject {
}
