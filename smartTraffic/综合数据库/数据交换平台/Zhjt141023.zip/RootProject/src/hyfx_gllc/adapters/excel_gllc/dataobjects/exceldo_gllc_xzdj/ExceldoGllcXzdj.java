package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj;

public interface ExceldoGllcXzdj extends javax.xml.bind.Element , hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdjType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject , org.apache.ws.jaxme.generator.sg.CalculateRecordCount {
}
