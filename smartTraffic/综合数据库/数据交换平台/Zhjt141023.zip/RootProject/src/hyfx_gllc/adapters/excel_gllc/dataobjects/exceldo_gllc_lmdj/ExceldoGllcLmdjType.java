package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj;

public interface ExceldoGllcLmdjType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record[] getRecordAsArray();

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record[] valuesInArray);

  public void setRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record value);

}
