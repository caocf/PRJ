/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package hyfx_gllc.adapters.db_hyfxxt.outbound.ao_hyfxxt_demo_gllc_lmdj;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import com.tongtech.ti.adapter.jdbc.util.midprocess.LobCreator;
import com.tongtech.ti.adapter.jdbc.util.midprocess.OracleLobHandler;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterBase;

/**
 * ���³�վ�������Ĺ�����
 */
public class AOHyfxxt_DEMO_GLLC_LMDJBase extends JdbcAdapterBase {

	SimpleDateFormat sdf = null;

	/**
	 * ���ݶ��󹤳�
	 */
	protected static hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.ObjectFactory DEMO_GLLC_LMDJ_exceldoGllcLmdj_doOF = null;

	/**
	 * ���ʼ��ʱ�������ݶ��󹤳���ʵ��
	 */
	static {
		try {
			DEMO_GLLC_LMDJ_exceldoGllcLmdj_doOF = new hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.ObjectFactory();
		} catch(Exception e) {
			classLogger.error("�������ݶ��󹤳�ʧ��",e);
		}
	}

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 */
	public AOHyfxxt_DEMO_GLLC_LMDJBase(InterfaceComponent ic) {
		super(ic);
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 * @param aoname, ���������������
	 */
	public AOHyfxxt_DEMO_GLLC_LMDJBase(InterfaceComponent ic, String aoname) {
		super(ic, aoname);
		
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public boolean DEMO_GLLC_LMDJ(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.ExceldoGllcLmdj exceldoGllcLmdj ) {
		String sqlStr = "insert into BI_DEMO.\"DEMO_GLLC_LMDJ\"(\"YEAR\",\"XZQH\",\"LMDJ\",\"GLLC\") values(?,?,?,?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("insert SQL : " + sqlStr);
		String sqlUpdate = "update BI_DEMO.\"DEMO_GLLC_LMDJ\" set \"YEAR\"=?,\"XZQH\"=?,\"LMDJ\"=?,\"GLLC\"=? where  (\"YEAR\" = ? and \"XZQH\" = ? and \"LMDJ\" = ?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("UPDATE FOR INSERT SQL : " + sqlUpdate);
		hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record record = null;
		int idx=0;
		int paramIdx = 1;
		PreparedStatement pstmt = null;
		PreparedStatement pcyclestmt = null;			
		try {
			pstmt = conn.prepareStatement(sqlStr);
			for (Iterator iter = exceldoGllcLmdj.getRecord().iterator(); iter.hasNext();) {
				record = (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record)iter.next();
		
				pstmt.clearParameters();	
		paramIdx = 1;

		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYEAR(),fromCharSet,toCharSet));			
		pstmt.setBigDecimal(paramIdx++,record.getXZQH());
		pstmt.setBigDecimal(paramIdx++,record.getZXDJ());
		pstmt.setBigDecimal(paramIdx++,record.getGLLC());
				int rst = -1;
				int n = 0;
				java.sql.SQLException sqlException = null;
				while (n<maxDeadlockRetry) {
					try {
						rst = pstmt.executeUpdate();
						break;
					} catch (java.sql.SQLException sqle){
						PreparedStatement pstmtUpd = null;
						try {
							pstmtUpd = conn.prepareStatement(sqlUpdate);
		paramIdx = 1;

		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYEAR(),fromCharSet,toCharSet));			
		pstmtUpd.setBigDecimal(paramIdx++,record.getXZQH());
		pstmtUpd.setBigDecimal(paramIdx++,record.getZXDJ());
		pstmtUpd.setBigDecimal(paramIdx++,record.getGLLC());
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYEAR(),fromCharSet,toCharSet));			
		pstmtUpd.setBigDecimal(paramIdx++,record.getXZQH());
		pstmtUpd.setBigDecimal(paramIdx++,record.getZXDJ());
							
							String pkConflictStr = "";
							if (sqle.getMessage().toLowerCase().indexOf(pkConflictStr.toLowerCase()) != -1) {//����쳣��Ϣ�������õ��쳣����ִ��update
								try {
									rst = pstmtUpd.executeUpdate();
								} catch (java.sql.SQLException sqle2){
									if (isCanRetry(sqle2)){//�ǿ������쳣���ȴ��´�
										n++;
										try	{
											ic.getLogger().warn(sqle2);
											ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
											Thread.sleep(deadlockRetryDelay);
										} catch (Exception ex){
										} 
									} else {//���ǿ������쳣�׳�
										ic.getLogger().error("ִ��SQL���["+sqlUpdate+"]����",sqle2);
										throw sqle2;
									}
								}	
								if (rst == 0) {
									throw sqle;
								} else if (rst > 0) {
									break;
								}
							} else {//�쳣��Ϣ���������õ��쳣��
								ic.getLogger().warn("�趨���쳣ƥ�䴮:\"" + pkConflictStr + "\"���׳����쳣��\"" + sqle.getMessage() + "\"��һ�£�����ִ��update����");
								throw sqle;
							}
						} finally {
							if (pstmtUpd!=null){
								try {
									pstmtUpd.close();
								} catch (Exception e){
									ic.getLogger().warn("Close PreparedStatement[pstmtUpd] error",e);
								}
							}
						}
					}
				}
				if (n== maxDeadlockRetry) {
					ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
					throw sqlException;
				}	
				
				
				
				idx++;
			}
			
			return true;//�ɹ�����true
		} catch (Exception e) {
			//ic.getLogger().error(e.getMessage(),e);
			this.faultMsg = e.toString()+";SQL:"+sqlStr+";ErrorData: "+Do2String(record);
			this.faultMsg = this.faultMsg.replaceAll("\n", "");

			boolean isAutoCommit = false;
			hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.ExceldoGllcLmdj errorDO = null ;
			try {
				if (isStopProcessOnException(e)) {
					isAutoCommit = conn.getAutoCommit();
					if (isAutoCommit) {
						int count=0;
						errorDO = DEMO_GLLC_LMDJ_exceldoGllcLmdj_doOF.createExceldoGllcLmdj();
						for (java.util.Iterator iter = exceldoGllcLmdj.getRecord().iterator(); iter.hasNext();) {
							hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record rec = (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record)iter.next();
							if (count>=idx) {
								List records = errorDO.getRecord();
								if (records==null) records = new ArrayList();
								records.add(rec);
							}
							count++;
						}
						
						com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"exceldoGllcLmdj",ic,e);
						this.faultCode = -3;
						return false;//ʧ�ܣ��Զ��ύ��ֹͣ����
					} else {
						if (isRollbackOnException()) {
							this.faultCode = -2;
							return false;//ʧ�ܣ��ع���ֹͣ����
						} else {
							int count=0;
							errorDO = DEMO_GLLC_LMDJ_exceldoGllcLmdj_doOF.createExceldoGllcLmdj();
							for (java.util.Iterator iter = exceldoGllcLmdj.getRecord().iterator(); iter.hasNext();) {
								hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record rec = (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record)iter.next();
								if (count>=idx) {
									List records = errorDO.getRecord();
									if (records==null) records = new ArrayList();
									records.add(rec);
								}
								count++;
							}
							com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"exceldoGllcLmdj",ic,e);
							this.faultCode = -3;
							return false;//ʧ�ܣ����ع���ֹͣ����
						}
						//errorDO = exceldoGllcLmdj;
					}
				} else {//���ǿ�ֹͣ�ķ���-1
					this.faultCode = -1;
					return false;
				}
			} catch(Exception e1) {
				ic.getLogger().error(e1.getMessage(),e1);
				this.faultCode = -1;
				return false;
			}
		} finally {
			if (pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					ic.getLogger().error("close pstmt error.",e);
				}
			}
				}
	} 
	
	
}
