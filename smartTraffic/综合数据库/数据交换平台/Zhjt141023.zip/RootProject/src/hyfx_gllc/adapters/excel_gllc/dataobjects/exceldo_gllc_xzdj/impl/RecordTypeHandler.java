package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.impl;

public class RecordTypeHandler extends org.apache.ws.jaxme.impl.JMSAXElementParser {
  /** The current state. The following values are valid states:
   *  0 = Before parsing the element
   *  1 = While or after parsing the child element YEAR
   *  2 = While or after parsing the child element XZQH
   *  3 = While or after parsing the child element ZXDJ
   *  4 = While or after parsing the child element GLLC
   *  5 = While or after parsing the child element rowNumber
   * 
   */
  private int __state;


  public boolean startElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler = getHandler();
    switch (__state) {
      case 0:
        return processCase0(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 1:
        return processCase1(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 2:
        return processCase2(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 3:
        return processCase3(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 4:
        return processCase4(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 5:
        return processCase5(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      default:
        throw new java.lang.IllegalStateException("Invalid state: " + __state);
    }
  }

  private boolean processCase0(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YEAR".equals(pLocalName)) {
      __state = 1;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQH".equals(pLocalName)) {
      __state = 2;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZXDJ".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GLLC".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase1(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQH".equals(pLocalName)) {
      __state = 2;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZXDJ".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GLLC".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase2(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZXDJ".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GLLC".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase3(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GLLC".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase4(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase5(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    return false;
  }

  public void endElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, java.lang.Object pResult) throws org.xml.sax.SAXException {
    hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.RecordType _1 = (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.RecordType) result;
    switch (__state) {
      case 1:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "YEAR".equals(pLocalName)) {
          _1.setYEAR((java.lang.String) pResult);
          return;
        }
        break;
      case 2:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XZQH".equals(pLocalName)) {
          try {
            _1.setXZQH(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _2) {
            getHandler().parseConversionEvent("Failed to convert value of XZQH: " + pResult, _2);
          }
          return;
        }
        break;
      case 3:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "ZXDJ".equals(pLocalName)) {
          try {
            _1.setZXDJ(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _3) {
            getHandler().parseConversionEvent("Failed to convert value of ZXDJ: " + pResult, _3);
          }
          return;
        }
        break;
      case 4:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "GLLC".equals(pLocalName)) {
          try {
            _1.setGLLC(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _4) {
            getHandler().parseConversionEvent("Failed to convert value of GLLC: " + pResult, _4);
          }
          return;
        }
        break;
      case 5:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "rowNumber".equals(pLocalName)) {
          _1.setRowNumber((java.lang.String) pResult);
          return;
        }
        break;
      default:
        throw new java.lang.IllegalStateException("Illegal state: " + __state);
    }
  }

  public boolean isFinished() {
    switch (__state) {
      case 5:
      case 4:
      case 3:
      case 2:
      case 1:
      case 0:
        return true;
      default:
        return false;
    }
  }

}
