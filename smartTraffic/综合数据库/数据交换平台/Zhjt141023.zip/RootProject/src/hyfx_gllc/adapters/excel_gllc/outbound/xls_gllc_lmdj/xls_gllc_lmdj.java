/*******************************************************************************
 * Copyright (c) 2009  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package hyfx_gllc.adapters.excel_gllc.outbound.xls_gllc_lmdj;
import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
/**
 * ��ѯ��վ����������
 */
public class xls_gllc_lmdj extends BaseService{
    private java.sql.Connection conn = null;
	private java.lang.String dbType = "excel";
	private InterfaceComponent ic = null;
	
	public java.sql.Connection getConn(){
		return conn;
	}
	public void setConn(java.sql.Connection conn){
		this.conn=conn;
	}
	
	/**
	 * ���캯��
	 * 
	 * @param ic,
	 */	
	public xls_gllc_lmdj(InterfaceComponent ic) {
		this.ic = ic;
	}
	
	public  void initialization() {
		super.initialization();
	}
	public  void cleanUp() {
		super.cleanUp();
	}
	
	/**
	 * ��ѯ��վ�Ĳ�������
	 */		
	public int query(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.ExceldoGllcLmdj exceldoGllcLmdj, default_project.adaptors.database.dataobjects.dbfault.DBFaultDO dBFaultDO) throws java.lang.Exception{
	
		hyfx_gllc.adapters.excel_gllc.outbound.xls_gllc_lmdj.xls_gllc_lmdjBase base = null;
		
		try {
			base = new hyfx_gllc.adapters.excel_gllc.outbound.xls_gllc_lmdj.xls_gllc_lmdjBase(ic);
			base.setIc(ic);
			base.query();
			java.sql.ResultSet rs = base.getResultSet_Query();
			com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet tongRS = new com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet(rs,this.dbType);
			exceldoGllcLmdj = base.RS2DO4Query( tongRS , exceldoGllcLmdj);
			rs.close();
		    return 0;//�ɹ�����0
		} catch (Exception e) {
			dBFaultDO.setFaultMessage(e.toString());
			return -1;//�쳣��ʧ�ܷ���-1
		}
	}
}