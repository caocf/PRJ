/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package hyfx_gllc.adapters.db_hyfxxt.outbound.hyfxxt_demo_gllc_jsdj;

import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.sql.Connection;
import javax.naming.NamingException;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterService;

import com.tongtech.ti.management.jms.AlertConstants;

/**
 * ���³�վ����������
 */
public class Hyfxxt_DEMO_GLLC_JSDJ extends JdbcAdapterService{

	/**
	 * ���캯��
	 * 
	 * @param ic,
	 */
	public Hyfxxt_DEMO_GLLC_JSDJ(InterfaceComponent ic) {
		super(ic);
	}
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public int DEMO_GLLC_JSDJ(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdj exceldoGllcJsdj,default_project.adaptors.database.dataobjects.opresult.OPResultDO oPResultDO,default_project.adaptors.database.dataobjects.dbfault.DBFaultDO dBFaultDO) throws java.lang.Exception{
	
		hyfx_gllc.adapters.db_hyfxxt.outbound.hyfxxt_demo_gllc_jsdj.Hyfxxt_DEMO_GLLC_JSDJBase base = null;
		
		try {
		
			startProcessInfo("DEMO_GLLC_JSDJ", "insert", "DEMO_GLLC_JSDJ", exceldoGllcJsdj);
			
			base = new hyfx_gllc.adapters.db_hyfxxt.outbound.hyfxxt_demo_gllc_jsdj.Hyfxxt_DEMO_GLLC_JSDJBase(ic);
			base.init();
			base.connect();
			   base.setAutoCommit(false);
			boolean baseResult = base.DEMO_GLLC_JSDJ(exceldoGllcJsdj);
			if (baseResult){
				base.commit();
				oPResultDO.setSuccess(true);
				
				endProcessInfo("DEMO_GLLC_JSDJ", "insert", "DEMO_GLLC_JSDJ", 0, 0, true);
				return 0;//�ɹ�
			} else {
				int errorCode = base.getFaultCode();
				base.rollback();
				oPResultDO.setSuccess(false);
				dBFaultDO.setFaultMessage(base.getFaultMsg());
				
				//endProcessInfo("DEMO_GLLC_JSDJ", "insert", "DEMO_GLLC_JSDJ", 0, 0, false);
				Exception exception = new Exception(base.getFaultMsg());
				errorProcessInfo("DEMO_GLLC_JSDJ", "insert", "DEMO_GLLC_JSDJ", exception);
				
				return errorCode;//ʧ��
			}
		} catch (Exception e) {
			//alert
			ic.alert(AlertConstants.ALERT_TYPE_ADAPTER_DB, AlertConstants.ALERT_LEVEL_CRITICAL, "���³�վ����ʧ��",e);
			
			ic.getLogger().error(e.getMessage(),e);
			oPResultDO.setSuccess(false);
			dBFaultDO.setFaultMessage(e.toString());
			ic.getLogger().error(e.getMessage(),e);
			
			errorProcessInfo("DEMO_GLLC_JSDJ", "insert", "DEMO_GLLC_JSDJ", e);
			
			return -1;//�쳣��ʧ�ܷ���-1
		} finally {
			try {
				base.closeConn();
			} catch (Exception e) {
				ic.getLogger().error(e.getMessage(),e);
			}
		}
	}
	
}
