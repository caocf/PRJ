package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.RecordType _1 = (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.RecordType) pObject;
    java.lang.String _2 = _1.getYEAR();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "YEAR", _1.getYEAR());
    }
    java.math.BigDecimal _3 = _1.getXZQH();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "XZQH", pController.getDatatypeConverter().printDecimal(_1.getXZQH()));
    }
    java.math.BigDecimal _4 = _1.getZXDJ();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "ZXDJ", pController.getDatatypeConverter().printDecimal(_1.getZXDJ()));
    }
    java.math.BigDecimal _5 = _1.getGLLC();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "GLLC", pController.getDatatypeConverter().printDecimal(_1.getGLLC()));
    }
    java.lang.String _6 = _1.getRowNumber();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "rowNumber", _1.getRowNumber());
    }
  }

}
