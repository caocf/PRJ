package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.impl;

public class RecordTypeImpl implements hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.RecordType {
  private java.lang.String _yEAR;

  private java.math.BigDecimal _xZQH;

  private java.math.BigDecimal _zXDJ;

  private java.math.BigDecimal _gLLC;

  private java.lang.String _rowNumber;


  public java.lang.String getYEAR() {
    return _yEAR;
  }

  public void setYEAR(java.lang.String pYEAR) {
    _yEAR = pYEAR;
  }

  public java.math.BigDecimal getXZQH() {
    return _xZQH;
  }

  public void setXZQH(java.math.BigDecimal pXZQH) {
    _xZQH = pXZQH;
  }

  public java.math.BigDecimal getZXDJ() {
    return _zXDJ;
  }

  public void setZXDJ(java.math.BigDecimal pZXDJ) {
    _zXDJ = pZXDJ;
  }

  public java.math.BigDecimal getGLLC() {
    return _gLLC;
  }

  public void setGLLC(java.math.BigDecimal pGLLC) {
    _gLLC = pGLLC;
  }

  public java.lang.String getRowNumber() {
    return _rowNumber;
  }

  public void setRowNumber(java.lang.String pRowNumber) {
    _rowNumber = pRowNumber;
  }

}
