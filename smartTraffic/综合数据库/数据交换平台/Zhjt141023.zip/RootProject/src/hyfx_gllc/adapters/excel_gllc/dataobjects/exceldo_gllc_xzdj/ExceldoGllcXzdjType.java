package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj;

public interface ExceldoGllcXzdjType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record[] getRecordAsArray();

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record[] valuesInArray);

  public void setRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.Record value);

}
