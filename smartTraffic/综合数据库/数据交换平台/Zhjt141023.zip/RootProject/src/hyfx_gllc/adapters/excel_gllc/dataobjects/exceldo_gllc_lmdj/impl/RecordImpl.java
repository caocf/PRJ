package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.net.MalformedURLException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.apache.ws.jaxme.JMUnmarshaller;
import org.xml.sax.InputSource;


public class RecordImpl extends hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.impl.RecordTypeImpl implements hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.Record , org.apache.ws.jaxme.JMElement {
  private final static javax.xml.namespace.QName __qName = new javax.xml.namespace.QName("http://www.tongtech.ti/dbrecord/exceldo_gllc_lmdj", "Record", "tidb");

  private boolean fault;


  public javax.xml.namespace.QName getQName() {
    return __qName;
  }

  public void setFault(boolean fault) {
    this.fault = fault;
  }

  public boolean isFault() {
    return this.fault;
  }

  private javax.xml.bind.JAXBContext getContext() throws javax.xml.bind.JAXBException {
    return hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_lmdj.ObjectFactory.getContext();
  }

  public void marshal2File(java.lang.String fileName) throws java.lang.Exception {
    JAXBContext ctx = getContext();
    java.io.OutputStream os = new java.io.FileOutputStream(fileName);
    Marshaller marshaller = ctx.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
    marshaller.marshal(this,os);
    os.close();
  }

  public java.lang.String marshal2String() throws java.lang.Exception {
    JAXBContext ctx = getContext();
    java.io.StringWriter sw = new java.io.StringWriter();
    Marshaller marshaller = ctx.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
    marshaller.marshal(this,sw);
    String s = sw.toString();
    sw.close();
    return s;
  }

  public void marshal2OutputStream(java.io.OutputStream os) throws java.lang.Exception {
    JAXBContext ctx = getContext();
    Marshaller marshaller = ctx.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
    marshaller.marshal(this,os);
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByFile(java.lang.String fileName) throws java.lang.Exception {
    File f = new File(fileName);
    FileInputStream fis = new FileInputStream(f);
    InputSource source = new InputSource(fis);
    source.setSystemId(f.toURL().toString());
    JAXBContext ctx = getContext();
    Unmarshaller u = ctx.createUnmarshaller();
    org.apache.ws.jaxme.generator.sg.DataObject dataObj = (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(source);
    fis.close();
    return dataObj;
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByString(java.lang.String xmlStr) throws java.lang.Exception {
    Reader reader = new StringReader(xmlStr);
    InputSource source = new InputSource(reader);
    JAXBContext ctx = getContext();
    Unmarshaller u = ctx.createUnmarshaller();
    org.apache.ws.jaxme.generator.sg.DataObject dataObj = (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(source);
    return dataObj;
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByInputStream(java.io.InputStream is) throws java.lang.Exception {
    JAXBContext ctx = getContext();
    Unmarshaller u = ctx.createUnmarshaller();
    return (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(is);
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByURL(java.net.URL url) throws java.lang.Exception {
    JAXBContext ctx = getContext();
    Unmarshaller u = ctx.createUnmarshaller();
    return (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(url);
  }

  public int MarshalSize() throws java.lang.Exception {
    JAXBContext ctx = getContext();
    java.io.StringWriter sw = new java.io.StringWriter();
    Marshaller marshaller = ctx.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
    marshaller.marshal(this,sw);
    String s = sw.toString();
    sw.close();
    return s.getBytes().length;
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByFile(java.lang.String fileName, java.lang.Object doObject) throws java.lang.Exception {
    File f = new File(fileName);
    FileInputStream fis = new FileInputStream(f);
    InputSource source = new InputSource(fis);
    source.setSystemId(f.toURL().toString());
    JAXBContext ctx = getContext();
    JMUnmarshaller u = (JMUnmarshaller)ctx.createUnmarshaller();
    org.apache.ws.jaxme.generator.sg.DataObject dataObj = (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(source, doObject);
    fis.close();
    return dataObj;
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByString(java.lang.String xmlStr, java.lang.Object doObject) throws java.lang.Exception {
    Reader reader = new StringReader(xmlStr);
    InputSource source = new InputSource(reader);
    JAXBContext ctx = getContext();
    JMUnmarshaller u = (JMUnmarshaller)ctx.createUnmarshaller();
    org.apache.ws.jaxme.generator.sg.DataObject dataObj = (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(source, doObject);
    return dataObj;
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByInputStream(java.io.InputStream is, java.lang.Object doObject) throws java.lang.Exception {
    JAXBContext ctx = getContext();
    JMUnmarshaller u = (JMUnmarshaller)ctx.createUnmarshaller();
    return (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(is, doObject);
  }

  public org.apache.ws.jaxme.generator.sg.DataObject unmarshalByURL(java.net.URL url, java.lang.Object doObject) throws java.lang.Exception {
    JAXBContext ctx = getContext();
    JMUnmarshaller u = (JMUnmarshaller)ctx.createUnmarshaller();
    return (org.apache.ws.jaxme.generator.sg.DataObject) u.unmarshal(url, doObject);
  }

  public void marshal2Sax(org.xml.sax.ContentHandler handler) throws java.lang.Exception {
    handler.startDocument();
    
    JAXBContext ctx = getContext();
    Marshaller marshaller = ctx.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
    marshaller.marshal(this,handler);
    
    handler.endDocument();
  }

  public javax.xml.bind.UnmarshallerHandler getUnmarshallerHandler(java.lang.Object doObject) throws java.lang.Exception {
    JAXBContext ctx = getContext();
    JMUnmarshaller u = (JMUnmarshaller)ctx.createUnmarshaller();
    
    return u.getUnmarshallerHandler(doObject);
  }

}
