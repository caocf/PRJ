/*******************************************************************************
 * Copyright (c) 2009  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package hyfx_gllc.adapters.excel_gllc.outbound.aoxls_gllc_xzdj;

import java.sql.SQLException;
import org.apache.ws.jaxme.generator.sg.DataObject;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import com.tongtech.ti.adapter.excel.ExcelAdapterObject;

/**
 * ��ѯ��վ����������
 */
public class AOxls_gllc_xzdj extends ExcelAdapterObject{
     
	/**
	 * ���캯��
	 * 
	 * @param ic,
	 * @param aoName, AO������
	 */
	public AOxls_gllc_xzdj(InterfaceComponent ic,String aoName) {		
		super(ic, aoName);
		
		base = new hyfx_gllc.adapters.excel_gllc.outbound.aoxls_gllc_xzdj.AOxls_gllc_xzdjBase(ic);
		base.setAoname(this.aoName);
		base.setIc(ic);
	}	
	


	/**
	 * ִ�в�ѯ
	 */			
    public  void query() throws java.lang.Exception{
		((hyfx_gllc.adapters.excel_gllc.outbound.aoxls_gllc_xzdj.AOxls_gllc_xzdjBase)base).query();
	}
	
	/**
	 * ���ز�ѯ�������һ����
	 * @return ���ݶ��� 
	 */		
    public  hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj nextQuery() throws java.lang.Exception{
    try {
    	startProcessInfo("nextQuery", 0, 0);
		hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj DO = ((hyfx_gllc.adapters.excel_gllc.outbound.aoxls_gllc_xzdj.AOxls_gllc_xzdjBase)base).nextQuery();
			endProcessInfo("nextQuery", DO);// ��¼���̸�����Ϣ��־
		return DO;
	}
		catch(Exception ex){
			errorProcessInfo("nextQuery", ex);
			throw ex;
		}			
	}
	/**
	 * ���ز�ѯ�������һ����
	 * @param BatchCount, ���ļ�¼����
	 * @param BatchSize, ���Ĵ�С
	 * @return ���ݶ���
	 */		
	public  hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj nextQuery(int BatchCount,int BatchSize) throws Exception{
		try {
    	startProcessInfo("nextQuery", 0, 0);
		hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_xzdj.ExceldoGllcXzdj DO = ((hyfx_gllc.adapters.excel_gllc.outbound.aoxls_gllc_xzdj.AOxls_gllc_xzdjBase)base).nextQuery(BatchCount,BatchSize);
			endProcessInfo("nextQuery", DO);// ��¼���̸�����Ϣ��־
		return DO;
	}
		catch(Exception ex){
			errorProcessInfo("nextQuery", ex);
			throw ex;
		}
	}
	
	/**
	 * �رղ�ѯ�����
	 */		
	public  void closeQuery() throws SQLException{
		((hyfx_gllc.adapters.excel_gllc.outbound.aoxls_gllc_xzdj.AOxls_gllc_xzdjBase)base).closeQuery();
	}
}
