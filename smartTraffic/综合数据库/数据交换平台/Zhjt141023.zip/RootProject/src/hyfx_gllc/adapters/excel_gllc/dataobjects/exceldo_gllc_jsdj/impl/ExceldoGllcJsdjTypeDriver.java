package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.impl;

public class ExceldoGllcJsdjTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    if (pURI == null) {
      pURI = "";
    }
    if (pURI.equals("http://www.tongtech.ti/dbrecord/exceldo_gllc_jsdj")) {
      return "tidb";
    }
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdjType _1 = (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdjType) pObject;
    java.util.List _2 = _1.getRecord();
    for (int _3 = 0;  _3 < (_2).size();  _3++) {
      org.apache.ws.jaxme.impl.JMSAXDriver _4 = pController.getJMMarshaller().getJAXBContextImpl().getManagerS(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record.class).getDriver();
      pController.marshal(_4, "http://www.tongtech.ti/dbrecord/exceldo_gllc_jsdj", "Record", (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.RecordType)_2.get(_3));
    }
  }

}
