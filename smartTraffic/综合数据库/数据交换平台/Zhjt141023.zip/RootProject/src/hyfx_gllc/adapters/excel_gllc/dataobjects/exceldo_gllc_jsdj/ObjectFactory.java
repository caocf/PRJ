package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj;

public class ObjectFactory {
  private static org.apache.ws.jaxme.impl.JAXBContextImpl jaxbContext;

  private static javax.xml.bind.JAXBException jaxbEx;

  private java.util.Map properties;


  static {
    try {
      // initialized the context when class is initialing
      jaxbContext = (org.apache.ws.jaxme.impl.JAXBContextImpl) javax.xml.bind.JAXBContext.newInstance("hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj");
    } catch (javax.xml.bind.JAXBException e) {
      jaxbEx = e;
    }
  }

  public ObjectFactory() throws javax.xml.bind.JAXBException {
    // if the context is not initialized, throw a exception
    if (jaxbContext == null) {
      throw new javax.xml.bind.JAXBException(jaxbEx.getMessage(), jaxbEx.getErrorCode(), jaxbEx);
    }
  }

  public static javax.xml.bind.JAXBContext getContext() throws javax.xml.bind.JAXBException {
    // if the context is not initialized, throw a exception
    if (jaxbContext == null) {
      throw new javax.xml.bind.JAXBException(jaxbEx.getMessage(), jaxbEx.getErrorCode(), jaxbEx);
    }
    return jaxbContext;
  }

  public java.lang.Object newInstance(java.lang.Class pElementInterface) throws javax.xml.bind.JAXBException {
    return jaxbContext.getManager(pElementInterface).getElementJ();
  }

  public java.lang.Object getProperty(java.lang.String pName) {
    if (properties == null) {
      return null;
    }
    return properties.get(pName);
  }

  public void setProperty(java.lang.String pName, java.lang.Object pValue) {
    if (properties == null) {
      properties = new java.util.HashMap();
    }
    properties.put(pName, pValue);
  }

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdj createExceldoGllcJsdj() throws javax.xml.bind.JAXBException {
    return (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdj) newInstance(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdj.class);
  }

  public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record createRecord() throws javax.xml.bind.JAXBException {
    return (hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record) newInstance(hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.Record.class);
  }

// public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.ExceldoGllcJsdjType createExceldoGllcJsdjType() throws javax.xml.bind.JAXBException;

// public hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj.RecordType createRecordType() throws javax.xml.bind.JAXBException;

}
