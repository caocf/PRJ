package hyfx_gllc.adapters.excel_gllc.dataobjects.exceldo_gllc_jsdj;

public interface RecordType extends java.io.Serializable {
  public java.lang.String getYEAR();

  public void setYEAR(java.lang.String pYEAR);

  public java.math.BigDecimal getXZQH();

  public void setXZQH(java.math.BigDecimal pXZQH);

  public java.math.BigDecimal getZXDJ();

  public void setZXDJ(java.math.BigDecimal pZXDJ);

  public java.math.BigDecimal getGLLC();

  public void setGLLC(java.math.BigDecimal pGLLC);

  public java.lang.String getRowNumber();

  public void setRowNumber(java.lang.String pRowNumber);

}
