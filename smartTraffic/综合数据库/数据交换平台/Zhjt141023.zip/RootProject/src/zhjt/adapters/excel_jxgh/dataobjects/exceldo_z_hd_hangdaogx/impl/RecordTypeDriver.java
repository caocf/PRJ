package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.RecordType _1 = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.RecordType) pObject;
    java.math.BigDecimal _2 = _1.getGXBH();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "GXBH", pController.getDatatypeConverter().printDecimal(_1.getGXBH()));
    }
    java.lang.String _3 = _1.getGXMC();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "GXMC", _1.getGXMC());
    }
    java.math.BigDecimal _4 = _1.getQDJD();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "QDJD", pController.getDatatypeConverter().printDecimal(_1.getQDJD()));
    }
    java.math.BigDecimal _5 = _1.getQDWD();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "QDWD", pController.getDatatypeConverter().printDecimal(_1.getQDWD()));
    }
    java.math.BigDecimal _6 = _1.getZDJD();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "ZDJD", pController.getDatatypeConverter().printDecimal(_1.getZDJD()));
    }
    java.math.BigDecimal _7 = _1.getZDWD();
    if (_7 != null) {
      pController.marshalSimpleChild(this, "", "ZDWD", pController.getDatatypeConverter().printDecimal(_1.getZDWD()));
    }
    java.math.BigDecimal _8 = _1.getYSMJL();
    if (_8 != null) {
      pController.marshalSimpleChild(this, "", "YSMJL", pController.getDatatypeConverter().printDecimal(_1.getYSMJL()));
    }
    java.lang.String _9 = _1.getGXDWMC();
    if (_9 != null) {
      pController.marshalSimpleChild(this, "", "GXDWMC", _1.getGXDWMC());
    }
    java.lang.String _10 = _1.getSSHD();
    if (_10 != null) {
      pController.marshalSimpleChild(this, "", "SSHD", _1.getSSHD());
    }
    java.lang.String _11 = _1.getSZHD();
    if (_11 != null) {
      pController.marshalSimpleChild(this, "", "SZHD", _1.getSZHD());
    }
    java.lang.String _12 = _1.getBZ();
    if (_12 != null) {
      pController.marshalSimpleChild(this, "", "BZ", _1.getBZ());
    }
    java.lang.String _13 = _1.getRowNumber();
    if (_13 != null) {
      pController.marshalSimpleChild(this, "", "rowNumber", _1.getRowNumber());
    }
  }

}
