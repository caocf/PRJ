/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaogx;

import com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet;
import com.tongtech.ti.adapter.jdbc.util.JdbcUtil;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.util.*;
import java.sql.*;
import com.tongtech.ti.adapter.excel.ColumnExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelColumn;
import com.tongtech.ti.adapter.excel.ExcelAdapterBase;
import com.tongtech.ti.adapter.excel.ExcelValueException;
/**
 * ��ѯ��վ�������Ĺ�����
 */
public class AOxls_z_hd_hangdaogxBase extends ExcelAdapterBase{

	/**
	 * ��ý����
	 */
	private java.sql.ResultSet resultSet_Query= null;
	/**
	 * ���泬��BatchSize�ļ�¼�Ļ���
	 */
	private java.util.ArrayList BufQuery = new ArrayList();

	/**
	 * �����������õĹ��캯�� 
	 * @param ic,
	 */		
	public AOxls_z_hd_hangdaogxBase(InterfaceComponent ic) {
		this.ic = ic;
	}	
    public java.sql.ResultSet getResultSet_Query(){
		return resultSet_Query;
	}
	/**
	 * ������е�һ����¼ת��Ϊ���ݶ����е�Record
	 */		
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.Record RSRecord2DO4Query( TongResultSet rs, zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.Record recordDO) throws Exception{
		try {
				recordDO.setRowNumber(rs.getString(-1));
		recordDO.setGXBH(rs.getBigDecimal(1));
		recordDO.setGXMC(rs.getString(2));
		recordDO.setQDJD(rs.getBigDecimal(3));
		recordDO.setQDWD(rs.getBigDecimal(4));
		recordDO.setZDJD(rs.getBigDecimal(5));
		recordDO.setZDWD(rs.getBigDecimal(6));
		recordDO.setYSMJL(rs.getBigDecimal(7));
		recordDO.setGXDWMC(rs.getString(8));
		recordDO.setSSHD(rs.getString(9));
		recordDO.setSZHD(rs.getString(10));
		recordDO.setBZ(rs.getString(11));
			return recordDO;
	}
		catch(ExcelValueException e){
			ic.getLogger().warn("Excelֵ��ȡʧ�ܣ����Ը�������", e);
			reportValueException(e);
			return null;
		}
	}
	
	/**
	 * �����ת��Ϊ���ݶ���
	 **/
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ExceldoZHdHangdaogx RS2DO4Query(TongResultSet rs, zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ExceldoZHdHangdaogx dataObj ) throws Exception{
		try{
		    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ObjectFactory  of = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ObjectFactory();
			
			while(rs.next()){
				  zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.Record recordDO = of.createRecord();
				 dataObj.getRecord().add(RSRecord2DO4Query(rs,recordDO));
				}
				return dataObj;
			} catch (Exception e){
				ic.getLogger().error(e.getMessage(),e);
				throw new Exception("�ӽ�����γ�DOʧ��");
			}
	}
  
  
	/**
	 * ִ�в�ѯ
	 */			
	 public  void query()  throws Exception{

	    ExcelColumn[] columnMap = new ExcelColumn[11+1];
			columnMap[1] = new ExcelColumn(0, 3, "");
			columnMap[2] = new ExcelColumn(1, 12, "");
			columnMap[3] = new ExcelColumn(2, 3, "");
			columnMap[4] = new ExcelColumn(3, 3, "");
			columnMap[5] = new ExcelColumn(4, 3, "");
			columnMap[6] = new ExcelColumn(5, 3, "");
			columnMap[7] = new ExcelColumn(6, 3, "");
			columnMap[8] = new ExcelColumn(7, 12, "");
			columnMap[9] = new ExcelColumn(8, 12, "");
			columnMap[10] = new ExcelColumn(9, 12, "");
			columnMap[11] = new ExcelColumn(10, 12, "");
		
			resultSet_Query = new ExcelResultSet(fileName, sheetName, columnMap, head, first, last, maxBlank);
	 }
	 
	/**
	 * ���ز�ѯ�������һ����
	 * @return ���ݶ��� 
	 */	
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ExceldoZHdHangdaogx nextQuery() throws Exception{
		return nextQuery(this.getBatchCount(),this.getBatchSize());
	}
	
	
	/**
	 * ���ز�ѯ�������һ����
	 * @param BatchCount, ���ļ�¼����
	 * @param BatchSize, ���Ĵ�С
	 * @return ���ݶ���
	 */			
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ExceldoZHdHangdaogx nextQuery(int BatchCount,int BatchSize) throws Exception{
		BatchSize = BatchSize*1024;
		int sizeflag = 0;
		if (resultSet_Query==null){
            return null;
		}
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ObjectFactory of = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ObjectFactory(); 
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ExceldoZHdHangdaogx exceldoZHdHangdaogx = of.createExceldoZHdHangdaogx();
		int rows = 0;
		for(int i = 0; i < BufQuery.size();i++){
			exceldoZHdHangdaogx.getRecord().add(BufQuery.get(i));
			sizeflag +=((zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.Record)BufQuery.get(i)).MarshalSize();
			rows++;
			BufQuery.clear();
		}
		
		TongResultSet tongRS = new TongResultSet(resultSet_Query,dbType);
		while (tongRS.next()){
			zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.Record record = of.createRecord();
			record = RSRecord2DO4Query(tongRS,record);
			
			//������ؿգ��ͺ�����һ��
			if(record == null){
				continue;
			}
			
				int thisrecordsize=0;
				if(BatchSize <= 0)
					thisrecordsize = 0;
				else
					thisrecordsize = (record).MarshalSize();
				if(BatchSize > 0 && sizeflag + thisrecordsize > BatchSize){
					BufQuery.add(record);
				    break;
				}
				rows++;
				exceldoZHdHangdaogx.getRecord().add(record);
				sizeflag += thisrecordsize;
				if(rows == BatchCount)
					break;
			}
		if (rows == 0) {
			return null;
		}else{
			ic.getLogger().debug("This BatchSize :" + sizeflag);
			ic.getLogger().debug("This BatchCount :" + rows);
			return exceldoZHdHangdaogx;
		}
	}

	/**
	 * �رղ�ѯ�����
	 */		
	public void closeQuery() throws SQLException{
		if (this.resultSet_Query!=null){
			this.resultSet_Query.close();
		}
	}	

}
