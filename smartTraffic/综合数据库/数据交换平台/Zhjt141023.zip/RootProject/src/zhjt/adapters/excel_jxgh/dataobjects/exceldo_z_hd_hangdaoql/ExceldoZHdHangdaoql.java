package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql;

public interface ExceldoZHdHangdaoql extends javax.xml.bind.Element , zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoqlType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject , org.apache.ws.jaxme.generator.sg.CalculateRecordCount {
}
