package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb;

public interface ExceldoZHdHangdaozb extends javax.xml.bind.Element , zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozbType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject , org.apache.ws.jaxme.generator.sg.CalculateRecordCount {
}
