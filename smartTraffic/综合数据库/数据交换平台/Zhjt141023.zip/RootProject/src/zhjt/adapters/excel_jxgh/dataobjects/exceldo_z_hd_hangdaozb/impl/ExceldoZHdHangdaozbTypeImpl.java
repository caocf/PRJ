package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.impl;

public class ExceldoZHdHangdaozbTypeImpl implements zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozbType {
  private java.util.List _record = new java.util.ArrayList();


  public java.util.List getRecord() {
    return _record;
  }

  public int getRecordCount() {
      return _record.size();
  }

  public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record[] getRecordAsArray() {
    java.util.List list = getRecord();
    int size = list.size();
    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record[] valuesInArray = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record[size];
    for (int index = 0; index < size; index++) {
          valuesInArray[index] = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record)list.get(index);
      }
      return valuesInArray;
  }

  public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException {
    java.util.List list = getRecord(); // check bounds for index
    if ((index < 0) || (index >= list.size())) {
    	throw new IndexOutOfBoundsException("getRecord: Index value '"+index+"' not in range [0.."+(list.size() - 1) + "]");
    }
    return (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record)list.get(index);
  }

  public void setRecord(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record[] valuesInArray) {
    java.util.List list = getRecord();
    list.clear();
    if(valuesInArray == null) {
    	  return;
    }
    //-- copy array
    for (int i = 0; i < valuesInArray.length; i++) {
    	list.add(valuesInArray[i]);
    }
  }

  public void setRecord(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record value, int index) throws java.lang.IndexOutOfBoundsException {
    java.util.List list = getRecord();
    //-- check bounds for index
    if ((index < 0) || (index >= list.size())) {
    	throw new IndexOutOfBoundsException("getRecord: Index value '"+index+"' not in range [0.."+(list.size() - 1) + "]");
    }
    list.set(index, value);
  }

  public void addRecord(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record value) {
    java.util.List list = getRecord();
    list.add(value);
  }

}
