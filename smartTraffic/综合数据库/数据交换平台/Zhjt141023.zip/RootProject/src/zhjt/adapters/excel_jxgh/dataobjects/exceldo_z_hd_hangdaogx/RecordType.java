package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getGXBH();

  public void setGXBH(java.math.BigDecimal pGXBH);

  public java.lang.String getGXMC();

  public void setGXMC(java.lang.String pGXMC);

  public java.math.BigDecimal getQDJD();

  public void setQDJD(java.math.BigDecimal pQDJD);

  public java.math.BigDecimal getQDWD();

  public void setQDWD(java.math.BigDecimal pQDWD);

  public java.math.BigDecimal getZDJD();

  public void setZDJD(java.math.BigDecimal pZDJD);

  public java.math.BigDecimal getZDWD();

  public void setZDWD(java.math.BigDecimal pZDWD);

  public java.math.BigDecimal getYSMJL();

  public void setYSMJL(java.math.BigDecimal pYSMJL);

  public java.lang.String getGXDWMC();

  public void setGXDWMC(java.lang.String pGXDWMC);

  public java.lang.String getSSHD();

  public void setSSHD(java.lang.String pSSHD);

  public java.lang.String getSZHD();

  public void setSZHD(java.lang.String pSZHD);

  public java.lang.String getBZ();

  public void setBZ(java.lang.String pBZ);

  public java.lang.String getRowNumber();

  public void setRowNumber(java.lang.String pRowNumber);

}
