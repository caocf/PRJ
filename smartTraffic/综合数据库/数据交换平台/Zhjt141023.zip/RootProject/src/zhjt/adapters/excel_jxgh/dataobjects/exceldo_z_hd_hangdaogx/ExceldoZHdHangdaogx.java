package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx;

public interface ExceldoZHdHangdaogx extends javax.xml.bind.Element , zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.ExceldoZHdHangdaogxType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject , org.apache.ws.jaxme.generator.sg.CalculateRecordCount {
}
