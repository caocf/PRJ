package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.impl;

public class RecordTypeHandler extends org.apache.ws.jaxme.impl.JMSAXElementParser {
  /** The current state. The following values are valid states:
   *  0 = Before parsing the element
   *  1 = While or after parsing the child element ZBBH
   *  2 = While or after parsing the child element ZBMC
   *  3 = While or after parsing the child element QDJD
   *  4 = While or after parsing the child element QDWD
   *  5 = While or after parsing the child element ZDJD
   *  6 = While or after parsing the child element ZDWD
   *  7 = While or after parsing the child element FXDJD
   *  8 = While or after parsing the child element FXDWD
   *  9 = While or after parsing the child element LXID
   *  10 = While or after parsing the child element LXMC
   *  11 = While or after parsing the child element GXDWID
   *  12 = While or after parsing the child element GXDWMC
   *  13 = While or after parsing the child element SSHD
   *  14 = While or after parsing the child element SZHD
   *  15 = While or after parsing the child element BZ
   *  16 = While or after parsing the child element rowNumber
   * 
   */
  private int __state;


  public boolean startElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler = getHandler();
    switch (__state) {
      case 0:
        return processCase0(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 1:
        return processCase1(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 2:
        return processCase2(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 3:
        return processCase3(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 4:
        return processCase4(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 5:
        return processCase5(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 6:
        return processCase6(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 7:
        return processCase7(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 8:
        return processCase8(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 9:
        return processCase9(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 10:
        return processCase10(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 11:
        return processCase11(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 12:
        return processCase12(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 13:
        return processCase13(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 14:
        return processCase14(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 15:
        return processCase15(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 16:
        return processCase16(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      default:
        throw new java.lang.IllegalStateException("Invalid state: " + __state);
    }
  }

  private boolean processCase0(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZBBH".equals(pLocalName)) {
      __state = 1;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZBMC".equals(pLocalName)) {
      __state = 2;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDJD".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDWD".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDJD".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDWD".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDJD".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase1(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZBMC".equals(pLocalName)) {
      __state = 2;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDJD".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDWD".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDJD".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDWD".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDJD".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase2(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDJD".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDWD".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDJD".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDWD".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDJD".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase3(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDWD".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDJD".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDWD".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDJD".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase4(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDJD".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDWD".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDJD".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase5(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZDWD".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDJD".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase6(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDJD".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase7(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FXDWD".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase8(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXID".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase9(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "LXMC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase10(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWID".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase11(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GXDWMC".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase12(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SSHD".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase13(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SZHD".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase14(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "BZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase15(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "rowNumber".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase16(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    return false;
  }

  public void endElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, java.lang.Object pResult) throws org.xml.sax.SAXException {
    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.RecordType _1 = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.RecordType) result;
    switch (__state) {
      case 1:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "ZBBH".equals(pLocalName)) {
          try {
            _1.setZBBH(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _2) {
            getHandler().parseConversionEvent("Failed to convert value of ZBBH: " + pResult, _2);
          }
          return;
        }
        break;
      case 2:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "ZBMC".equals(pLocalName)) {
          _1.setZBMC((java.lang.String) pResult);
          return;
        }
        break;
      case 3:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "QDJD".equals(pLocalName)) {
          try {
            _1.setQDJD(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _3) {
            getHandler().parseConversionEvent("Failed to convert value of QDJD: " + pResult, _3);
          }
          return;
        }
        break;
      case 4:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "QDWD".equals(pLocalName)) {
          try {
            _1.setQDWD(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _4) {
            getHandler().parseConversionEvent("Failed to convert value of QDWD: " + pResult, _4);
          }
          return;
        }
        break;
      case 5:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "ZDJD".equals(pLocalName)) {
          try {
            _1.setZDJD(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _5) {
            getHandler().parseConversionEvent("Failed to convert value of ZDJD: " + pResult, _5);
          }
          return;
        }
        break;
      case 6:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "ZDWD".equals(pLocalName)) {
          try {
            _1.setZDWD(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _6) {
            getHandler().parseConversionEvent("Failed to convert value of ZDWD: " + pResult, _6);
          }
          return;
        }
        break;
      case 7:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "FXDJD".equals(pLocalName)) {
          try {
            _1.setFXDJD(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _7) {
            getHandler().parseConversionEvent("Failed to convert value of FXDJD: " + pResult, _7);
          }
          return;
        }
        break;
      case 8:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "FXDWD".equals(pLocalName)) {
          try {
            _1.setFXDWD(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _8) {
            getHandler().parseConversionEvent("Failed to convert value of FXDWD: " + pResult, _8);
          }
          return;
        }
        break;
      case 9:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "LXID".equals(pLocalName)) {
          _1.setLXID((java.lang.String) pResult);
          return;
        }
        break;
      case 10:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "LXMC".equals(pLocalName)) {
          _1.setLXMC((java.lang.String) pResult);
          return;
        }
        break;
      case 11:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "GXDWID".equals(pLocalName)) {
          _1.setGXDWID((java.lang.String) pResult);
          return;
        }
        break;
      case 12:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "GXDWMC".equals(pLocalName)) {
          _1.setGXDWMC((java.lang.String) pResult);
          return;
        }
        break;
      case 13:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "SSHD".equals(pLocalName)) {
          _1.setSSHD((java.lang.String) pResult);
          return;
        }
        break;
      case 14:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "SZHD".equals(pLocalName)) {
          _1.setSZHD((java.lang.String) pResult);
          return;
        }
        break;
      case 15:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "BZ".equals(pLocalName)) {
          _1.setBZ((java.lang.String) pResult);
          return;
        }
        break;
      case 16:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "rowNumber".equals(pLocalName)) {
          _1.setRowNumber((java.lang.String) pResult);
          return;
        }
        break;
      default:
        throw new java.lang.IllegalStateException("Illegal state: " + __state);
    }
  }

  public boolean isFinished() {
    switch (__state) {
      case 16:
      case 15:
      case 14:
      case 13:
      case 12:
      case 11:
      case 10:
      case 9:
      case 8:
      case 7:
      case 6:
      case 5:
      case 4:
      case 3:
      case 2:
      case 1:
      case 0:
        return true;
      default:
        return false;
    }
  }

}
