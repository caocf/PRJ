/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt.adapters.db_zhjtdata.outbound.zhjtdata_z_hd_hangdaozb;

import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.sql.Connection;
import javax.naming.NamingException;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterService;

import com.tongtech.ti.management.jms.AlertConstants;

/**
 * ���³�վ����������
 */
public class ZhjtData_z_hd_hangdaozb extends JdbcAdapterService{

	/**
	 * ���캯��
	 * 
	 * @param ic,
	 */
	public ZhjtData_z_hd_hangdaozb(InterfaceComponent ic) {
		super(ic);
	}
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public int z_hd_hangdaozb_update(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb exceldoZHdHangdaozb,default_project.adaptors.database.dataobjects.opresult.OPResultDO oPResultDO,default_project.adaptors.database.dataobjects.dbfault.DBFaultDO dBFaultDO) throws java.lang.Exception{
	
		zhjt.adapters.db_zhjtdata.outbound.zhjtdata_z_hd_hangdaozb.ZhjtData_z_hd_hangdaozbBase base = null;
		
		try {
		
			startProcessInfo("z_hd_hangdaozb_update", "insert", "z_hd_hangdaozb_update", exceldoZHdHangdaozb);
			
			base = new zhjt.adapters.db_zhjtdata.outbound.zhjtdata_z_hd_hangdaozb.ZhjtData_z_hd_hangdaozbBase(ic);
			base.init();
			base.connect();
			   base.setAutoCommit(false);
			boolean baseResult = base.z_hd_hangdaozb_update(exceldoZHdHangdaozb);
			if (baseResult){
				base.commit();
				oPResultDO.setSuccess(true);
				
				endProcessInfo("z_hd_hangdaozb_update", "insert", "z_hd_hangdaozb_update", 0, 0, true);
				return 0;//�ɹ�
			} else {
				int errorCode = base.getFaultCode();
				base.rollback();
				oPResultDO.setSuccess(false);
				dBFaultDO.setFaultMessage(base.getFaultMsg());
				
				//endProcessInfo("z_hd_hangdaozb_update", "insert", "z_hd_hangdaozb_update", 0, 0, false);
				Exception exception = new Exception(base.getFaultMsg());
				errorProcessInfo("z_hd_hangdaozb_update", "insert", "z_hd_hangdaozb_update", exception);
				
				return errorCode;//ʧ��
			}
		} catch (Exception e) {
			//alert
			ic.alert(AlertConstants.ALERT_TYPE_ADAPTER_DB, AlertConstants.ALERT_LEVEL_CRITICAL, "���³�վ����ʧ��",e);
			
			ic.getLogger().error(e.getMessage(),e);
			oPResultDO.setSuccess(false);
			dBFaultDO.setFaultMessage(e.toString());
			ic.getLogger().error(e.getMessage(),e);
			
			errorProcessInfo("z_hd_hangdaozb_update", "insert", "z_hd_hangdaozb_update", e);
			
			return -1;//�쳣��ʧ�ܷ���-1
		} finally {
			try {
				base.closeConn();
			} catch (Exception e) {
				ic.getLogger().error(e.getMessage(),e);
			}
		}
	}
	
}
