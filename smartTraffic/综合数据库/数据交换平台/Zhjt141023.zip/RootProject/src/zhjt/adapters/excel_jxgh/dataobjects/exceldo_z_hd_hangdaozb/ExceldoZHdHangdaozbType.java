package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb;

public interface ExceldoZHdHangdaozbType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record[] getRecordAsArray();

  public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record[] valuesInArray);

  public void setRecord(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record value);

}
