package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getQLBH();

  public void setQLBH(java.math.BigDecimal pQLBH);

  public java.lang.String getQLMC();

  public void setQLMC(java.lang.String pQLMC);

  public java.math.BigDecimal getQDJD();

  public void setQDJD(java.math.BigDecimal pQDJD);

  public java.math.BigDecimal getQDWD();

  public void setQDWD(java.math.BigDecimal pQDWD);

  public java.math.BigDecimal getZDJD();

  public void setZDJD(java.math.BigDecimal pZDJD);

  public java.math.BigDecimal getZDWD();

  public void setZDWD(java.math.BigDecimal pZDWD);

  public java.lang.String getGXDWMC();

  public void setGXDWMC(java.lang.String pGXDWMC);

  public java.lang.String getSSHD();

  public void setSSHD(java.lang.String pSSHD);

  public java.lang.String getSZHD();

  public void setSZHD(java.lang.String pSZHD);

  public java.math.BigDecimal getSJZGTHSW();

  public void setSJZGTHSW(java.math.BigDecimal pSJZGTHSW);

  public java.lang.String getYTFL();

  public void setYTFL(java.lang.String pYTFL);

  public java.lang.String getJGXS();

  public void setJGXS(java.lang.String pJGXS);

  public java.math.BigDecimal getTHKS();

  public void setTHKS(java.math.BigDecimal pTHKS);

  public java.lang.String getSFWQ();

  public void setSFWQ(java.lang.String pSFWQ);

  public java.math.BigDecimal getJG();

  public void setJG(java.math.BigDecimal pJG);

  public java.math.BigDecimal getSJZGTHSWHSCXQ();

  public void setSJZGTHSWHSCXQ(java.math.BigDecimal pSJZGTHSWHSCXQ);

  public java.lang.String getRowNumber();

  public void setRowNumber(java.lang.String pRowNumber);

}
