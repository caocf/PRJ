package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.impl;

public class RecordTypeImpl implements zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaogx.RecordType {
  private java.math.BigDecimal _gXBH;

  private java.lang.String _gXMC;

  private java.math.BigDecimal _qDJD;

  private java.math.BigDecimal _qDWD;

  private java.math.BigDecimal _zDJD;

  private java.math.BigDecimal _zDWD;

  private java.math.BigDecimal _ySMJL;

  private java.lang.String _gXDWMC;

  private java.lang.String _sSHD;

  private java.lang.String _sZHD;

  private java.lang.String _bZ;

  private java.lang.String _rowNumber;


  public java.math.BigDecimal getGXBH() {
    return _gXBH;
  }

  public void setGXBH(java.math.BigDecimal pGXBH) {
    _gXBH = pGXBH;
  }

  public java.lang.String getGXMC() {
    return _gXMC;
  }

  public void setGXMC(java.lang.String pGXMC) {
    _gXMC = pGXMC;
  }

  public java.math.BigDecimal getQDJD() {
    return _qDJD;
  }

  public void setQDJD(java.math.BigDecimal pQDJD) {
    _qDJD = pQDJD;
  }

  public java.math.BigDecimal getQDWD() {
    return _qDWD;
  }

  public void setQDWD(java.math.BigDecimal pQDWD) {
    _qDWD = pQDWD;
  }

  public java.math.BigDecimal getZDJD() {
    return _zDJD;
  }

  public void setZDJD(java.math.BigDecimal pZDJD) {
    _zDJD = pZDJD;
  }

  public java.math.BigDecimal getZDWD() {
    return _zDWD;
  }

  public void setZDWD(java.math.BigDecimal pZDWD) {
    _zDWD = pZDWD;
  }

  public java.math.BigDecimal getYSMJL() {
    return _ySMJL;
  }

  public void setYSMJL(java.math.BigDecimal pYSMJL) {
    _ySMJL = pYSMJL;
  }

  public java.lang.String getGXDWMC() {
    return _gXDWMC;
  }

  public void setGXDWMC(java.lang.String pGXDWMC) {
    _gXDWMC = pGXDWMC;
  }

  public java.lang.String getSSHD() {
    return _sSHD;
  }

  public void setSSHD(java.lang.String pSSHD) {
    _sSHD = pSSHD;
  }

  public java.lang.String getSZHD() {
    return _sZHD;
  }

  public void setSZHD(java.lang.String pSZHD) {
    _sZHD = pSZHD;
  }

  public java.lang.String getBZ() {
    return _bZ;
  }

  public void setBZ(java.lang.String pBZ) {
    _bZ = pBZ;
  }

  public java.lang.String getRowNumber() {
    return _rowNumber;
  }

  public void setRowNumber(java.lang.String pRowNumber) {
    _rowNumber = pRowNumber;
  }

}
