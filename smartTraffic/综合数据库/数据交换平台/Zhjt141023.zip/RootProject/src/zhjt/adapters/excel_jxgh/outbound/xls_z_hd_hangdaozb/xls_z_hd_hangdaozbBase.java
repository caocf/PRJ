/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt.adapters.excel_jxgh.outbound.xls_z_hd_hangdaozb;

import com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet;
import com.tongtech.ti.adapter.jdbc.util.JdbcUtil;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.util.*;
import java.sql.*;
import com.tongtech.ti.adapter.excel.ColumnExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelColumn;
import com.tongtech.ti.adapter.excel.ExcelAdapterBase;
import com.tongtech.ti.adapter.excel.ExcelValueException;
/**
 * ��ѯ��վ�������Ĺ�����
 */
public class xls_z_hd_hangdaozbBase extends ExcelAdapterBase{

	/**
	 * ��ý����
	 */
	private java.sql.ResultSet resultSet_Query= null;
	/**
	 * ���泬��BatchSize�ļ�¼�Ļ���
	 */
	private java.util.ArrayList BufQuery = new ArrayList();

	/**
	 * �����������õĹ��캯�� 
	 * @param ic,
	 */		
	public xls_z_hd_hangdaozbBase(InterfaceComponent ic) {
		this.ic = ic;
	}	
    public java.sql.ResultSet getResultSet_Query(){
		return resultSet_Query;
	}
	/**
	 * ������е�һ����¼ת��Ϊ���ݶ����е�Record
	 */		
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record RSRecord2DO4Query( TongResultSet rs, zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record recordDO) throws Exception{
		try {
				recordDO.setRowNumber(rs.getString(-1));
		recordDO.setZBBH(rs.getBigDecimal(1));
		recordDO.setZBMC(rs.getString(2));
		recordDO.setQDJD(rs.getBigDecimal(3));
		recordDO.setQDWD(rs.getBigDecimal(4));
		recordDO.setZDJD(rs.getBigDecimal(5));
		recordDO.setZDWD(rs.getBigDecimal(6));
		recordDO.setFXDJD(rs.getBigDecimal(7));
		recordDO.setFXDWD(rs.getBigDecimal(8));
		recordDO.setLXID(rs.getString(9));
		recordDO.setLXMC(rs.getString(10));
		recordDO.setGXDWID(rs.getString(11));
		recordDO.setGXDWMC(rs.getString(12));
		recordDO.setSSHD(rs.getString(13));
		recordDO.setSZHD(rs.getString(14));
		recordDO.setBZ(rs.getString(15));
			return recordDO;
	}
		catch(ExcelValueException e){
			ic.getLogger().warn("Excelֵ��ȡʧ�ܣ����Ը�������", e);
			reportValueException(e);
			return null;
		}
	}
	
	/**
	 * �����ת��Ϊ���ݶ���
	 **/
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb RS2DO4Query(TongResultSet rs, zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb dataObj ) throws Exception{
		try{
		    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ObjectFactory  of = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ObjectFactory();
			
			while(rs.next()){
				  zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record recordDO = of.createRecord();
				 dataObj.getRecord().add(RSRecord2DO4Query(rs,recordDO));
				}
				return dataObj;
			} catch (Exception e){
				ic.getLogger().error(e.getMessage(),e);
				throw new Exception("�ӽ�����γ�DOʧ��");
			}
	}
  
  
	/**
	 * ִ�в�ѯ
	 */			
	 public  void query()  throws Exception{

	    ExcelColumn[] columnMap = new ExcelColumn[15+1];
			columnMap[1] = new ExcelColumn(0, 3, "");
			columnMap[2] = new ExcelColumn(1, 12, "");
			columnMap[3] = new ExcelColumn(2, 3, "");
			columnMap[4] = new ExcelColumn(3, 3, "");
			columnMap[5] = new ExcelColumn(4, 3, "");
			columnMap[6] = new ExcelColumn(5, 3, "");
			columnMap[7] = new ExcelColumn(6, 3, "");
			columnMap[8] = new ExcelColumn(7, 3, "");
			columnMap[9] = new ExcelColumn(8, 12, "");
			columnMap[10] = new ExcelColumn(9, 12, "");
			columnMap[11] = new ExcelColumn(10, 12, "");
			columnMap[12] = new ExcelColumn(11, 12, "");
			columnMap[13] = new ExcelColumn(12, 12, "");
			columnMap[14] = new ExcelColumn(13, 12, "");
			columnMap[15] = new ExcelColumn(14, 12, "");
		
			resultSet_Query = new ExcelResultSet(fileName, sheetName, columnMap, head, first, last, maxBlank);
	 }
	 
	/**
	 * ���ز�ѯ�������һ����
	 * @return ���ݶ��� 
	 */	
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb nextQuery() throws Exception{
		return nextQuery(this.getBatchCount(),this.getBatchSize());
	}
	
	
	/**
	 * ���ز�ѯ�������һ����
	 * @param BatchCount, ���ļ�¼����
	 * @param BatchSize, ���Ĵ�С
	 * @return ���ݶ���
	 */			
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb nextQuery(int BatchCount,int BatchSize) throws Exception{
		BatchSize = BatchSize*1024;
		int sizeflag = 0;
		if (resultSet_Query==null){
            return null;
		}
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ObjectFactory of = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ObjectFactory(); 
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb exceldoZHdHangdaozb = of.createExceldoZHdHangdaozb();
		int rows = 0;
		for(int i = 0; i < BufQuery.size();i++){
			exceldoZHdHangdaozb.getRecord().add(BufQuery.get(i));
			sizeflag +=((zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record)BufQuery.get(i)).MarshalSize();
			rows++;
			BufQuery.clear();
		}
		
		TongResultSet tongRS = new TongResultSet(resultSet_Query,dbType);
		while (tongRS.next()){
			zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record record = of.createRecord();
			record = RSRecord2DO4Query(tongRS,record);
			
			//������ؿգ��ͺ�����һ��
			if(record == null){
				continue;
			}
			
				int thisrecordsize=0;
				if(BatchSize <= 0)
					thisrecordsize = 0;
				else
					thisrecordsize = (record).MarshalSize();
				if(BatchSize > 0 && sizeflag + thisrecordsize > BatchSize){
					BufQuery.add(record);
				    break;
				}
				rows++;
				exceldoZHdHangdaozb.getRecord().add(record);
				sizeflag += thisrecordsize;
				if(rows == BatchCount)
					break;
			}
		if (rows == 0) {
			return null;
		}else{
			ic.getLogger().debug("This BatchSize :" + sizeflag);
			ic.getLogger().debug("This BatchCount :" + rows);
			return exceldoZHdHangdaozb;
		}
	}

	/**
	 * �رղ�ѯ�����
	 */		
	public void closeQuery() throws SQLException{
		if (this.resultSet_Query!=null){
			this.resultSet_Query.close();
		}
	}	

}
