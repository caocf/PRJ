package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb;

public interface Record extends javax.xml.bind.Element , zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.RecordType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject {
}
