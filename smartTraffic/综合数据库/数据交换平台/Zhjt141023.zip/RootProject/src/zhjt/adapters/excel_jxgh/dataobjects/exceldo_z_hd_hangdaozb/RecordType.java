package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getZBBH();

  public void setZBBH(java.math.BigDecimal pZBBH);

  public java.lang.String getZBMC();

  public void setZBMC(java.lang.String pZBMC);

  public java.math.BigDecimal getQDJD();

  public void setQDJD(java.math.BigDecimal pQDJD);

  public java.math.BigDecimal getQDWD();

  public void setQDWD(java.math.BigDecimal pQDWD);

  public java.math.BigDecimal getZDJD();

  public void setZDJD(java.math.BigDecimal pZDJD);

  public java.math.BigDecimal getZDWD();

  public void setZDWD(java.math.BigDecimal pZDWD);

  public java.math.BigDecimal getFXDJD();

  public void setFXDJD(java.math.BigDecimal pFXDJD);

  public java.math.BigDecimal getFXDWD();

  public void setFXDWD(java.math.BigDecimal pFXDWD);

  public java.lang.String getLXID();

  public void setLXID(java.lang.String pLXID);

  public java.lang.String getLXMC();

  public void setLXMC(java.lang.String pLXMC);

  public java.lang.String getGXDWID();

  public void setGXDWID(java.lang.String pGXDWID);

  public java.lang.String getGXDWMC();

  public void setGXDWMC(java.lang.String pGXDWMC);

  public java.lang.String getSSHD();

  public void setSSHD(java.lang.String pSSHD);

  public java.lang.String getSZHD();

  public void setSZHD(java.lang.String pSZHD);

  public java.lang.String getBZ();

  public void setBZ(java.lang.String pBZ);

  public java.lang.String getRowNumber();

  public void setRowNumber(java.lang.String pRowNumber);

}
