/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt.adapters.excel_jxgh.outbound.xls_z_hd_hangdaoql;

import com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet;
import com.tongtech.ti.adapter.jdbc.util.JdbcUtil;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.util.*;
import java.sql.*;
import com.tongtech.ti.adapter.excel.ColumnExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelResultSet;
import com.tongtech.ti.adapter.excel.ExcelColumn;
import com.tongtech.ti.adapter.excel.ExcelAdapterBase;
import com.tongtech.ti.adapter.excel.ExcelValueException;
/**
 * ��ѯ��վ�������Ĺ�����
 */
public class xls_z_hd_hangdaoqlBase extends ExcelAdapterBase{

	/**
	 * ��ý����
	 */
	private java.sql.ResultSet resultSet_Query= null;
	/**
	 * ���泬��BatchSize�ļ�¼�Ļ���
	 */
	private java.util.ArrayList BufQuery = new ArrayList();

	/**
	 * �����������õĹ��캯�� 
	 * @param ic,
	 */		
	public xls_z_hd_hangdaoqlBase(InterfaceComponent ic) {
		this.ic = ic;
	}	
    public java.sql.ResultSet getResultSet_Query(){
		return resultSet_Query;
	}
	/**
	 * ������е�һ����¼ת��Ϊ���ݶ����е�Record
	 */		
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.Record RSRecord2DO4Query( TongResultSet rs, zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.Record recordDO) throws Exception{
		try {
				recordDO.setRowNumber(rs.getString(-1));
		recordDO.setQLBH(rs.getBigDecimal(1));
		recordDO.setQLMC(rs.getString(2));
		recordDO.setQDJD(rs.getBigDecimal(3));
		recordDO.setQDWD(rs.getBigDecimal(4));
		recordDO.setZDJD(rs.getBigDecimal(5));
		recordDO.setZDWD(rs.getBigDecimal(6));
		recordDO.setGXDWMC(rs.getString(7));
		recordDO.setSSHD(rs.getString(8));
		recordDO.setSZHD(rs.getString(9));
		recordDO.setSJZGTHSW(rs.getBigDecimal(10));
		recordDO.setYTFL(rs.getString(11));
		recordDO.setJGXS(rs.getString(12));
		recordDO.setTHKS(rs.getBigDecimal(13));
		recordDO.setSFWQ(rs.getString(14));
		recordDO.setJG(rs.getBigDecimal(15));
		recordDO.setSJZGTHSWHSCXQ(rs.getBigDecimal(16));
			return recordDO;
	}
		catch(ExcelValueException e){
			ic.getLogger().warn("Excelֵ��ȡʧ�ܣ����Ը�������", e);
			reportValueException(e);
			return null;
		}
	}
	
	/**
	 * �����ת��Ϊ���ݶ���
	 **/
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoql RS2DO4Query(TongResultSet rs, zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoql dataObj ) throws Exception{
		try{
		    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ObjectFactory  of = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ObjectFactory();
			
			while(rs.next()){
				  zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.Record recordDO = of.createRecord();
				 dataObj.getRecord().add(RSRecord2DO4Query(rs,recordDO));
				}
				return dataObj;
			} catch (Exception e){
				ic.getLogger().error(e.getMessage(),e);
				throw new Exception("�ӽ�����γ�DOʧ��");
			}
	}
  
  
	/**
	 * ִ�в�ѯ
	 */			
	 public  void query()  throws Exception{

	    ExcelColumn[] columnMap = new ExcelColumn[16+1];
			columnMap[1] = new ExcelColumn(0, 3, "");
			columnMap[2] = new ExcelColumn(1, 12, "");
			columnMap[3] = new ExcelColumn(2, 3, "");
			columnMap[4] = new ExcelColumn(3, 3, "");
			columnMap[5] = new ExcelColumn(4, 3, "");
			columnMap[6] = new ExcelColumn(5, 3, "");
			columnMap[7] = new ExcelColumn(6, 12, "");
			columnMap[8] = new ExcelColumn(7, 12, "");
			columnMap[9] = new ExcelColumn(8, 12, "");
			columnMap[10] = new ExcelColumn(9, 3, "");
			columnMap[11] = new ExcelColumn(10, 12, "");
			columnMap[12] = new ExcelColumn(11, 12, "");
			columnMap[13] = new ExcelColumn(12, 3, "");
			columnMap[14] = new ExcelColumn(13, 12, "");
			columnMap[15] = new ExcelColumn(14, 3, "");
			columnMap[16] = new ExcelColumn(15, 3, "");
		
			resultSet_Query = new ExcelResultSet(fileName, sheetName, columnMap, head, first, last, maxBlank);
	 }
	 
	/**
	 * ���ز�ѯ�������һ����
	 * @return ���ݶ��� 
	 */	
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoql nextQuery() throws Exception{
		return nextQuery(this.getBatchCount(),this.getBatchSize());
	}
	
	
	/**
	 * ���ز�ѯ�������һ����
	 * @param BatchCount, ���ļ�¼����
	 * @param BatchSize, ���Ĵ�С
	 * @return ���ݶ���
	 */			
	public zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoql nextQuery(int BatchCount,int BatchSize) throws Exception{
		BatchSize = BatchSize*1024;
		int sizeflag = 0;
		if (resultSet_Query==null){
            return null;
		}
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ObjectFactory of = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ObjectFactory(); 
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoql exceldoZHdHangdaoql = of.createExceldoZHdHangdaoql();
		int rows = 0;
		for(int i = 0; i < BufQuery.size();i++){
			exceldoZHdHangdaoql.getRecord().add(BufQuery.get(i));
			sizeflag +=((zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.Record)BufQuery.get(i)).MarshalSize();
			rows++;
			BufQuery.clear();
		}
		
		TongResultSet tongRS = new TongResultSet(resultSet_Query,dbType);
		while (tongRS.next()){
			zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.Record record = of.createRecord();
			record = RSRecord2DO4Query(tongRS,record);
			
			//������ؿգ��ͺ�����һ��
			if(record == null){
				continue;
			}
			
				int thisrecordsize=0;
				if(BatchSize <= 0)
					thisrecordsize = 0;
				else
					thisrecordsize = (record).MarshalSize();
				if(BatchSize > 0 && sizeflag + thisrecordsize > BatchSize){
					BufQuery.add(record);
				    break;
				}
				rows++;
				exceldoZHdHangdaoql.getRecord().add(record);
				sizeflag += thisrecordsize;
				if(rows == BatchCount)
					break;
			}
		if (rows == 0) {
			return null;
		}else{
			ic.getLogger().debug("This BatchSize :" + sizeflag);
			ic.getLogger().debug("This BatchCount :" + rows);
			return exceldoZHdHangdaoql;
		}
	}

	/**
	 * �رղ�ѯ�����
	 */		
	public void closeQuery() throws SQLException{
		if (this.resultSet_Query!=null){
			this.resultSet_Query.close();
		}
	}	

}
