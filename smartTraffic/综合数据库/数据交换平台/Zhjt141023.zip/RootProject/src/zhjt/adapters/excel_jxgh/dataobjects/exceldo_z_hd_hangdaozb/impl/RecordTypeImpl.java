package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.impl;

public class RecordTypeImpl implements zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.RecordType {
  private java.math.BigDecimal _zBBH;

  private java.lang.String _zBMC;

  private java.math.BigDecimal _qDJD;

  private java.math.BigDecimal _qDWD;

  private java.math.BigDecimal _zDJD;

  private java.math.BigDecimal _zDWD;

  private java.math.BigDecimal _fXDJD;

  private java.math.BigDecimal _fXDWD;

  private java.lang.String _lXID;

  private java.lang.String _lXMC;

  private java.lang.String _gXDWID;

  private java.lang.String _gXDWMC;

  private java.lang.String _sSHD;

  private java.lang.String _sZHD;

  private java.lang.String _bZ;

  private java.lang.String _rowNumber;


  public java.math.BigDecimal getZBBH() {
    return _zBBH;
  }

  public void setZBBH(java.math.BigDecimal pZBBH) {
    _zBBH = pZBBH;
  }

  public java.lang.String getZBMC() {
    return _zBMC;
  }

  public void setZBMC(java.lang.String pZBMC) {
    _zBMC = pZBMC;
  }

  public java.math.BigDecimal getQDJD() {
    return _qDJD;
  }

  public void setQDJD(java.math.BigDecimal pQDJD) {
    _qDJD = pQDJD;
  }

  public java.math.BigDecimal getQDWD() {
    return _qDWD;
  }

  public void setQDWD(java.math.BigDecimal pQDWD) {
    _qDWD = pQDWD;
  }

  public java.math.BigDecimal getZDJD() {
    return _zDJD;
  }

  public void setZDJD(java.math.BigDecimal pZDJD) {
    _zDJD = pZDJD;
  }

  public java.math.BigDecimal getZDWD() {
    return _zDWD;
  }

  public void setZDWD(java.math.BigDecimal pZDWD) {
    _zDWD = pZDWD;
  }

  public java.math.BigDecimal getFXDJD() {
    return _fXDJD;
  }

  public void setFXDJD(java.math.BigDecimal pFXDJD) {
    _fXDJD = pFXDJD;
  }

  public java.math.BigDecimal getFXDWD() {
    return _fXDWD;
  }

  public void setFXDWD(java.math.BigDecimal pFXDWD) {
    _fXDWD = pFXDWD;
  }

  public java.lang.String getLXID() {
    return _lXID;
  }

  public void setLXID(java.lang.String pLXID) {
    _lXID = pLXID;
  }

  public java.lang.String getLXMC() {
    return _lXMC;
  }

  public void setLXMC(java.lang.String pLXMC) {
    _lXMC = pLXMC;
  }

  public java.lang.String getGXDWID() {
    return _gXDWID;
  }

  public void setGXDWID(java.lang.String pGXDWID) {
    _gXDWID = pGXDWID;
  }

  public java.lang.String getGXDWMC() {
    return _gXDWMC;
  }

  public void setGXDWMC(java.lang.String pGXDWMC) {
    _gXDWMC = pGXDWMC;
  }

  public java.lang.String getSSHD() {
    return _sSHD;
  }

  public void setSSHD(java.lang.String pSSHD) {
    _sSHD = pSSHD;
  }

  public java.lang.String getSZHD() {
    return _sZHD;
  }

  public void setSZHD(java.lang.String pSZHD) {
    _sZHD = pSZHD;
  }

  public java.lang.String getBZ() {
    return _bZ;
  }

  public void setBZ(java.lang.String pBZ) {
    _bZ = pBZ;
  }

  public java.lang.String getRowNumber() {
    return _rowNumber;
  }

  public void setRowNumber(java.lang.String pRowNumber) {
    _rowNumber = pRowNumber;
  }

}
