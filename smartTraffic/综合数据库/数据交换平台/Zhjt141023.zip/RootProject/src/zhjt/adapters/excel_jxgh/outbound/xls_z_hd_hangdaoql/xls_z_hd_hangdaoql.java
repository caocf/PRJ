/*******************************************************************************
 * Copyright (c) 2009  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt.adapters.excel_jxgh.outbound.xls_z_hd_hangdaoql;
import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
/**
 * ��ѯ��վ����������
 */
public class xls_z_hd_hangdaoql extends BaseService{
    private java.sql.Connection conn = null;
	private java.lang.String dbType = "excel";
	private InterfaceComponent ic = null;
	
	public java.sql.Connection getConn(){
		return conn;
	}
	public void setConn(java.sql.Connection conn){
		this.conn=conn;
	}
	
	/**
	 * ���캯��
	 * 
	 * @param ic,
	 */	
	public xls_z_hd_hangdaoql(InterfaceComponent ic) {
		this.ic = ic;
	}
	
	public  void initialization() {
		super.initialization();
	}
	public  void cleanUp() {
		super.cleanUp();
	}
	
	/**
	 * ��ѯ��վ�Ĳ�������
	 */		
	public int query(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoql exceldoZHdHangdaoql, default_project.adaptors.database.dataobjects.dbfault.DBFaultDO dBFaultDO) throws java.lang.Exception{
	
		zhjt.adapters.excel_jxgh.outbound.xls_z_hd_hangdaoql.xls_z_hd_hangdaoqlBase base = null;
		
		try {
			base = new zhjt.adapters.excel_jxgh.outbound.xls_z_hd_hangdaoql.xls_z_hd_hangdaoqlBase(ic);
			base.setIc(ic);
			base.query();
			java.sql.ResultSet rs = base.getResultSet_Query();
			com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet tongRS = new com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet(rs,this.dbType);
			exceldoZHdHangdaoql = base.RS2DO4Query( tongRS , exceldoZHdHangdaoql);
			rs.close();
		    return 0;//�ɹ�����0
		} catch (Exception e) {
			dBFaultDO.setFaultMessage(e.toString());
			return -1;//�쳣��ʧ�ܷ���-1
		}
	}
}