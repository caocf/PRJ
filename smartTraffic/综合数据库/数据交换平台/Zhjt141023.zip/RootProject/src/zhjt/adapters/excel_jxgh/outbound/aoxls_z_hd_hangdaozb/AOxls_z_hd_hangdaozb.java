/*******************************************************************************
 * Copyright (c) 2009  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaozb;

import java.sql.SQLException;
import org.apache.ws.jaxme.generator.sg.DataObject;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import com.tongtech.ti.adapter.excel.ExcelAdapterObject;

/**
 * ��ѯ��վ����������
 */
public class AOxls_z_hd_hangdaozb extends ExcelAdapterObject{
     
	/**
	 * ���캯��
	 * 
	 * @param ic,
	 * @param aoName, AO������
	 */
	public AOxls_z_hd_hangdaozb(InterfaceComponent ic,String aoName) {		
		super(ic, aoName);
		
		base = new zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaozb.AOxls_z_hd_hangdaozbBase(ic);
		base.setAoname(this.aoName);
		base.setIc(ic);
	}	
	


	/**
	 * ִ�в�ѯ
	 */			
    public  void query() throws java.lang.Exception{
		((zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaozb.AOxls_z_hd_hangdaozbBase)base).query();
	}
	
	/**
	 * ���ز�ѯ�������һ����
	 * @return ���ݶ��� 
	 */		
    public  zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb nextQuery() throws java.lang.Exception{
    try {
    	startProcessInfo("nextQuery", 0, 0);
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb DO = ((zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaozb.AOxls_z_hd_hangdaozbBase)base).nextQuery();
			endProcessInfo("nextQuery", DO);// ��¼���̸�����Ϣ��־
		return DO;
	}
		catch(Exception ex){
			errorProcessInfo("nextQuery", ex);
			throw ex;
		}			
	}
	/**
	 * ���ز�ѯ�������һ����
	 * @param BatchCount, ���ļ�¼����
	 * @param BatchSize, ���Ĵ�С
	 * @return ���ݶ���
	 */		
	public  zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb nextQuery(int BatchCount,int BatchSize) throws Exception{
		try {
    	startProcessInfo("nextQuery", 0, 0);
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb DO = ((zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaozb.AOxls_z_hd_hangdaozbBase)base).nextQuery(BatchCount,BatchSize);
			endProcessInfo("nextQuery", DO);// ��¼���̸�����Ϣ��־
		return DO;
	}
		catch(Exception ex){
			errorProcessInfo("nextQuery", ex);
			throw ex;
		}
	}
	
	/**
	 * �رղ�ѯ�����
	 */		
	public  void closeQuery() throws SQLException{
		((zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaozb.AOxls_z_hd_hangdaozbBase)base).closeQuery();
	}
}
