/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt.adapters.db_zhjtdata.outbound.ao_zhjtdata_z_hd_hangdaozb;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import com.tongtech.ti.adapter.jdbc.util.midprocess.LobCreator;
import com.tongtech.ti.adapter.jdbc.util.midprocess.OracleLobHandler;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterBase;

/**
 * ���³�վ�������Ĺ�����
 */
public class AOZhjtData_z_hd_hangdaozbBase extends JdbcAdapterBase {

	SimpleDateFormat sdf = null;

	/**
	 * ���ݶ��󹤳�
	 */
	protected static zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ObjectFactory z_hd_hangdaozb_update_exceldoZHdHangdaozb_doOF = null;

	/**
	 * ���ʼ��ʱ�������ݶ��󹤳���ʵ��
	 */
	static {
		try {
			z_hd_hangdaozb_update_exceldoZHdHangdaozb_doOF = new zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ObjectFactory();
		} catch(Exception e) {
			classLogger.error("�������ݶ��󹤳�ʧ��",e);
		}
	}

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 */
	public AOZhjtData_z_hd_hangdaozbBase(InterfaceComponent ic) {
		super(ic);
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 * @param aoname, ���������������
	 */
	public AOZhjtData_z_hd_hangdaozbBase(InterfaceComponent ic, String aoname) {
		super(ic, aoname);
		
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public boolean z_hd_hangdaozb_update(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb exceldoZHdHangdaozb ) {
		String sqlStr = "insert into ZHJTADMIN.\"Z_HD_HANGDAOZB\"(\"ZBBH\",\"ZBMC\",\"QDJD\",\"QDWD\",\"ZDJD\",\"ZDWD\",\"FXDJD\",\"FXDWD\",\"LXID\",\"LXMC\",\"GXDWID\",\"GXDWMC\",\"SSHD\",\"SZHD\",\"BZ\") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("insert SQL : " + sqlStr);
		String sqlUpdate = "update ZHJTADMIN.\"Z_HD_HANGDAOZB\" set \"ZBBH\"=?,\"ZBMC\"=?,\"QDJD\"=?,\"QDWD\"=?,\"ZDJD\"=?,\"ZDWD\"=?,\"FXDJD\"=?,\"FXDWD\"=?,\"LXID\"=?,\"LXMC\"=?,\"GXDWID\"=?,\"GXDWMC\"=?,\"SSHD\"=?,\"SZHD\"=?,\"BZ\"=? where  (\"ZBBH\" = ?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("UPDATE FOR INSERT SQL : " + sqlUpdate);
		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record record = null;
		int idx=0;
		int paramIdx = 1;
		PreparedStatement pstmt = null;
		PreparedStatement pcyclestmt = null;			
		try {
			pstmt = conn.prepareStatement(sqlStr);
			for (Iterator iter = exceldoZHdHangdaozb.getRecord().iterator(); iter.hasNext();) {
				record = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record)iter.next();
		
				pstmt.clearParameters();	
		paramIdx = 1;

		pstmt.setBigDecimal(paramIdx++,record.getZBBH());
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZBMC(),fromCharSet,toCharSet));			
		pstmt.setBigDecimal(paramIdx++,record.getQDJD());
		pstmt.setBigDecimal(paramIdx++,record.getQDWD());
		pstmt.setBigDecimal(paramIdx++,record.getZDJD());
		pstmt.setBigDecimal(paramIdx++,record.getZDWD());
		pstmt.setBigDecimal(paramIdx++,record.getFXDJD());
		pstmt.setBigDecimal(paramIdx++,record.getFXDWD());
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getLXID(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getLXMC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getGXDWID(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getGXDWMC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSSHD(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSZHD(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getBZ(),fromCharSet,toCharSet));			
				int rst = -1;
				int n = 0;
				java.sql.SQLException sqlException = null;
				while (n<maxDeadlockRetry) {
					try {
						rst = pstmt.executeUpdate();
						break;
					} catch (java.sql.SQLException sqle){
						PreparedStatement pstmtUpd = null;
						try {
							pstmtUpd = conn.prepareStatement(sqlUpdate);
		paramIdx = 1;

		pstmtUpd.setBigDecimal(paramIdx++,record.getZBBH());
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getZBMC(),fromCharSet,toCharSet));			
		pstmtUpd.setBigDecimal(paramIdx++,record.getQDJD());
		pstmtUpd.setBigDecimal(paramIdx++,record.getQDWD());
		pstmtUpd.setBigDecimal(paramIdx++,record.getZDJD());
		pstmtUpd.setBigDecimal(paramIdx++,record.getZDWD());
		pstmtUpd.setBigDecimal(paramIdx++,record.getFXDJD());
		pstmtUpd.setBigDecimal(paramIdx++,record.getFXDWD());
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getLXID(),fromCharSet,toCharSet));			
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getLXMC(),fromCharSet,toCharSet));			
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getGXDWID(),fromCharSet,toCharSet));			
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getGXDWMC(),fromCharSet,toCharSet));			
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSSHD(),fromCharSet,toCharSet));			
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSZHD(),fromCharSet,toCharSet));			
		pstmtUpd.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getBZ(),fromCharSet,toCharSet));			
		pstmtUpd.setBigDecimal(paramIdx++,record.getZBBH());
							
							String pkConflictStr = "";
							if (sqle.getMessage().toLowerCase().indexOf(pkConflictStr.toLowerCase()) != -1) {//����쳣��Ϣ�������õ��쳣����ִ��update
								try {
									rst = pstmtUpd.executeUpdate();
								} catch (java.sql.SQLException sqle2){
									if (isCanRetry(sqle2)){//�ǿ������쳣���ȴ��´�
										n++;
										try	{
											ic.getLogger().warn(sqle2);
											ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
											Thread.sleep(deadlockRetryDelay);
										} catch (Exception ex){
										} 
									} else {//���ǿ������쳣�׳�
										ic.getLogger().error("ִ��SQL���["+sqlUpdate+"]����",sqle2);
										throw sqle2;
									}
								}	
								if (rst == 0) {
									throw sqle;
								} else if (rst > 0) {
									break;
								}
							} else {//�쳣��Ϣ���������õ��쳣��
								ic.getLogger().warn("�趨���쳣ƥ�䴮:\"" + pkConflictStr + "\"���׳����쳣��\"" + sqle.getMessage() + "\"��һ�£�����ִ��update����");
								throw sqle;
							}
						} finally {
							if (pstmtUpd!=null){
								try {
									pstmtUpd.close();
								} catch (Exception e){
									ic.getLogger().warn("Close PreparedStatement[pstmtUpd] error",e);
								}
							}
						}
					}
				}
				if (n== maxDeadlockRetry) {
					ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
					throw sqlException;
				}	
				
				
				
				idx++;
			}
			
			return true;//�ɹ�����true
		} catch (Exception e) {
			//ic.getLogger().error(e.getMessage(),e);
			this.faultMsg = e.toString()+";SQL:"+sqlStr+";ErrorData: "+Do2String(record);
			this.faultMsg = this.faultMsg.replaceAll("\n", "");

			boolean isAutoCommit = false;
			zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.ExceldoZHdHangdaozb errorDO = null ;
			try {
				if (isStopProcessOnException(e)) {
					isAutoCommit = conn.getAutoCommit();
					if (isAutoCommit) {
						int count=0;
						errorDO = z_hd_hangdaozb_update_exceldoZHdHangdaozb_doOF.createExceldoZHdHangdaozb();
						for (java.util.Iterator iter = exceldoZHdHangdaozb.getRecord().iterator(); iter.hasNext();) {
							zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record rec = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record)iter.next();
							if (count>=idx) {
								List records = errorDO.getRecord();
								if (records==null) records = new ArrayList();
								records.add(rec);
							}
							count++;
						}
						
						com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"exceldoZHdHangdaozb",ic,e);
						this.faultCode = -3;
						return false;//ʧ�ܣ��Զ��ύ��ֹͣ����
					} else {
						if (isRollbackOnException()) {
							this.faultCode = -2;
							return false;//ʧ�ܣ��ع���ֹͣ����
						} else {
							int count=0;
							errorDO = z_hd_hangdaozb_update_exceldoZHdHangdaozb_doOF.createExceldoZHdHangdaozb();
							for (java.util.Iterator iter = exceldoZHdHangdaozb.getRecord().iterator(); iter.hasNext();) {
								zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record rec = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaozb.Record)iter.next();
								if (count>=idx) {
									List records = errorDO.getRecord();
									if (records==null) records = new ArrayList();
									records.add(rec);
								}
								count++;
							}
							com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"exceldoZHdHangdaozb",ic,e);
							this.faultCode = -3;
							return false;//ʧ�ܣ����ع���ֹͣ����
						}
						//errorDO = exceldoZHdHangdaozb;
					}
				} else {//���ǿ�ֹͣ�ķ���-1
					this.faultCode = -1;
					return false;
				}
			} catch(Exception e1) {
				ic.getLogger().error(e1.getMessage(),e1);
				this.faultCode = -1;
				return false;
			}
		} finally {
			if (pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					ic.getLogger().error("close pstmt error.",e);
				}
			}
				}
	} 
	
	
}
