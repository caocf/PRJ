package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.RecordType _1 = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.RecordType) pObject;
    java.math.BigDecimal _2 = _1.getQLBH();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "QLBH", pController.getDatatypeConverter().printDecimal(_1.getQLBH()));
    }
    java.lang.String _3 = _1.getQLMC();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "QLMC", _1.getQLMC());
    }
    java.math.BigDecimal _4 = _1.getQDJD();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "QDJD", pController.getDatatypeConverter().printDecimal(_1.getQDJD()));
    }
    java.math.BigDecimal _5 = _1.getQDWD();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "QDWD", pController.getDatatypeConverter().printDecimal(_1.getQDWD()));
    }
    java.math.BigDecimal _6 = _1.getZDJD();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "ZDJD", pController.getDatatypeConverter().printDecimal(_1.getZDJD()));
    }
    java.math.BigDecimal _7 = _1.getZDWD();
    if (_7 != null) {
      pController.marshalSimpleChild(this, "", "ZDWD", pController.getDatatypeConverter().printDecimal(_1.getZDWD()));
    }
    java.lang.String _8 = _1.getGXDWMC();
    if (_8 != null) {
      pController.marshalSimpleChild(this, "", "GXDWMC", _1.getGXDWMC());
    }
    java.lang.String _9 = _1.getSSHD();
    if (_9 != null) {
      pController.marshalSimpleChild(this, "", "SSHD", _1.getSSHD());
    }
    java.lang.String _10 = _1.getSZHD();
    if (_10 != null) {
      pController.marshalSimpleChild(this, "", "SZHD", _1.getSZHD());
    }
    java.math.BigDecimal _11 = _1.getSJZGTHSW();
    if (_11 != null) {
      pController.marshalSimpleChild(this, "", "SJZGTHSW", pController.getDatatypeConverter().printDecimal(_1.getSJZGTHSW()));
    }
    java.lang.String _12 = _1.getYTFL();
    if (_12 != null) {
      pController.marshalSimpleChild(this, "", "YTFL", _1.getYTFL());
    }
    java.lang.String _13 = _1.getJGXS();
    if (_13 != null) {
      pController.marshalSimpleChild(this, "", "JGXS", _1.getJGXS());
    }
    java.math.BigDecimal _14 = _1.getTHKS();
    if (_14 != null) {
      pController.marshalSimpleChild(this, "", "THKS", pController.getDatatypeConverter().printDecimal(_1.getTHKS()));
    }
    java.lang.String _15 = _1.getSFWQ();
    if (_15 != null) {
      pController.marshalSimpleChild(this, "", "SFWQ", _1.getSFWQ());
    }
    java.math.BigDecimal _16 = _1.getJG();
    if (_16 != null) {
      pController.marshalSimpleChild(this, "", "JG", pController.getDatatypeConverter().printDecimal(_1.getJG()));
    }
    java.math.BigDecimal _17 = _1.getSJZGTHSWHSCXQ();
    if (_17 != null) {
      pController.marshalSimpleChild(this, "", "SJZGTHSWHSCXQ", pController.getDatatypeConverter().printDecimal(_1.getSJZGTHSWHSCXQ()));
    }
    java.lang.String _18 = _1.getRowNumber();
    if (_18 != null) {
      pController.marshalSimpleChild(this, "", "rowNumber", _1.getRowNumber());
    }
  }

}
