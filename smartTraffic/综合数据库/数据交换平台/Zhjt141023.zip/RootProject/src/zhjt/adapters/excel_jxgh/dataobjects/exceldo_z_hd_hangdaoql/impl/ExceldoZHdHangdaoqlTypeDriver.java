package zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.impl;

public class ExceldoZHdHangdaoqlTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    if (pURI == null) {
      pURI = "";
    }
    if (pURI.equals("http://www.tongtech.ti/dbrecord/exceldo_z_hd_hangdaoql")) {
      return "tidb";
    }
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoqlType _1 = (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoqlType) pObject;
    java.util.List _2 = _1.getRecord();
    for (int _3 = 0;  _3 < (_2).size();  _3++) {
      org.apache.ws.jaxme.impl.JMSAXDriver _4 = pController.getJMMarshaller().getJAXBContextImpl().getManagerS(zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.Record.class).getDriver();
      pController.marshal(_4, "http://www.tongtech.ti/dbrecord/exceldo_z_hd_hangdaoql", "Record", (zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.RecordType)_2.get(_3));
    }
  }

}
