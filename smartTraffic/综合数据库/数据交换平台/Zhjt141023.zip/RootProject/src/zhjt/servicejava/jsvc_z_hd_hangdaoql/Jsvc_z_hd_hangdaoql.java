package zhjt.servicejava.jsvc_z_hd_hangdaoql;

import default_project.adaptors.file.outbound.fileadapterobject.FileAOParameter;
import default_project.adaptors.file.outbound.fileadapterobject.FileAdapterObject;
import com.tongtech.ti.javaservice.BaseService;
import zhjt.adapters.excel_jxgh.outbound.aoxls_z_hd_hangdaoql.AOxls_z_hd_hangdaoql;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import default_project.adaptors.file.dataobjects.nameinbound.FileNameInboundDO;
import zhjt.adapters.db_zhjtdata.outbound.ao_zhjtdata_z_hd_hangdaoql.AOZhjtData_z_hd_hangdaoql;
public class Jsvc_z_hd_hangdaoql extends BaseService{
	private InterfaceComponent ic = null;


	private void saveErrorData(default_project.adaptors.file.outbound.fileadapterobject.FileAdapterObject fileAO,
		String errorMsg, String errorData) throws Exception{
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String sDate = sdf.format(new java.util.Date());
		String errorContents = "ERROR TIME:" + sDate + "\r\nERROR MESSAGE: " + errorMsg + "\r\nERROR DATA:\r\n" + errorData + "\r\n";
		fileAO.connect();
		fileAO.writeText(null,null,errorContents);
		fileAO.disconnect();
	}
/*METHODS BEGIN*/
	public Jsvc_z_hd_hangdaoql(InterfaceComponent ic) {
		this.ic = ic;
	}
	public  int OnFileName(FileNameInboundDO filenameinbounddo,AOZhjtData_z_hd_hangdaoql aozhjtdata_z_hd_hangdaoql,AOxls_z_hd_hangdaoql aoxls_z_hd_hangdaoql,FileAdapterObject fileadapterobject) {
		/*���ڴ��޸����ԣ�ȷ���������ɴ���ʱ�Ƿ񸲸�ԭ�д��룬�Ϸ�ֵΪtrue����false��CoverOldCode:false*/

		zhjt.adapters.excel_jxgh.dataobjects.exceldo_z_hd_hangdaoql.ExceldoZHdHangdaoql doQueryResult = null;
		String filename = null;
		com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject dbAO = aozhjtdata_z_hd_hangdaoql;
		try {
			filename = filenameinbounddo.getPath()+"/"+filenameinbounddo.getName();
			aoxls_z_hd_hangdaoql.setFileName(filenameinbounddo.getPath(),filenameinbounddo.getTemFileName());
			//aoxls_z_hd_hangdaoql.setSheetName("result");
			aoxls_z_hd_hangdaoql.connectToDB();
			dbAO.connectToDB();
			try {
				dbAO.setAutoCommit(false);
				aoxls_z_hd_hangdaoql.query();
				doQueryResult = aoxls_z_hd_hangdaoql.nextQuery();
				while (doQueryResult!=null){
					boolean execResult  = dbAO.executeInsert("z_hd_hangdaoql_insert",doQueryResult);
					if (!execResult){
						ic.getLogger().error("�������ݵ����ݿ����: " + dbAO.getFaultMsg());
						saveErrorData(fileadapterobject,dbAO.getFaultMsg(),doQueryResult.marshal2String());
						dbAO.rollback();
					} else {
						dbAO.commit();
					}
					doQueryResult = aoxls_z_hd_hangdaoql.nextQuery();
				}
 
			} catch (Exception e) {
				dbAO.rollback();
				throw e;
			}
			aoxls_z_hd_hangdaoql.closeConnection();
			return 0;
		} catch (Exception e) {
			ic.getLogger().error("��Excel�ļ�["+filename+"]�������ݿ����,",e);
			ic.alert("��Excel�ļ�["+filename+"]�������ݿ����",e);
			return -1;
		} finally {
			try {
				dbAO.setAutoCommit(true);
				dbAO.closeConnection();
			} catch(Exception e1){
				ic.getLogger().error("�ر����ݿ��վAO[aozhjtdata_z_hd_hangdaoql]����,",e1);
			}	
			try {
				aoxls_z_hd_hangdaoql.closeQuery();
				aoxls_z_hd_hangdaoql.closeConnection();
			} catch (Exception e1){
				ic.getLogger().error("�ر�Excel��ѯ��վ[aoxls_z_hd_hangdaoql]����,",e1);
			}
		}

	}
/*METHODS END*/
}
