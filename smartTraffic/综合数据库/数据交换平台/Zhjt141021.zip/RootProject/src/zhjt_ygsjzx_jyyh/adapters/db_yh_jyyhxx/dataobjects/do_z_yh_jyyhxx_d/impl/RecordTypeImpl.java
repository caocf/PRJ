package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.RecordType {
  private java.lang.String _yHID;


  public java.lang.String getYHID() {
    return _yHID;
  }

  public void setYHID(java.lang.String pYHID) {
    _yHID = pYHID;
  }

}
