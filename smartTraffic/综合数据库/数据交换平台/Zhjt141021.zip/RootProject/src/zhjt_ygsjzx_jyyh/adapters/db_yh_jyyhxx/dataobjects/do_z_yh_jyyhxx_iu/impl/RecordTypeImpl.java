package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.RecordType {
  private java.lang.String _yHID;

  private java.lang.String _yHMC;

  private java.lang.String _yEHUDZ;

  private java.lang.String _xZQHDM;

  private java.lang.String _xZQHMC;

  private java.lang.String _fRDB;

  private java.lang.String _jYXKZH;

  private java.lang.String _jYFW;

  private java.lang.String _jYFWDM;

  private java.lang.String _jJLX;

  private java.lang.String _jJLXNAME;

  private java.util.Calendar _hFRQ;

  private java.util.Calendar _zCRQ;

  private java.util.Calendar _yXQQ;

  private java.util.Calendar _yXQZ;

  private java.lang.String _mEMO;


  public java.lang.String getYHID() {
    return _yHID;
  }

  public void setYHID(java.lang.String pYHID) {
    _yHID = pYHID;
  }

  public java.lang.String getYHMC() {
    return _yHMC;
  }

  public void setYHMC(java.lang.String pYHMC) {
    _yHMC = pYHMC;
  }

  public java.lang.String getYEHUDZ() {
    return _yEHUDZ;
  }

  public void setYEHUDZ(java.lang.String pYEHUDZ) {
    _yEHUDZ = pYEHUDZ;
  }

  public java.lang.String getXZQHDM() {
    return _xZQHDM;
  }

  public void setXZQHDM(java.lang.String pXZQHDM) {
    _xZQHDM = pXZQHDM;
  }

  public java.lang.String getXZQHMC() {
    return _xZQHMC;
  }

  public void setXZQHMC(java.lang.String pXZQHMC) {
    _xZQHMC = pXZQHMC;
  }

  public java.lang.String getFRDB() {
    return _fRDB;
  }

  public void setFRDB(java.lang.String pFRDB) {
    _fRDB = pFRDB;
  }

  public java.lang.String getJYXKZH() {
    return _jYXKZH;
  }

  public void setJYXKZH(java.lang.String pJYXKZH) {
    _jYXKZH = pJYXKZH;
  }

  public java.lang.String getJYFW() {
    return _jYFW;
  }

  public void setJYFW(java.lang.String pJYFW) {
    _jYFW = pJYFW;
  }

  public java.lang.String getJYFWDM() {
    return _jYFWDM;
  }

  public void setJYFWDM(java.lang.String pJYFWDM) {
    _jYFWDM = pJYFWDM;
  }

  public java.lang.String getJJLX() {
    return _jJLX;
  }

  public void setJJLX(java.lang.String pJJLX) {
    _jJLX = pJJLX;
  }

  public java.lang.String getJJLXNAME() {
    return _jJLXNAME;
  }

  public void setJJLXNAME(java.lang.String pJJLXNAME) {
    _jJLXNAME = pJJLXNAME;
  }

  public java.util.Calendar getHFRQ() {
    return _hFRQ;
  }

  public void setHFRQ(java.util.Calendar pHFRQ) {
    _hFRQ = pHFRQ;
  }

  public java.util.Calendar getZCRQ() {
    return _zCRQ;
  }

  public void setZCRQ(java.util.Calendar pZCRQ) {
    _zCRQ = pZCRQ;
  }

  public java.util.Calendar getYXQQ() {
    return _yXQQ;
  }

  public void setYXQQ(java.util.Calendar pYXQQ) {
    _yXQQ = pYXQQ;
  }

  public java.util.Calendar getYXQZ() {
    return _yXQZ;
  }

  public void setYXQZ(java.util.Calendar pYXQZ) {
    _yXQZ = pYXQZ;
  }

  public java.lang.String getMEMO() {
    return _mEMO;
  }

  public void setMEMO(java.lang.String pMEMO) {
    _mEMO = pMEMO;
  }

}
