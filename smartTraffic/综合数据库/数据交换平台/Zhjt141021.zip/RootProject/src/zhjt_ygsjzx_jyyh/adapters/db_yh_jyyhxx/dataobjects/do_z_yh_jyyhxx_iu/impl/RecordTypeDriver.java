package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.RecordType _1 = (zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.RecordType) pObject;
    java.lang.String _2 = _1.getYHID();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "YHID", _1.getYHID());
    }
    java.lang.String _3 = _1.getYHMC();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "YHMC", _1.getYHMC());
    }
    java.lang.String _4 = _1.getYEHUDZ();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "YEHUDZ", _1.getYEHUDZ());
    }
    java.lang.String _5 = _1.getXZQHDM();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "XZQHDM", _1.getXZQHDM());
    }
    java.lang.String _6 = _1.getXZQHMC();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "XZQHMC", _1.getXZQHMC());
    }
    java.lang.String _7 = _1.getFRDB();
    if (_7 != null) {
      pController.marshalSimpleChild(this, "", "FRDB", _1.getFRDB());
    }
    java.lang.String _8 = _1.getJYXKZH();
    if (_8 != null) {
      pController.marshalSimpleChild(this, "", "JYXKZH", _1.getJYXKZH());
    }
    java.lang.String _9 = _1.getJYFW();
    if (_9 != null) {
      pController.marshalSimpleChild(this, "", "JYFW", _1.getJYFW());
    }
    java.lang.String _10 = _1.getJYFWDM();
    if (_10 != null) {
      pController.marshalSimpleChild(this, "", "JYFWDM", _1.getJYFWDM());
    }
    java.lang.String _11 = _1.getJJLX();
    if (_11 != null) {
      pController.marshalSimpleChild(this, "", "JJLX", _1.getJJLX());
    }
    java.lang.String _12 = _1.getJJLXNAME();
    if (_12 != null) {
      pController.marshalSimpleChild(this, "", "JJLX_NAME", _1.getJJLXNAME());
    }
    java.util.Calendar _13 = _1.getHFRQ();
    if (_13 != null) {
      pController.marshalSimpleChild(this, "", "HFRQ", pController.getJMMarshaller().getDateTimeFormat().format(_1.getHFRQ()));
    }
    java.util.Calendar _14 = _1.getZCRQ();
    if (_14 != null) {
      pController.marshalSimpleChild(this, "", "ZCRQ", pController.getJMMarshaller().getDateTimeFormat().format(_1.getZCRQ()));
    }
    java.util.Calendar _15 = _1.getYXQQ();
    if (_15 != null) {
      pController.marshalSimpleChild(this, "", "YXQQ", pController.getJMMarshaller().getDateTimeFormat().format(_1.getYXQQ()));
    }
    java.util.Calendar _16 = _1.getYXQZ();
    if (_16 != null) {
      pController.marshalSimpleChild(this, "", "YXQZ", pController.getJMMarshaller().getDateTimeFormat().format(_1.getYXQZ()));
    }
    java.lang.String _17 = _1.getMEMO();
    if (_17 != null) {
      pController.marshalSimpleChild(this, "", "MEMO", _1.getMEMO());
    }
  }

}
