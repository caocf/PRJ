package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d;

public interface DoZYhJyyhxxDType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.Record[] getRecordAsArray();

  public zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.Record[] valuesInArray);

  public void setRecord(zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.Record value);

}
