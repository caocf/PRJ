package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu;

public interface RecordType extends java.io.Serializable {
  public java.lang.String getYHID();

  public void setYHID(java.lang.String pYHID);

  public java.lang.String getYHMC();

  public void setYHMC(java.lang.String pYHMC);

  public java.lang.String getYEHUDZ();

  public void setYEHUDZ(java.lang.String pYEHUDZ);

  public java.lang.String getXZQHDM();

  public void setXZQHDM(java.lang.String pXZQHDM);

  public java.lang.String getXZQHMC();

  public void setXZQHMC(java.lang.String pXZQHMC);

  public java.lang.String getFRDB();

  public void setFRDB(java.lang.String pFRDB);

  public java.lang.String getJYXKZH();

  public void setJYXKZH(java.lang.String pJYXKZH);

  public java.lang.String getJYFW();

  public void setJYFW(java.lang.String pJYFW);

  public java.lang.String getJYFWDM();

  public void setJYFWDM(java.lang.String pJYFWDM);

  public java.lang.String getJJLX();

  public void setJJLX(java.lang.String pJJLX);

  public java.lang.String getJJLXNAME();

  public void setJJLXNAME(java.lang.String pJJLXNAME);

  public java.util.Calendar getHFRQ();

  public void setHFRQ(java.util.Calendar pHFRQ);

  public java.util.Calendar getZCRQ();

  public void setZCRQ(java.util.Calendar pZCRQ);

  public java.util.Calendar getYXQQ();

  public void setYXQQ(java.util.Calendar pYXQQ);

  public java.util.Calendar getYXQZ();

  public void setYXQZ(java.util.Calendar pYXQZ);

  public java.lang.String getMEMO();

  public void setMEMO(java.lang.String pMEMO);

}
