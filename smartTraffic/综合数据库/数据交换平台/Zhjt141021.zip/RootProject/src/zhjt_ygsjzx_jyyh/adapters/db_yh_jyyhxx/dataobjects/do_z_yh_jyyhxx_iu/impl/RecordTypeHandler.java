package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.impl;

public class RecordTypeHandler extends org.apache.ws.jaxme.impl.JMSAXElementParser {
  /** The current state. The following values are valid states:
   *  0 = Before parsing the element
   *  1 = While or after parsing the child element YHID
   *  2 = While or after parsing the child element YHMC
   *  3 = While or after parsing the child element YEHUDZ
   *  4 = While or after parsing the child element XZQHDM
   *  5 = While or after parsing the child element XZQHMC
   *  6 = While or after parsing the child element FRDB
   *  7 = While or after parsing the child element JYXKZH
   *  8 = While or after parsing the child element JYFW
   *  9 = While or after parsing the child element JYFWDM
   *  10 = While or after parsing the child element JJLX
   *  11 = While or after parsing the child element JJLX_NAME
   *  12 = While or after parsing the child element HFRQ
   *  13 = While or after parsing the child element ZCRQ
   *  14 = While or after parsing the child element YXQQ
   *  15 = While or after parsing the child element YXQZ
   *  16 = While or after parsing the child element MEMO
   * 
   */
  private int __state;


  public boolean startElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler = getHandler();
    switch (__state) {
      case 0:
        return processCase0(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 1:
        return processCase1(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 2:
        return processCase2(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 3:
        return processCase3(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 4:
        return processCase4(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 5:
        return processCase5(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 6:
        return processCase6(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 7:
        return processCase7(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 8:
        return processCase8(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 9:
        return processCase9(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 10:
        return processCase10(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 11:
        return processCase11(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 12:
        return processCase12(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 13:
        return processCase13(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 14:
        return processCase14(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 15:
        return processCase15(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 16:
        return processCase16(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      default:
        throw new java.lang.IllegalStateException("Invalid state: " + __state);
    }
  }

  private boolean processCase0(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YHID".equals(pLocalName)) {
      __state = 1;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase1(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YHMC".equals(pLocalName)) {
      __state = 2;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YEHUDZ".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQHDM".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQHMC".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FRDB".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYXKZH".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFW".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase2(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YEHUDZ".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQHDM".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQHMC".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FRDB".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYXKZH".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFW".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase3(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQHDM".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQHMC".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FRDB".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYXKZH".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFW".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase4(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XZQHMC".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FRDB".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYXKZH".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFW".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase5(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FRDB".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYXKZH".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFW".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase6(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYXKZH".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFW".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase7(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFW".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase8(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JYFWDM".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase9(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase10(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JJLX_NAME".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase11(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "HFRQ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase12(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "ZCRQ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase13(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQQ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase14(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "YXQZ".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase15(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "MEMO".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase16(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    return false;
  }

  public void endElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, java.lang.Object pResult) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.RecordType _1 = (zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.RecordType) result;
    switch (__state) {
      case 1:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "YHID".equals(pLocalName)) {
          _1.setYHID((java.lang.String) pResult);
          return;
        }
        break;
      case 2:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "YHMC".equals(pLocalName)) {
          _1.setYHMC((java.lang.String) pResult);
          return;
        }
        break;
      case 3:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "YEHUDZ".equals(pLocalName)) {
          _1.setYEHUDZ((java.lang.String) pResult);
          return;
        }
        break;
      case 4:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XZQHDM".equals(pLocalName)) {
          _1.setXZQHDM((java.lang.String) pResult);
          return;
        }
        break;
      case 5:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XZQHMC".equals(pLocalName)) {
          _1.setXZQHMC((java.lang.String) pResult);
          return;
        }
        break;
      case 6:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "FRDB".equals(pLocalName)) {
          _1.setFRDB((java.lang.String) pResult);
          return;
        }
        break;
      case 7:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "JYXKZH".equals(pLocalName)) {
          _1.setJYXKZH((java.lang.String) pResult);
          return;
        }
        break;
      case 8:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "JYFW".equals(pLocalName)) {
          _1.setJYFW((java.lang.String) pResult);
          return;
        }
        break;
      case 9:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "JYFWDM".equals(pLocalName)) {
          _1.setJYFWDM((java.lang.String) pResult);
          return;
        }
        break;
      case 10:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "JJLX".equals(pLocalName)) {
          _1.setJJLX((java.lang.String) pResult);
          return;
        }
        break;
      case 11:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "JJLX_NAME".equals(pLocalName)) {
          _1.setJJLXNAME((java.lang.String) pResult);
          return;
        }
        break;
      case 12:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "HFRQ".equals(pLocalName)) {
          try {
            java.lang.String _2 = (java.lang.String) pResult;
            java.text.ParsePosition _3 = new java.text.ParsePosition(0);
            java.lang.Object _4 = ((org.apache.ws.jaxme.impl.JMUnmarshallerImpl) getHandler().getJMUnmarshaller()).getDateTimeFormat().parseObject(_2, _3);
            if (_4 == null) {
              throw new java.lang.IllegalArgumentException("Failed to parse dateTime " + _2 + " at: " + _2.substring(_3.getErrorIndex()));
            }
            java.util.Calendar _5;
            if (_4 instanceof java.util.Calendar) {
              _5 = (java.util.Calendar) _4;
            } else {
              _5 = java.util.Calendar.getInstance();
              _5.setTime((java.util.Date) _4);
            }
            _1.setHFRQ(_5);
          } catch (java.lang.Exception _6) {
            getHandler().parseConversionEvent("Failed to convert value of HFRQ: " + pResult, _6);
          }
          return;
        }
        break;
      case 13:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "ZCRQ".equals(pLocalName)) {
          try {
            java.lang.String _7 = (java.lang.String) pResult;
            java.text.ParsePosition _8 = new java.text.ParsePosition(0);
            java.lang.Object _9 = ((org.apache.ws.jaxme.impl.JMUnmarshallerImpl) getHandler().getJMUnmarshaller()).getDateTimeFormat().parseObject(_7, _8);
            if (_9 == null) {
              throw new java.lang.IllegalArgumentException("Failed to parse dateTime " + _7 + " at: " + _7.substring(_8.getErrorIndex()));
            }
            java.util.Calendar _10;
            if (_9 instanceof java.util.Calendar) {
              _10 = (java.util.Calendar) _9;
            } else {
              _10 = java.util.Calendar.getInstance();
              _10.setTime((java.util.Date) _9);
            }
            _1.setZCRQ(_10);
          } catch (java.lang.Exception _11) {
            getHandler().parseConversionEvent("Failed to convert value of ZCRQ: " + pResult, _11);
          }
          return;
        }
        break;
      case 14:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "YXQQ".equals(pLocalName)) {
          try {
            java.lang.String _12 = (java.lang.String) pResult;
            java.text.ParsePosition _13 = new java.text.ParsePosition(0);
            java.lang.Object _14 = ((org.apache.ws.jaxme.impl.JMUnmarshallerImpl) getHandler().getJMUnmarshaller()).getDateTimeFormat().parseObject(_12, _13);
            if (_14 == null) {
              throw new java.lang.IllegalArgumentException("Failed to parse dateTime " + _12 + " at: " + _12.substring(_13.getErrorIndex()));
            }
            java.util.Calendar _15;
            if (_14 instanceof java.util.Calendar) {
              _15 = (java.util.Calendar) _14;
            } else {
              _15 = java.util.Calendar.getInstance();
              _15.setTime((java.util.Date) _14);
            }
            _1.setYXQQ(_15);
          } catch (java.lang.Exception _16) {
            getHandler().parseConversionEvent("Failed to convert value of YXQQ: " + pResult, _16);
          }
          return;
        }
        break;
      case 15:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "YXQZ".equals(pLocalName)) {
          try {
            java.lang.String _17 = (java.lang.String) pResult;
            java.text.ParsePosition _18 = new java.text.ParsePosition(0);
            java.lang.Object _19 = ((org.apache.ws.jaxme.impl.JMUnmarshallerImpl) getHandler().getJMUnmarshaller()).getDateTimeFormat().parseObject(_17, _18);
            if (_19 == null) {
              throw new java.lang.IllegalArgumentException("Failed to parse dateTime " + _17 + " at: " + _17.substring(_18.getErrorIndex()));
            }
            java.util.Calendar _20;
            if (_19 instanceof java.util.Calendar) {
              _20 = (java.util.Calendar) _19;
            } else {
              _20 = java.util.Calendar.getInstance();
              _20.setTime((java.util.Date) _19);
            }
            _1.setYXQZ(_20);
          } catch (java.lang.Exception _21) {
            getHandler().parseConversionEvent("Failed to convert value of YXQZ: " + pResult, _21);
          }
          return;
        }
        break;
      case 16:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "MEMO".equals(pLocalName)) {
          _1.setMEMO((java.lang.String) pResult);
          return;
        }
        break;
      default:
        throw new java.lang.IllegalStateException("Illegal state: " + __state);
    }
  }

  public boolean isFinished() {
    switch (__state) {
      case 16:
      case 15:
      case 14:
      case 13:
      case 12:
      case 11:
      case 10:
      case 9:
      case 8:
      case 7:
      case 6:
      case 5:
      case 4:
      case 3:
      case 2:
      case 1:
        return true;
      default:
        return false;
    }
  }

}
