/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.inbound.yh_jyyhxx;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;
import com.tongtech.ti.adapter.database.*;
import com.tongtech.ti.adapter.common.service.*;
import com.tongtech.ti.management.jms.LoadMetadata;
import org.apache.ws.jaxme.generator.sg.DataObject;
import com.tongtech.ti.esbcore.tongutil.*;
import com.tongtech.ti.adapter.jdbc.util.*;
import com.tongtech.ti.adapter.jdbc.util.midprocess.*;
import com.tongtech.ti.adapter.jdbc.configinfo.DOProperty;
import com.tongtech.ti.adapter.jdbc.util.midprocess.TongResultSet;
import com.tongtech.ti.adapter.database.JdbcSourceEventMessage;
import javax.ejb.MessageDrivenContext;
import com.tongtech.ti.adapter.database.DatabaseInboundWork;
import com.tongtech.ti.adapter.database.service.DBIBAdapterBeanBase;
import org.apache.ws.jaxme.generator.sg.*;
import javax.ejb.EJBException;
import com.tongtech.ti.adapter.common.AdapterException;

public class Yh_Jyyhxx extends DBIBAdapterBeanBase implements MessageDrivenBean,DatabaseListener,ServiceConstants{

	/**
	 * ���ݶ��󹤳�
	 */
	protected static zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.ObjectFactory z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu_doOF = null;
	/**
	 * ���ݶ��󹤳�
	 */
	protected static zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.ObjectFactory z_yh_jyyhxx_d_do_z_yh_jyyhxx_d_doOF = null;

	/**
	 * ���ʼ��ʱ�������ݶ��󹤳���ʵ��
	 */
	static{
		try {
			z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu_doOF = new zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.ObjectFactory();
			z_yh_jyyhxx_d_do_z_yh_jyyhxx_d_doOF = new zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.ObjectFactory();
		}
		catch(Exception e){
			classLogger.error("�������ݶ��󹤳�ʧ��",e);
		}
	}

	/**
	 * ���캯��
	 */
	public  Yh_Jyyhxx() {
		super();
	}
	
	/**
	 * EJB��ʼ������
	 */	
	public  void ejbCreate() {
		_ejbCreate();
		initCallFlags("onZ_yh_jyyhxx_iu", "z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu");
		initCallFlags("onZ_yh_jyyhxx_d", "z_yh_jyyhxx_d_do_z_yh_jyyhxx_d");
	}

	/**
	 * �������ݶ���
	 * 
	 * @param sDoTypeaName, ���ݶ�������
	 */
	public DataObject createDO(String sDoTypeaName)throws java.lang.Exception{
		DataObject userDataObj = null;
		if(sDoTypeaName.equalsIgnoreCase("z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu")){
			userDataObj =  z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu_doOF.createDoZYhJyyhxxIu();
		}
		else if(sDoTypeaName.equalsIgnoreCase("z_yh_jyyhxx_d_do_z_yh_jyyhxx_d")){
			userDataObj =  z_yh_jyyhxx_d_do_z_yh_jyyhxx_d_doOF.createDoZYhJyyhxxD();
		}
		return userDataObj;
	}
	
	/**
	 * ��������е�һ����¼ת��Ϊ���ݶ����һ����¼
	 * @param sDoTypeaName, ���ݶ�������
	 * @param tongRS, �����
	 * @return ��¼
	 */
	public DataObject RS2RecordsDOList(String sDoTypeaName, TongResultSet tongRS)throws java.lang.Exception{
		DataObject record = null;

		if (sDoTypeaName.equals("z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu")){
			record=RS2Records4z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu(tongRS);
		}
		
		else if (sDoTypeaName.equals("z_yh_jyyhxx_d_do_z_yh_jyyhxx_d")){
			record=RS2Records4z_yh_jyyhxx_d_do_z_yh_jyyhxx_d(tongRS);
		}
		
		return record;
	}
	
		
	/**
	 * ����¼���ӵ����ݶ�����
	 *
	 * @param sDoTypeaName, ���ݶ�������
	 * @param userDataObj, ���ݶ���
	 * @param record, ��¼ 
	 */		
	public  void addRecordToDo(String sDoTypeaName,DataObject userDataObj,DataObject record) {
		if(sDoTypeaName.equalsIgnoreCase("z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu")){
			((zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.DoZYhJyyhxxIu)userDataObj).getRecord().add(record);
		}
		else if(sDoTypeaName.equalsIgnoreCase("z_yh_jyyhxx_d_do_z_yh_jyyhxx_d")){
			((zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.DoZYhJyyhxxD)userDataObj).getRecord().add(record);
		}
	}

	/**
	 * ��������е�һ����¼ת��Ϊ���ݶ����һ����¼
	 * @param rs, �����
	 * @return ��¼
	 */
	public  zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record RSRecord2DO4z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu(TongResultSet rs) throws java.lang.Exception{
		zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record recordDO = z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu_doOF.createRecord();
		recordDO.setYHID(rs.getString(1));
		recordDO.setYHMC(rs.getString(2));
		recordDO.setYEHUDZ(rs.getString(3));
		recordDO.setXZQHDM(rs.getString(4));
		recordDO.setXZQHMC(rs.getString(5));
		recordDO.setFRDB(rs.getString(6));
		recordDO.setJYXKZH(rs.getString(7));
		recordDO.setJYFW(rs.getString(8));
		recordDO.setJYFWDM(rs.getString(9));
		recordDO.setJJLX(rs.getString(10));
		recordDO.setJJLXNAME(rs.getString(11));
		java.sql.Timestamp varVal11=rs.getTongDateTime(12);
		if (varVal11!= null){
			Calendar cal = JdbcUtil.getCalendarInstance();
			cal.setTimeInMillis(varVal11.getTime());
			recordDO.setHFRQ(cal);
		}
		java.sql.Timestamp varVal12=rs.getTongDateTime(13);
		if (varVal12!= null){
			Calendar cal = JdbcUtil.getCalendarInstance();
			cal.setTimeInMillis(varVal12.getTime());
			recordDO.setZCRQ(cal);
		}
		java.sql.Timestamp varVal13=rs.getTongDateTime(14);
		if (varVal13!= null){
			Calendar cal = JdbcUtil.getCalendarInstance();
			cal.setTimeInMillis(varVal13.getTime());
			recordDO.setYXQQ(cal);
		}
		java.sql.Timestamp varVal14=rs.getTongDateTime(15);
		if (varVal14!= null){
			Calendar cal = JdbcUtil.getCalendarInstance();
			cal.setTimeInMillis(varVal14.getTime());
			recordDO.setYXQZ(cal);
		}
		recordDO.setMEMO(rs.getString(16));
		return recordDO;
	}

	/**
	 * �������ת��Ϊ���ݶ���
	 * @param rs, �����
	 */	
	public org.apache.ws.jaxme.generator.sg.DataObject RS2Records4z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu(TongResultSet rs) throws java.lang.Exception{
		try{
			return RSRecord2DO4z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu(rs);
		} catch (Exception e){
			logger.error(e.getMessage(),e);

			//alert
			sendAlert(AdapterException.ERROR_TYPE_INTERNAL, "�ӽ�����γ�DOʧ��", e);
			throw new Exception("�ӽ�����γ�DOʧ��");
		}
	}
	
	/**
	 * ��������е�һ����¼ת��Ϊ���ݶ����һ����¼
	 * @param rs, �����
	 * @return ��¼
	 */
	public  zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.Record RSRecord2DO4z_yh_jyyhxx_d_do_z_yh_jyyhxx_d(TongResultSet rs) throws java.lang.Exception{
		zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.Record recordDO = z_yh_jyyhxx_d_do_z_yh_jyyhxx_d_doOF.createRecord();
		recordDO.setYHID(rs.getString(1));
		return recordDO;
	}

	/**
	 * �������ת��Ϊ���ݶ���
	 * @param rs, �����
	 */	
	public org.apache.ws.jaxme.generator.sg.DataObject RS2Records4z_yh_jyyhxx_d_do_z_yh_jyyhxx_d(TongResultSet rs) throws java.lang.Exception{
		try{
			return RSRecord2DO4z_yh_jyyhxx_d_do_z_yh_jyyhxx_d(rs);
		} catch (Exception e){
			logger.error(e.getMessage(),e);

			//alert
			sendAlert(AdapterException.ERROR_TYPE_INTERNAL, "�ӽ�����γ�DOʧ��", e);
			throw new Exception("�ӽ�����γ�DOʧ��");
		}
	}
	
	
	/**
	 * �����¼��ķ���ӿڣ�ISSO��
	 * @param sDoTypeaName, ���ݶ�������
	 * @param userDataObject, ���ݶ���
	 */
	public  int callSI(String sDoTypeaName,DataObject userDataObj) {
		int result = 0;
		LoadMetadata lm = null; // ��أ�������Ϣ
		
		if (logger.isDebugEnabled()) {
			logger.debug("sDoTypeaName:"+sDoTypeaName);
		}
		
		//��ȡ�Ƿ�����¼��ı�־
		Boolean callnextFlag = (Boolean)callflag.get(sDoTypeaName);
		boolean callnext = (null != callnextFlag)?callnextFlag.booleanValue():false;

		//��������ã�ֱ�ӷ���
		if (!callnext){
			logger.warn("�������¼����񲻴�����do���ͣ�"+sDoTypeaName);
			return 0;
		}			
		

		String exportOpName = null;
		String operationType = getDBOperationType();
		try{
			if(sDoTypeaName.equalsIgnoreCase("z_yh_jyyhxx_iu_do_z_yh_jyyhxx_iu")){
				//�������̸���ID
				processTrace();
				
				exportOpName = "z_yh_jyyhxx_iu";
				
				startProcessInfo(exportOpName, operationType, exportOpName, userDataObj, getStartTime().longValue()); //���̸�����־
				
				lm = beforeOperation("onZ_yh_jyyhxx_iu",userDataObj);// ��أ���ʼʱ���и�����Ϣ׼��
				zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.sid.z_yh_jyyhxx_iu.Z_yh_jyyhxx_iu isso = new zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.sid.z_yh_jyyhxx_iu.Z_yh_jyyhxx_iu(this);
				zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.sid.z_yh_jyyhxx_iu.Z_yh_jyyhxx_iu.Z_yh_jyyhxx_iu_onZ_yh_jyyhxx_iu onZ_yh_jyyhxx_iuOperation = isso.getZ_yh_jyyhxx_iu_onZ_yh_jyyhxx_iu();
				onZ_yh_jyyhxx_iuOperation.setInput((zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.DoZYhJyyhxxIu)userDataObj);
				result = onZ_yh_jyyhxx_iuOperation.invoke();
				if (logger.isDebugEnabled()) {
					logger.debug("invoke db operation method of isso is " + ((result == -1)?"failed":"Sucessed"));
				}
				afterOperation(lm, (result == 0)?LoadMetadata.OP_SUCCESS:LoadMetadata.OP_FAILED); //��أ�����ʱ���и�����Ϣ����
				
				endProcessInfo(exportOpName, operationType, exportOpName, 0, 0, (result == 0)?true:false); //���̸�����־
			}
			else if(sDoTypeaName.equalsIgnoreCase("z_yh_jyyhxx_d_do_z_yh_jyyhxx_d")){
				//�������̸���ID
				processTrace();
				
				exportOpName = "z_yh_jyyhxx_d";
				
				startProcessInfo(exportOpName, operationType, exportOpName, userDataObj, getStartTime().longValue()); //���̸�����־
				
				lm = beforeOperation("onZ_yh_jyyhxx_d",userDataObj);// ��أ���ʼʱ���и�����Ϣ׼��
				zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.sid.z_yh_jyyhxx_d.Z_yh_jyyhxx_d isso = new zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.sid.z_yh_jyyhxx_d.Z_yh_jyyhxx_d(this);
				zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.sid.z_yh_jyyhxx_d.Z_yh_jyyhxx_d.Z_yh_jyyhxx_d_onZ_yh_jyyhxx_d onZ_yh_jyyhxx_dOperation = isso.getZ_yh_jyyhxx_d_onZ_yh_jyyhxx_d();
				onZ_yh_jyyhxx_dOperation.setInput((zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.DoZYhJyyhxxD)userDataObj);
				result = onZ_yh_jyyhxx_dOperation.invoke();
				if (logger.isDebugEnabled()) {
					logger.debug("invoke db operation method of isso is " + ((result == -1)?"failed":"Sucessed"));
				}
				afterOperation(lm, (result == 0)?LoadMetadata.OP_SUCCESS:LoadMetadata.OP_FAILED); //��أ�����ʱ���и�����Ϣ����
				
				endProcessInfo(exportOpName, operationType, exportOpName, 0, 0, (result == 0)?true:false); //���̸�����־
			}
		}catch (TongESBException esbException){
			result = -1;
			sendAlert(AdapterException.ERROR_TYPE_INBOUND, "����Java����ʧ��", esbException);
			afterOperation(lm, LoadMetadata.OP_FAILED); //��أ�����ʱ���и�����Ϣ����
			
			errorProcessInfo(exportOpName, operationType, exportOpName, esbException); //���̸�����־
		}
		setStartTime(System.currentTimeMillis());
		return result;
	}

}
