/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.outbound.ao_out_yh_jyyhxx_iu;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import com.tongtech.ti.adapter.jdbc.util.midprocess.LobCreator;
import com.tongtech.ti.adapter.jdbc.util.midprocess.OracleLobHandler;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterBase;

/**
 * ���³�վ�������Ĺ�����
 */
public class AOOut_yh_jyyhxx_iuBase extends JdbcAdapterBase {

	SimpleDateFormat sdf = null;

	/**
	 * ���ݶ��󹤳�
	 */
	protected static zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.ObjectFactory yh_jyyhxx_doZYhJyyhxxIu_doOF = null;

	/**
	 * ���ʼ��ʱ�������ݶ��󹤳���ʵ��
	 */
	static {
		try {
			yh_jyyhxx_doZYhJyyhxxIu_doOF = new zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.ObjectFactory();
		} catch(Exception e) {
			classLogger.error("�������ݶ��󹤳�ʧ��",e);
		}
	}

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 */
	public AOOut_yh_jyyhxx_iuBase(InterfaceComponent ic) {
		super(ic);
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 * @param aoname, ���������������
	 */
	public AOOut_yh_jyyhxx_iuBase(InterfaceComponent ic, String aoname) {
		super(ic, aoname);
		
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public boolean yh_jyyhxx(zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.DoZYhJyyhxxIu doZYhJyyhxxIu ) {
		String sqlStr = "update ZHJTADMIN.\"Z_YH_JYYHXX\" set \"YHID\"=?,\"YHMC\"=?,\"YHDZ\"=?,\"XZQHDM\"=?,\"XZQHMC\"=?,\"FDDBR\"=?,\"JYXKZH\"=?,\"JYFW\"=?,\"JYFWDM\"=?,\"JJLXDM\"=?,\"JJLXMC\"=?,\"HFRQ\"=?,\"ZCRQ\"=?,\"JYXKZYXQQ\"=?,\"JYXKZYXQZ\"=?,\"BZ\"=? where  (\"YHID\" = ?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("update SQL : " + sqlStr);
		String sqlInsert = "insert into ZHJTADMIN.\"Z_YH_JYYHXX\"(\"YHID\",\"YHMC\",\"YHDZ\",\"XZQHDM\",\"XZQHMC\",\"FDDBR\",\"JYXKZH\",\"JYFW\",\"JYFWDM\",\"JJLXDM\",\"JJLXMC\",\"HFRQ\",\"ZCRQ\",\"JYXKZYXQQ\",\"JYXKZYXQZ\",\"BZ\") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("INSERT FOR UPDATE SQL : " + sqlInsert);
		zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record record = null;
		int idx=0;
		int paramIdx = 1;
		PreparedStatement pstmt = null;
		PreparedStatement pcyclestmt = null;			
		try {
			pstmt = conn.prepareStatement(sqlStr);
			for (Iterator iter = doZYhJyyhxxIu.getRecord().iterator(); iter.hasNext();) {
				record = (zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record)iter.next();
		
				pstmt.clearParameters();	
		paramIdx = 1;

		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYHID(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYHMC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYEHUDZ(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXZQHDM(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXZQHMC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getFRDB(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJYXKZH(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJYFW(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJYFWDM(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJJLX(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJJLXNAME(),fromCharSet,toCharSet));			
		pstmt.setTimestamp(paramIdx++,calendar2Timestamp(record.getHFRQ()));			
		pstmt.setTimestamp(paramIdx++,calendar2Timestamp(record.getZCRQ()));			
		pstmt.setTimestamp(paramIdx++,calendar2Timestamp(record.getYXQQ()));			
		pstmt.setTimestamp(paramIdx++,calendar2Timestamp(record.getYXQZ()));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getMEMO(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYHID(),fromCharSet,toCharSet));			
				int rst = -1;
				int n = 0;
				java.sql.SQLException sqlException = null;
				while (n<maxDeadlockRetry) {
					try {
						rst = pstmt.executeUpdate();
						break;
					} catch (java.sql.SQLException sqle){
						if (isCanRetry(sqle)){
							n++;
							try	{
								ic.getLogger().warn(sqle);
								ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
								Thread.sleep(deadlockRetryDelay);
							} catch (Exception ex) {
							} 
						} else {
							ic.getLogger().error("ִ��SQL���["+sqlStr+"]����",sqle);
							throw sqle;
						}
					}
				}
				if (n== maxDeadlockRetry) {
					ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
					throw sqlException;
				}	
				
				if (rst==0) {
					PreparedStatement pstmtIns = null;
					try {
					pstmtIns = conn.prepareStatement(sqlInsert);
		paramIdx = 1;

		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYHID(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYHMC(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getYEHUDZ(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXZQHDM(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXZQHMC(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getFRDB(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJYXKZH(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJYFW(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJYFWDM(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJJLX(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getJJLXNAME(),fromCharSet,toCharSet));			
		pstmtIns.setTimestamp(paramIdx++,calendar2Timestamp(record.getHFRQ()));			
		pstmtIns.setTimestamp(paramIdx++,calendar2Timestamp(record.getZCRQ()));			
		pstmtIns.setTimestamp(paramIdx++,calendar2Timestamp(record.getYXQQ()));			
		pstmtIns.setTimestamp(paramIdx++,calendar2Timestamp(record.getYXQZ()));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getMEMO(),fromCharSet,toCharSet));			
					
					n = 0;
					while (n<maxDeadlockRetry) {
						try {
							pstmtIns.execute();
							break;
						} catch (java.sql.SQLException sqle) {
							sqlException = sqle;
							if (isCanRetry(sqle)) {
								n++;
								try	{
									ic.getLogger().warn(sqle);
									ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
									Thread.sleep(deadlockRetryDelay);
								} catch (Exception ex) {
								} 
							} else {
								ic.getLogger().warn("ִ��SQL���["+sqlInsert+"]����",sqle);
								throw sqle;
							}
						}
					}
					if (n == maxDeadlockRetry) {
						ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
						throw sqlException;
					}	
					} finally {
						if (pstmtIns!=null){
							try {
								pstmtIns.close();
							} catch (Exception e){
								ic.getLogger().warn("Close PreparedStatement[pstmtIns] error",e);
				}
						}
					}
				}
				
				
				idx++;
			}
			
			return true;//�ɹ�����true
		} catch (Exception e) {
			//ic.getLogger().error(e.getMessage(),e);
			this.faultMsg = e.toString()+";SQL:"+sqlStr+";ErrorData: "+Do2String(record);
			this.faultMsg = this.faultMsg.replaceAll("\n", "");

			boolean isAutoCommit = false;
			zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.DoZYhJyyhxxIu errorDO = null ;
			try {
				if (isStopProcessOnException(e)) {
					isAutoCommit = conn.getAutoCommit();
					if (isAutoCommit) {
						int count=0;
						errorDO = yh_jyyhxx_doZYhJyyhxxIu_doOF.createDoZYhJyyhxxIu();
						for (java.util.Iterator iter = doZYhJyyhxxIu.getRecord().iterator(); iter.hasNext();) {
							zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record rec = (zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record)iter.next();
							if (count>=idx) {
								List records = errorDO.getRecord();
								if (records==null) records = new ArrayList();
								records.add(rec);
							}
							count++;
						}
						
						com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"doZYhJyyhxxIu",ic,e);
						this.faultCode = -3;
						return false;//ʧ�ܣ��Զ��ύ��ֹͣ����
					} else {
						if (isRollbackOnException()) {
							this.faultCode = -2;
							return false;//ʧ�ܣ��ع���ֹͣ����
						} else {
							int count=0;
							errorDO = yh_jyyhxx_doZYhJyyhxxIu_doOF.createDoZYhJyyhxxIu();
							for (java.util.Iterator iter = doZYhJyyhxxIu.getRecord().iterator(); iter.hasNext();) {
								zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record rec = (zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record)iter.next();
								if (count>=idx) {
									List records = errorDO.getRecord();
									if (records==null) records = new ArrayList();
									records.add(rec);
								}
								count++;
							}
							com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"doZYhJyyhxxIu",ic,e);
							this.faultCode = -3;
							return false;//ʧ�ܣ����ع���ֹͣ����
						}
						//errorDO = doZYhJyyhxxIu;
					}
				} else {//���ǿ�ֹͣ�ķ���-1
					this.faultCode = -1;
					return false;
				}
			} catch(Exception e1) {
				ic.getLogger().error(e1.getMessage(),e1);
				this.faultCode = -1;
				return false;
			}
		} finally {
			if (pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					ic.getLogger().error("close pstmt error.",e);
				}
			}
				}
	} 
	
	
}
