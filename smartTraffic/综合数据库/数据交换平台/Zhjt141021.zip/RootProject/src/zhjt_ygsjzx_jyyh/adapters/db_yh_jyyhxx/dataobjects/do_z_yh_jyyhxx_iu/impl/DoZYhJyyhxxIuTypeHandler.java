package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.impl;

public class DoZYhJyyhxxIuTypeHandler extends org.apache.ws.jaxme.impl.JMSAXElementParser {
  /** The current state. The following values are valid states:
   *  0 = Before parsing the element
   *  1 = While or after parsing the child element {http://www.tongtech.ti/dbrecord/do_z_yh_jyyhxx_iu}Record
   * 
   */
  private int __state;


  public boolean startElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler = getHandler();
    switch (__state) {
      case 0:
        return processCase0(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 1:
        return processCase1(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      default:
        throw new java.lang.IllegalStateException("Invalid state: " + __state);
    }
  }

  private boolean processCase0(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ("http://www.tongtech.ti/dbrecord/do_z_yh_jyyhxx_iu".equals(pNamespaceURI)  &&  "Record".equals(pLocalName)) {
      __state = 1;
      org.apache.ws.jaxme.JMManager _1 = getHandler().getJMUnmarshaller().getJAXBContextImpl().getManagerS(zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record.class);
      java.lang.Object _2 = _1.getElementS();
      org.apache.ws.jaxme.impl.JMSAXElementParser _3 = _1.getHandler();
      _3.init(unmarshallerHandler, _2, "http://www.tongtech.ti/dbrecord/do_z_yh_jyyhxx_iu", "Record", unmarshallerHandler.getLevel());
      _3.setAttributes(pAttr);
      unmarshallerHandler.addElementParser(_3);
      return true;
    }
    return false;
  }

  private boolean processCase1(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ("http://www.tongtech.ti/dbrecord/do_z_yh_jyyhxx_iu".equals(pNamespaceURI)  &&  "Record".equals(pLocalName)) {
      __state = 1;
      org.apache.ws.jaxme.JMManager _1 = getHandler().getJMUnmarshaller().getJAXBContextImpl().getManagerS(zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.Record.class);
      java.lang.Object _2 = _1.getElementS();
      org.apache.ws.jaxme.impl.JMSAXElementParser _3 = _1.getHandler();
      _3.init(unmarshallerHandler, _2, "http://www.tongtech.ti/dbrecord/do_z_yh_jyyhxx_iu", "Record", unmarshallerHandler.getLevel());
      _3.setAttributes(pAttr);
      unmarshallerHandler.addElementParser(_3);
      return true;
    }
    return false;
  }

  public void endElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, java.lang.Object pResult) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.DoZYhJyyhxxIuType _1 = (zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_iu.DoZYhJyyhxxIuType) result;
    switch (__state) {
      case 1:
        if ("http://www.tongtech.ti/dbrecord/do_z_yh_jyyhxx_iu".equals(pNamespaceURI)  &&  "Record".equals(pLocalName)) {
          _1.getRecord().add(pResult);
          return;
        }
        break;
      default:
        throw new java.lang.IllegalStateException("Illegal state: " + __state);
    }
  }

  public boolean isFinished() {
    switch (__state) {
      case 1:
      case 0:
        return true;
      default:
        return false;
    }
  }

}
