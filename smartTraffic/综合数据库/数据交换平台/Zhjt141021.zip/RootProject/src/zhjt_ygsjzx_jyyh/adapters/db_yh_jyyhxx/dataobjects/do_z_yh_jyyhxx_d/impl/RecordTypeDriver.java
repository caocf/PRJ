package zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.RecordType _1 = (zhjt_ygsjzx_jyyh.adapters.db_yh_jyyhxx.dataobjects.do_z_yh_jyyhxx_d.RecordType) pObject;
    java.lang.String _2 = _1.getYHID();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "YHID", _1.getYHID());
    }
  }

}
