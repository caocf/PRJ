package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.RecordType {
  private java.math.BigDecimal _bH;


  public java.math.BigDecimal getBH() {
    return _bH;
  }

  public void setBH(java.math.BigDecimal pBH) {
    _bH = pBH;
  }

}
