package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.impl;

public class RecordTypeHandler extends org.apache.ws.jaxme.impl.JMSAXElementParser {
  /** The current state. The following values are valid states:
   *  0 = Before parsing the element
   *  1 = While or after parsing the child element XLBH
   *  2 = While or after parsing the child element FX
   *  3 = While or after parsing the child element GJXH
   *  4 = While or after parsing the child element QDJL
   *  5 = While or after parsing the child element JD
   *  6 = While or after parsing the child element WD
   * 
   */
  private int __state;


  public boolean startElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler = getHandler();
    switch (__state) {
      case 0:
        return processCase0(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 1:
        return processCase1(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 2:
        return processCase2(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 3:
        return processCase3(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 4:
        return processCase4(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 5:
        return processCase5(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 6:
        return processCase6(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      default:
        throw new java.lang.IllegalStateException("Invalid state: " + __state);
    }
  }

  private boolean processCase0(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLBH".equals(pLocalName)) {
      __state = 1;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase1(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "FX".equals(pLocalName)) {
      __state = 2;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase2(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GJXH".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase3(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QDJL".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase4(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "JD".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase5(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "WD".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase6(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    return false;
  }

  public void endElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, java.lang.Object pResult) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.RecordType _1 = (zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.RecordType) result;
    switch (__state) {
      case 1:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLBH".equals(pLocalName)) {
          try {
            _1.setXLBH(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _2) {
            getHandler().parseConversionEvent("Failed to convert value of XLBH: " + pResult, _2);
          }
          return;
        }
        break;
      case 2:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "FX".equals(pLocalName)) {
          try {
            _1.setFX(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _3) {
            getHandler().parseConversionEvent("Failed to convert value of FX: " + pResult, _3);
          }
          return;
        }
        break;
      case 3:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "GJXH".equals(pLocalName)) {
          try {
            _1.setGJXH(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _4) {
            getHandler().parseConversionEvent("Failed to convert value of GJXH: " + pResult, _4);
          }
          return;
        }
        break;
      case 4:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "QDJL".equals(pLocalName)) {
          try {
            _1.setQDJL(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _5) {
            getHandler().parseConversionEvent("Failed to convert value of QDJL: " + pResult, _5);
          }
          return;
        }
        break;
      case 5:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "JD".equals(pLocalName)) {
          _1.setJD((java.lang.String) pResult);
          return;
        }
        break;
      case 6:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "WD".equals(pLocalName)) {
          _1.setWD((java.lang.String) pResult);
          return;
        }
        break;
      default:
        throw new java.lang.IllegalStateException("Illegal state: " + __state);
    }
  }

  public boolean isFinished() {
    switch (__state) {
      case 6:
        return true;
      default:
        return false;
    }
  }

}
