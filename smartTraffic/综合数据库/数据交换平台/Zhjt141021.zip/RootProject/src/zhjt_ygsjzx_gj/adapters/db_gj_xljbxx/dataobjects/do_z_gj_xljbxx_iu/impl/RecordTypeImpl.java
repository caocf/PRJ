package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.RecordType {
  private java.math.BigDecimal _xLBH;

  private java.lang.String _xLMC;

  private java.lang.String _xLJC;

  private java.lang.String _xLLX;

  private java.math.BigDecimal _xLTDLX;

  private java.math.BigDecimal _xLKTLX;

  private java.math.BigDecimal _xLSPLX;

  private java.math.BigDecimal _sFHX;

  private java.lang.String _kTJG;

  private java.lang.String _iC;

  private java.lang.String _sXSBSJ;

  private java.lang.String _sXMBSJ;

  private java.lang.String _xXSBSJ;

  private java.lang.String _xXMBSJ;

  private java.math.BigDecimal _pZLX;

  private java.math.BigDecimal _gS;

  private java.math.BigDecimal _qY;

  private java.math.BigDecimal _xLJPLX;


  public java.math.BigDecimal getXLBH() {
    return _xLBH;
  }

  public void setXLBH(java.math.BigDecimal pXLBH) {
    _xLBH = pXLBH;
  }

  public java.lang.String getXLMC() {
    return _xLMC;
  }

  public void setXLMC(java.lang.String pXLMC) {
    _xLMC = pXLMC;
  }

  public java.lang.String getXLJC() {
    return _xLJC;
  }

  public void setXLJC(java.lang.String pXLJC) {
    _xLJC = pXLJC;
  }

  public java.lang.String getXLLX() {
    return _xLLX;
  }

  public void setXLLX(java.lang.String pXLLX) {
    _xLLX = pXLLX;
  }

  public java.math.BigDecimal getXLTDLX() {
    return _xLTDLX;
  }

  public void setXLTDLX(java.math.BigDecimal pXLTDLX) {
    _xLTDLX = pXLTDLX;
  }

  public java.math.BigDecimal getXLKTLX() {
    return _xLKTLX;
  }

  public void setXLKTLX(java.math.BigDecimal pXLKTLX) {
    _xLKTLX = pXLKTLX;
  }

  public java.math.BigDecimal getXLSPLX() {
    return _xLSPLX;
  }

  public void setXLSPLX(java.math.BigDecimal pXLSPLX) {
    _xLSPLX = pXLSPLX;
  }

  public java.math.BigDecimal getSFHX() {
    return _sFHX;
  }

  public void setSFHX(java.math.BigDecimal pSFHX) {
    _sFHX = pSFHX;
  }

  public java.lang.String getKTJG() {
    return _kTJG;
  }

  public void setKTJG(java.lang.String pKTJG) {
    _kTJG = pKTJG;
  }

  public java.lang.String getIC() {
    return _iC;
  }

  public void setIC(java.lang.String pIC) {
    _iC = pIC;
  }

  public java.lang.String getSXSBSJ() {
    return _sXSBSJ;
  }

  public void setSXSBSJ(java.lang.String pSXSBSJ) {
    _sXSBSJ = pSXSBSJ;
  }

  public java.lang.String getSXMBSJ() {
    return _sXMBSJ;
  }

  public void setSXMBSJ(java.lang.String pSXMBSJ) {
    _sXMBSJ = pSXMBSJ;
  }

  public java.lang.String getXXSBSJ() {
    return _xXSBSJ;
  }

  public void setXXSBSJ(java.lang.String pXXSBSJ) {
    _xXSBSJ = pXXSBSJ;
  }

  public java.lang.String getXXMBSJ() {
    return _xXMBSJ;
  }

  public void setXXMBSJ(java.lang.String pXXMBSJ) {
    _xXMBSJ = pXXMBSJ;
  }

  public java.math.BigDecimal getPZLX() {
    return _pZLX;
  }

  public void setPZLX(java.math.BigDecimal pPZLX) {
    _pZLX = pPZLX;
  }

  public java.math.BigDecimal getGS() {
    return _gS;
  }

  public void setGS(java.math.BigDecimal pGS) {
    _gS = pGS;
  }

  public java.math.BigDecimal getQY() {
    return _qY;
  }

  public void setQY(java.math.BigDecimal pQY) {
    _qY = pQY;
  }

  public java.math.BigDecimal getXLJPLX() {
    return _xLJPLX;
  }

  public void setXLJPLX(java.math.BigDecimal pXLJPLX) {
    _xLJPLX = pXLJPLX;
  }

}
