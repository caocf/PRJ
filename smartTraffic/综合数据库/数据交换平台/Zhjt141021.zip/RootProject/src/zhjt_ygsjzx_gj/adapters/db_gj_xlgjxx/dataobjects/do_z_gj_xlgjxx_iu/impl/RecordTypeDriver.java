package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.RecordType _1 = (zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.RecordType) pObject;
    java.math.BigDecimal _2 = _1.getXLBH();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "XLBH", pController.getDatatypeConverter().printDecimal(_1.getXLBH()));
    }
    java.math.BigDecimal _3 = _1.getFX();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "FX", pController.getDatatypeConverter().printDecimal(_1.getFX()));
    }
    java.math.BigDecimal _4 = _1.getGJXH();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "GJXH", pController.getDatatypeConverter().printDecimal(_1.getGJXH()));
    }
    java.math.BigDecimal _5 = _1.getQDJL();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "QDJL", pController.getDatatypeConverter().printDecimal(_1.getQDJL()));
    }
    java.lang.String _6 = _1.getJD();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "JD", _1.getJD());
    }
    java.lang.String _7 = _1.getWD();
    if (_7 != null) {
      pController.marshalSimpleChild(this, "", "WD", _1.getWD());
    }
  }

}
