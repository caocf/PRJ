package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d.RecordType {
  private java.math.BigDecimal _xLBH;

  private java.math.BigDecimal _fX;

  private java.math.BigDecimal _gJXH;


  public java.math.BigDecimal getXLBH() {
    return _xLBH;
  }

  public void setXLBH(java.math.BigDecimal pXLBH) {
    _xLBH = pXLBH;
  }

  public java.math.BigDecimal getFX() {
    return _fX;
  }

  public void setFX(java.math.BigDecimal pFX) {
    _fX = pFX;
  }

  public java.math.BigDecimal getGJXH() {
    return _gJXH;
  }

  public void setGJXH(java.math.BigDecimal pGJXH) {
    _gJXH = pGJXH;
  }

}
