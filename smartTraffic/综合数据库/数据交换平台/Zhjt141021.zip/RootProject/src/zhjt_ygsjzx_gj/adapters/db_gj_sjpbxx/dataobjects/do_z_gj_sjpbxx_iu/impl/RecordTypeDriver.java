package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu.RecordType _1 = (zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu.RecordType) pObject;
    java.math.BigDecimal _2 = _1.getBH();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "BH", pController.getDatatypeConverter().printDecimal(_1.getBH()));
    }
    java.lang.String _3 = _1.getCPH();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "CPH", _1.getCPH());
    }
    java.math.BigDecimal _4 = _1.getCPYS();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "CPYS", pController.getDatatypeConverter().printDecimal(_1.getCPYS()));
    }
    java.math.BigDecimal _5 = _1.getXLBH();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "XLBH", pController.getDatatypeConverter().printDecimal(_1.getXLBH()));
    }
    java.math.BigDecimal _6 = _1.getFX();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "FX", pController.getDatatypeConverter().printDecimal(_1.getFX()));
    }
    java.math.BigDecimal _7 = _1.getRQ();
    if (_7 != null) {
      pController.marshalSimpleChild(this, "", "RQ", pController.getDatatypeConverter().printDecimal(_1.getRQ()));
    }
    java.util.Calendar _8 = _1.getFCSJ();
    if (_8 != null) {
      pController.marshalSimpleChild(this, "", "FCSJ", pController.getJMMarshaller().getDateTimeFormat().format(_1.getFCSJ()));
    }
    java.util.Calendar _9 = _1.getDZSJ();
    if (_9 != null) {
      pController.marshalSimpleChild(this, "", "DZSJ", pController.getJMMarshaller().getDateTimeFormat().format(_1.getDZSJ()));
    }
    java.math.BigDecimal _10 = _1.getJHBH();
    if (_10 != null) {
      pController.marshalSimpleChild(this, "", "JHBH", pController.getDatatypeConverter().printDecimal(_1.getJHBH()));
    }
  }

}
