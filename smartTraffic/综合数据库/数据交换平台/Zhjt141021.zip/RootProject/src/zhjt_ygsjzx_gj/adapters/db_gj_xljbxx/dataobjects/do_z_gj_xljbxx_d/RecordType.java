package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_d;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getXLBH();

  public void setXLBH(java.math.BigDecimal pXLBH);

}
