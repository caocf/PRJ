package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d;

public class ObjectFactory {
  private static org.apache.ws.jaxme.impl.JAXBContextImpl jaxbContext;

  private static javax.xml.bind.JAXBException jaxbEx;

  private java.util.Map properties;


  static {
    try {
      // initialized the context when class is initialing
      jaxbContext = (org.apache.ws.jaxme.impl.JAXBContextImpl) javax.xml.bind.JAXBContext.newInstance("zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d");
    } catch (javax.xml.bind.JAXBException e) {
      jaxbEx = e;
    }
  }

  public ObjectFactory() throws javax.xml.bind.JAXBException {
    // if the context is not initialized, throw a exception
    if (jaxbContext == null) {
      throw new javax.xml.bind.JAXBException(jaxbEx.getMessage(), jaxbEx.getErrorCode(), jaxbEx);
    }
  }

  public static javax.xml.bind.JAXBContext getContext() throws javax.xml.bind.JAXBException {
    // if the context is not initialized, throw a exception
    if (jaxbContext == null) {
      throw new javax.xml.bind.JAXBException(jaxbEx.getMessage(), jaxbEx.getErrorCode(), jaxbEx);
    }
    return jaxbContext;
  }

  public java.lang.Object newInstance(java.lang.Class pElementInterface) throws javax.xml.bind.JAXBException {
    return jaxbContext.getManager(pElementInterface).getElementJ();
  }

  public java.lang.Object getProperty(java.lang.String pName) {
    if (properties == null) {
      return null;
    }
    return properties.get(pName);
  }

  public void setProperty(java.lang.String pName, java.lang.Object pValue) {
    if (properties == null) {
      properties = new java.util.HashMap();
    }
    properties.put(pName, pValue);
  }

  public zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD createDoZGjSjpbxxD() throws javax.xml.bind.JAXBException {
    return (zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD) newInstance(zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD.class);
  }

  public zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.Record createRecord() throws javax.xml.bind.JAXBException {
    return (zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.Record) newInstance(zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.Record.class);
  }

// public zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxDType createDoZGjSjpbxxDType() throws javax.xml.bind.JAXBException;

// public zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.RecordType createRecordType() throws javax.xml.bind.JAXBException;

}
