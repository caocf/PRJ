package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d;

public interface Record extends javax.xml.bind.Element , zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.RecordType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject {
}
