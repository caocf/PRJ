package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.RecordType {
  private java.math.BigDecimal _zDBH;


  public java.math.BigDecimal getZDBH() {
    return _zDBH;
  }

  public void setZDBH(java.math.BigDecimal pZDBH) {
    _zDBH = pZDBH;
  }

}
