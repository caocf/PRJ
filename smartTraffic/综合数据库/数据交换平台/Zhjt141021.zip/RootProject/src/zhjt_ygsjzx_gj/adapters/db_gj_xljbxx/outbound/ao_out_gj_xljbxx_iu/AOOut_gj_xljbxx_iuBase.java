/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.outbound.ao_out_gj_xljbxx_iu;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import com.tongtech.ti.adapter.jdbc.util.midprocess.LobCreator;
import com.tongtech.ti.adapter.jdbc.util.midprocess.OracleLobHandler;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterBase;

/**
 * ���³�վ�������Ĺ�����
 */
public class AOOut_gj_xljbxx_iuBase extends JdbcAdapterBase {

	SimpleDateFormat sdf = null;

	/**
	 * ���ݶ��󹤳�
	 */
	protected static zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.ObjectFactory gj_xljbxx_doZGjXljbxxIu_doOF = null;

	/**
	 * ���ʼ��ʱ�������ݶ��󹤳���ʵ��
	 */
	static {
		try {
			gj_xljbxx_doZGjXljbxxIu_doOF = new zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.ObjectFactory();
		} catch(Exception e) {
			classLogger.error("�������ݶ��󹤳�ʧ��",e);
		}
	}

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 */
	public AOOut_gj_xljbxx_iuBase(InterfaceComponent ic) {
		super(ic);
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	

	/**
	 * �����������õĹ��캯��
	 * 
	 * @param ic,
	 * @param aoname, ���������������
	 */
	public AOOut_gj_xljbxx_iuBase(InterfaceComponent ic, String aoname) {
		super(ic, aoname);
		
		dbType = "oracle";
		jdbcAdapterType = JDBC_UPDATE;
	}	
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public boolean gj_xljbxx(zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu doZGjXljbxxIu ) {
		String sqlStr = "update ZHJTADMIN.\"Z_GJ_XLJBXX\" set \"XLBH\"=?,\"XLMC\"=?,\"XLJC\"=?,\"XLLXMC\"=?,\"XLTDFL\"=?,\"XLKTFWLB\"=?,\"SPFWLX\"=?,\"SFHX\"=?,\"KTJG\"=?,\"KSYICKZL\"=?,\"SXSBSJ\"=?,\"SXMBSJ\"=?,\"XXSBSJ\"=?,\"XXMBSJ\"=?,\"XLPZ\"=?,\"GS\"=?,\"QY\"=?,\"JPLX\"=? where  (\"XLBH\" = ?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("update SQL : " + sqlStr);
		String sqlInsert = "insert into ZHJTADMIN.\"Z_GJ_XLJBXX\"(\"XLBH\",\"XLMC\",\"XLJC\",\"XLLXMC\",\"XLTDFL\",\"XLKTFWLB\",\"SPFWLX\",\"SFHX\",\"KTJG\",\"KSYICKZL\",\"SXSBSJ\",\"SXMBSJ\",\"XXSBSJ\",\"XXMBSJ\",\"XLPZ\",\"GS\",\"QY\",\"JPLX\") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		if (ic.getLogger().isDebugEnabled())
			ic.getLogger().debug("INSERT FOR UPDATE SQL : " + sqlInsert);
		zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.Record record = null;
		int idx=0;
		int paramIdx = 1;
		PreparedStatement pstmt = null;
		PreparedStatement pcyclestmt = null;			
		try {
			pstmt = conn.prepareStatement(sqlStr);
			for (Iterator iter = doZGjXljbxxIu.getRecord().iterator(); iter.hasNext();) {
				record = (zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.Record)iter.next();
		
				pstmt.clearParameters();	
		paramIdx = 1;

		pstmt.setBigDecimal(paramIdx++,record.getXLBH());
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXLMC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXLJC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXLLX(),fromCharSet,toCharSet));			
		pstmt.setBigDecimal(paramIdx++,record.getXLTDLX());
		pstmt.setBigDecimal(paramIdx++,record.getXLKTLX());
		pstmt.setBigDecimal(paramIdx++,record.getXLSPLX());
		pstmt.setBigDecimal(paramIdx++,record.getSFHX());
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getKTJG(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getIC(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSXSBSJ(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSXMBSJ(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXXSBSJ(),fromCharSet,toCharSet));			
		pstmt.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXXMBSJ(),fromCharSet,toCharSet));			
		pstmt.setBigDecimal(paramIdx++,record.getPZLX());
		pstmt.setBigDecimal(paramIdx++,record.getGS());
		pstmt.setBigDecimal(paramIdx++,record.getQY());
		pstmt.setBigDecimal(paramIdx++,record.getXLJPLX());
		pstmt.setBigDecimal(paramIdx++,record.getXLBH());
				int rst = -1;
				int n = 0;
				java.sql.SQLException sqlException = null;
				while (n<maxDeadlockRetry) {
					try {
						rst = pstmt.executeUpdate();
						break;
					} catch (java.sql.SQLException sqle){
						if (isCanRetry(sqle)){
							n++;
							try	{
								ic.getLogger().warn(sqle);
								ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
								Thread.sleep(deadlockRetryDelay);
							} catch (Exception ex) {
							} 
						} else {
							ic.getLogger().error("ִ��SQL���["+sqlStr+"]����",sqle);
							throw sqle;
						}
					}
				}
				if (n== maxDeadlockRetry) {
					ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
					throw sqlException;
				}	
				
				if (rst==0) {
					PreparedStatement pstmtIns = null;
					try {
					pstmtIns = conn.prepareStatement(sqlInsert);
		paramIdx = 1;

		pstmtIns.setBigDecimal(paramIdx++,record.getXLBH());
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXLMC(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXLJC(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXLLX(),fromCharSet,toCharSet));			
		pstmtIns.setBigDecimal(paramIdx++,record.getXLTDLX());
		pstmtIns.setBigDecimal(paramIdx++,record.getXLKTLX());
		pstmtIns.setBigDecimal(paramIdx++,record.getXLSPLX());
		pstmtIns.setBigDecimal(paramIdx++,record.getSFHX());
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getKTJG(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getIC(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSXSBSJ(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getSXMBSJ(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXXSBSJ(),fromCharSet,toCharSet));			
		pstmtIns.setString(paramIdx++,com.tongtech.ti.adapter.jdbc.util.JdbcUtil.transCharSet(record.getXXMBSJ(),fromCharSet,toCharSet));			
		pstmtIns.setBigDecimal(paramIdx++,record.getPZLX());
		pstmtIns.setBigDecimal(paramIdx++,record.getGS());
		pstmtIns.setBigDecimal(paramIdx++,record.getQY());
		pstmtIns.setBigDecimal(paramIdx++,record.getXLJPLX());
					
					n = 0;
					while (n<maxDeadlockRetry) {
						try {
							pstmtIns.execute();
							break;
						} catch (java.sql.SQLException sqle) {
							sqlException = sqle;
							if (isCanRetry(sqle)) {
								n++;
								try	{
									ic.getLogger().warn(sqle);
									ic.getLogger().warn("ִ�����ݿ���������������쳣���ȴ�"+deadlockRetryDelay+"��������ԡ�");
									Thread.sleep(deadlockRetryDelay);
								} catch (Exception ex) {
								} 
							} else {
								ic.getLogger().warn("ִ��SQL���["+sqlInsert+"]����",sqle);
								throw sqle;
							}
						}
					}
					if (n == maxDeadlockRetry) {
						ic.getLogger().warn("�쳣���Դ����Ѿ��ﵽ�趨�����["+maxDeadlockRetry+"]��");
						throw sqlException;
					}	
					} finally {
						if (pstmtIns!=null){
							try {
								pstmtIns.close();
							} catch (Exception e){
								ic.getLogger().warn("Close PreparedStatement[pstmtIns] error",e);
				}
						}
					}
				}
				
				
				idx++;
			}
			
			return true;//�ɹ�����true
		} catch (Exception e) {
			//ic.getLogger().error(e.getMessage(),e);
			this.faultMsg = e.toString()+";SQL:"+sqlStr+";ErrorData: "+Do2String(record);
			this.faultMsg = this.faultMsg.replaceAll("\n", "");

			boolean isAutoCommit = false;
			zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu errorDO = null ;
			try {
				if (isStopProcessOnException(e)) {
					isAutoCommit = conn.getAutoCommit();
					if (isAutoCommit) {
						int count=0;
						errorDO = gj_xljbxx_doZGjXljbxxIu_doOF.createDoZGjXljbxxIu();
						for (java.util.Iterator iter = doZGjXljbxxIu.getRecord().iterator(); iter.hasNext();) {
							zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.Record rec = (zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.Record)iter.next();
							if (count>=idx) {
								List records = errorDO.getRecord();
								if (records==null) records = new ArrayList();
								records.add(rec);
							}
							count++;
						}
						
						com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"doZGjXljbxxIu",ic,e);
						this.faultCode = -3;
						return false;//ʧ�ܣ��Զ��ύ��ֹͣ����
					} else {
						if (isRollbackOnException()) {
							this.faultCode = -2;
							return false;//ʧ�ܣ��ع���ֹͣ����
						} else {
							int count=0;
							errorDO = gj_xljbxx_doZGjXljbxxIu_doOF.createDoZGjXljbxxIu();
							for (java.util.Iterator iter = doZGjXljbxxIu.getRecord().iterator(); iter.hasNext();) {
								zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.Record rec = (zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.Record)iter.next();
								if (count>=idx) {
									List records = errorDO.getRecord();
									if (records==null) records = new ArrayList();
									records.add(rec);
								}
								count++;
							}
							com.tongtech.ti.adapter.jdbc.util.JdbcUtil.saveErrorDBData(errorDO,record,"doZGjXljbxxIu",ic,e);
							this.faultCode = -3;
							return false;//ʧ�ܣ����ع���ֹͣ����
						}
						//errorDO = doZGjXljbxxIu;
					}
				} else {//���ǿ�ֹͣ�ķ���-1
					this.faultCode = -1;
					return false;
				}
			} catch(Exception e1) {
				ic.getLogger().error(e1.getMessage(),e1);
				this.faultCode = -1;
				return false;
			}
		} finally {
			if (pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					ic.getLogger().error("close pstmt error.",e);
				}
			}
				}
	} 
	
	
}
