package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu;

public interface DoZGjXljbxxIu extends javax.xml.bind.Element , zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIuType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject , org.apache.ws.jaxme.generator.sg.CalculateRecordCount {
}
