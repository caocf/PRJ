package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.impl;

public class RecordTypeHandler extends org.apache.ws.jaxme.impl.JMSAXElementParser {
  /** The current state. The following values are valid states:
   *  0 = Before parsing the element
   *  1 = While or after parsing the child element XLBH
   *  2 = While or after parsing the child element XLMC
   *  3 = While or after parsing the child element XLJC
   *  4 = While or after parsing the child element XLLX
   *  5 = While or after parsing the child element XLTDLX
   *  6 = While or after parsing the child element XLKTLX
   *  7 = While or after parsing the child element XLSPLX
   *  8 = While or after parsing the child element SFHX
   *  9 = While or after parsing the child element KTJG
   *  10 = While or after parsing the child element IC
   *  11 = While or after parsing the child element SXSBSJ
   *  12 = While or after parsing the child element SXMBSJ
   *  13 = While or after parsing the child element XXSBSJ
   *  14 = While or after parsing the child element XXMBSJ
   *  15 = While or after parsing the child element PZLX
   *  16 = While or after parsing the child element GS
   *  17 = While or after parsing the child element QY
   *  18 = While or after parsing the child element XLJPLX
   * 
   */
  private int __state;


  public boolean startElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler = getHandler();
    switch (__state) {
      case 0:
        return processCase0(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 1:
        return processCase1(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 2:
        return processCase2(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 3:
        return processCase3(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 4:
        return processCase4(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 5:
        return processCase5(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 6:
        return processCase6(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 7:
        return processCase7(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 8:
        return processCase8(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 9:
        return processCase9(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 10:
        return processCase10(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 11:
        return processCase11(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 12:
        return processCase12(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 13:
        return processCase13(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 14:
        return processCase14(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 15:
        return processCase15(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 16:
        return processCase16(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 17:
        return processCase17(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      case 18:
        return processCase18(unmarshallerHandler,pNamespaceURI,pLocalName, pQName, pAttr);
      default:
        throw new java.lang.IllegalStateException("Invalid state: " + __state);
    }
  }

  private boolean processCase0(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLBH".equals(pLocalName)) {
      __state = 1;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase1(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLMC".equals(pLocalName)) {
      __state = 2;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase2(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLJC".equals(pLocalName)) {
      __state = 3;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase3(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLLX".equals(pLocalName)) {
      __state = 4;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLTDLX".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLKTLX".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLSPLX".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SFHX".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase4(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLTDLX".equals(pLocalName)) {
      __state = 5;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLKTLX".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLSPLX".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SFHX".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase5(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLKTLX".equals(pLocalName)) {
      __state = 6;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLSPLX".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SFHX".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase6(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLSPLX".equals(pLocalName)) {
      __state = 7;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SFHX".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase7(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SFHX".equals(pLocalName)) {
      __state = 8;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase8(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "KTJG".equals(pLocalName)) {
      __state = 9;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "IC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SXSBSJ".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SXMBSJ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXSBSJ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXMBSJ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "PZLX".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase9(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "IC".equals(pLocalName)) {
      __state = 10;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SXSBSJ".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SXMBSJ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXSBSJ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXMBSJ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "PZLX".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase10(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SXSBSJ".equals(pLocalName)) {
      __state = 11;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SXMBSJ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXSBSJ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXMBSJ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "PZLX".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase11(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "SXMBSJ".equals(pLocalName)) {
      __state = 12;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXSBSJ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXMBSJ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "PZLX".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase12(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXSBSJ".equals(pLocalName)) {
      __state = 13;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXMBSJ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "PZLX".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase13(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XXMBSJ".equals(pLocalName)) {
      __state = 14;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "PZLX".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase14(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "PZLX".equals(pLocalName)) {
      __state = 15;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    } else if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase15(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "GS".equals(pLocalName)) {
      __state = 16;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase16(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "QY".equals(pLocalName)) {
      __state = 17;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase17(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    if ((pNamespaceURI == null  ||  pNamespaceURI.length() == 0)  &&  "XLJPLX".equals(pLocalName)) {
      __state = 18;
      unmarshallerHandler.addSimpleAtomicState();
      return true;
    }
    return false;
  }

  private boolean processCase18(org.apache.ws.jaxme.impl.JMUnmarshallerHandlerImpl unmarshallerHandler, java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, org.xml.sax.Attributes pAttr) throws org.xml.sax.SAXException {
    return false;
  }

  public void endElement(java.lang.String pNamespaceURI, java.lang.String pLocalName, java.lang.String pQName, java.lang.Object pResult) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.RecordType _1 = (zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.RecordType) result;
    switch (__state) {
      case 1:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLBH".equals(pLocalName)) {
          try {
            _1.setXLBH(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _2) {
            getHandler().parseConversionEvent("Failed to convert value of XLBH: " + pResult, _2);
          }
          return;
        }
        break;
      case 2:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLMC".equals(pLocalName)) {
          _1.setXLMC((java.lang.String) pResult);
          return;
        }
        break;
      case 3:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLJC".equals(pLocalName)) {
          _1.setXLJC((java.lang.String) pResult);
          return;
        }
        break;
      case 4:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLLX".equals(pLocalName)) {
          _1.setXLLX((java.lang.String) pResult);
          return;
        }
        break;
      case 5:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLTDLX".equals(pLocalName)) {
          try {
            _1.setXLTDLX(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _3) {
            getHandler().parseConversionEvent("Failed to convert value of XLTDLX: " + pResult, _3);
          }
          return;
        }
        break;
      case 6:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLKTLX".equals(pLocalName)) {
          try {
            _1.setXLKTLX(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _4) {
            getHandler().parseConversionEvent("Failed to convert value of XLKTLX: " + pResult, _4);
          }
          return;
        }
        break;
      case 7:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLSPLX".equals(pLocalName)) {
          try {
            _1.setXLSPLX(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _5) {
            getHandler().parseConversionEvent("Failed to convert value of XLSPLX: " + pResult, _5);
          }
          return;
        }
        break;
      case 8:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "SFHX".equals(pLocalName)) {
          try {
            _1.setSFHX(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _6) {
            getHandler().parseConversionEvent("Failed to convert value of SFHX: " + pResult, _6);
          }
          return;
        }
        break;
      case 9:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "KTJG".equals(pLocalName)) {
          _1.setKTJG((java.lang.String) pResult);
          return;
        }
        break;
      case 10:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "IC".equals(pLocalName)) {
          _1.setIC((java.lang.String) pResult);
          return;
        }
        break;
      case 11:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "SXSBSJ".equals(pLocalName)) {
          _1.setSXSBSJ((java.lang.String) pResult);
          return;
        }
        break;
      case 12:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "SXMBSJ".equals(pLocalName)) {
          _1.setSXMBSJ((java.lang.String) pResult);
          return;
        }
        break;
      case 13:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XXSBSJ".equals(pLocalName)) {
          _1.setXXSBSJ((java.lang.String) pResult);
          return;
        }
        break;
      case 14:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XXMBSJ".equals(pLocalName)) {
          _1.setXXMBSJ((java.lang.String) pResult);
          return;
        }
        break;
      case 15:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "PZLX".equals(pLocalName)) {
          try {
            _1.setPZLX(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _7) {
            getHandler().parseConversionEvent("Failed to convert value of PZLX: " + pResult, _7);
          }
          return;
        }
        break;
      case 16:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "GS".equals(pLocalName)) {
          try {
            _1.setGS(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _8) {
            getHandler().parseConversionEvent("Failed to convert value of GS: " + pResult, _8);
          }
          return;
        }
        break;
      case 17:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "QY".equals(pLocalName)) {
          try {
            _1.setQY(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _9) {
            getHandler().parseConversionEvent("Failed to convert value of QY: " + pResult, _9);
          }
          return;
        }
        break;
      case 18:
        if (pNamespaceURI == null  ||  pNamespaceURI.length() == 0  &&  "XLJPLX".equals(pLocalName)) {
          try {
            _1.setXLJPLX(getHandler().getDatatypeConverter().parseDecimal((java.lang.String) pResult));
          } catch (java.lang.Exception _10) {
            getHandler().parseConversionEvent("Failed to convert value of XLJPLX: " + pResult, _10);
          }
          return;
        }
        break;
      default:
        throw new java.lang.IllegalStateException("Illegal state: " + __state);
    }
  }

  public boolean isFinished() {
    switch (__state) {
      case 18:
      case 17:
        return true;
      default:
        return false;
    }
  }

}
