package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.sid.z_gj_xljbxx_iu;

import org.apache.ws.jaxme.generator.sg.DataObject;
import com.tongtech.ti.javaservice.ISSOOperation;
public class Z_gj_xljbxx_iu {
	private java.lang.String myServiceName = "";
	private com.tongtech.ti.esbcore.tongutil.InterfaceComponent ic = null;
	private Z_gj_xljbxx_iu_onZ_gj_xljbxx_iu z_gj_xljbxx_iu_onZ_gj_xljbxx_iu = new Z_gj_xljbxx_iu_onZ_gj_xljbxx_iu();
	

	public Z_gj_xljbxx_iu_onZ_gj_xljbxx_iu getZ_gj_xljbxx_iu_onZ_gj_xljbxx_iu(){
		return z_gj_xljbxx_iu_onZ_gj_xljbxx_iu;
	}
	public void setZ_gj_xljbxx_iu_onZ_gj_xljbxx_iu(Z_gj_xljbxx_iu_onZ_gj_xljbxx_iu z_gj_xljbxx_iu_onZ_gj_xljbxx_iu){
		this.z_gj_xljbxx_iu_onZ_gj_xljbxx_iu=z_gj_xljbxx_iu_onZ_gj_xljbxx_iu;
	}


/*METHODS BEGIN*/
	public Z_gj_xljbxx_iu(com.tongtech.ti.esbcore.tongutil.InterfaceComponent ic) {
		this.ic = ic;
		myServiceName = ic.getName() + com.tongtech.ti.esbcore.tongutil.Constants.SERVICENAME_ISONAME_SPLIT + "_fss91f_i1hdv1uc__p90_121594";
	}
/*METHODS END*/
public class Z_gj_xljbxx_iu_onZ_gj_xljbxx_iu extends ISSOOperation{
	private zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu input = null;
	private java.lang.String invokedOperationName = "onZ_gj_xljbxx_iu";
	

	public zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu getInput(){
		return input;
	}
	public void setInput(zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu input){
		this.input=input;
	}
	

	public java.lang.String getInvokedOperationName(){
		return invokedOperationName;
	}
	public void setInvokedOperationName(java.lang.String invokedOperationName){
		this.invokedOperationName=invokedOperationName;
	}


/*METHODS BEGIN*/
	public  void setInputMessage(DataObject input) {
		if(input instanceof zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu){
		setInput((zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu)input);
		}
		else{ 
		   throw  new java.lang.IllegalArgumentException("���������������ݶ��������Ӧ���ǣ�zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.DoZGjXljbxxIu������������������ǣ�"+input.getClass().getName());
		}
	}
	public  org.apache.ws.jaxme.generator.sg.DataObject getInputMessage() {
		 return getInput();
	}
	public  int invoke() throws com.tongtech.ti.esbcore.tongutil.TongESBException{
			com.tongtech.ti.esbcore.tongesb.ESBRequestImpl request = new com.tongtech.ti.esbcore.tongesb.ESBRequestImpl();
			request.setESBOperation(invokedOperationName);
			request.setProcessTraceInfo(ic.getProcessTraceInfo());
			request.setDBOperationType(ic.getDBOperationType());
			request.setAttributes(ic.getAttributes());
			request.setInputMessage(input);
			try{ 
			com.tongtech.ti.esbcore.tongesb.ESBReplyFault rtn = com.tongtech.ti.esbcore.tongesb.TongESB.esbHandleRequest(myServiceName,request);
			int result = rtn.getReplyCode();
			if (result != 0) {
				return result;
			} else {
			    return 0;
			}
			}catch(com.tongtech.ti.esbcore.tongutil.TongESBException e) {
				ic.alert("�������ʧ��", e);
				throw e;
			}
	}
	public  int invoke(String labelName) throws com.tongtech.ti.esbcore.tongutil.TongESBException{
			com.tongtech.ti.esbcore.tongesb.ESBRequestImpl request = new com.tongtech.ti.esbcore.tongesb.ESBRequestImpl();
			request.setESBOperation(invokedOperationName);
			request.setProcessTraceInfo(ic.getProcessTraceInfo());
			request.setDBOperationType(ic.getDBOperationType());
			request.setAttributes(ic.getAttributes());
			request.setInputMessage(input);
			try{ 
			com.tongtech.ti.esbcore.tongesb.ESBReplyFault rtn = com.tongtech.ti.esbcore.tongesb.TongESB.esbHandleRequest(myServiceName+com.tongtech.ti.esbcore.tongutil.Constants.SERVICENAME_LABELNAME_SPLIT+labelName,request);
			int result = rtn.getReplyCode();
			if (result != 0) {
				return result;
			} else {
			    return 0;
			}
			}catch(com.tongtech.ti.esbcore.tongutil.TongESBException e) {
				ic.alert("�������ʧ��", e);
				throw e;
			}
	}
/*METHODS END*/
}
}
