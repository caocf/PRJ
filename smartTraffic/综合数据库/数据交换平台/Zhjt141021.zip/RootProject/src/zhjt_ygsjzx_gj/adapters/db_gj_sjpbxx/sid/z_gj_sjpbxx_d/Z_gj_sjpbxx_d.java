package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.sid.z_gj_sjpbxx_d;

import org.apache.ws.jaxme.generator.sg.DataObject;
import com.tongtech.ti.javaservice.ISSOOperation;
public class Z_gj_sjpbxx_d {
	private java.lang.String myServiceName = "";
	private com.tongtech.ti.esbcore.tongutil.InterfaceComponent ic = null;
	private Z_gj_sjpbxx_d_onZ_gj_sjpbxx_d z_gj_sjpbxx_d_onZ_gj_sjpbxx_d = new Z_gj_sjpbxx_d_onZ_gj_sjpbxx_d();
	

	public Z_gj_sjpbxx_d_onZ_gj_sjpbxx_d getZ_gj_sjpbxx_d_onZ_gj_sjpbxx_d(){
		return z_gj_sjpbxx_d_onZ_gj_sjpbxx_d;
	}
	public void setZ_gj_sjpbxx_d_onZ_gj_sjpbxx_d(Z_gj_sjpbxx_d_onZ_gj_sjpbxx_d z_gj_sjpbxx_d_onZ_gj_sjpbxx_d){
		this.z_gj_sjpbxx_d_onZ_gj_sjpbxx_d=z_gj_sjpbxx_d_onZ_gj_sjpbxx_d;
	}


/*METHODS BEGIN*/
	public Z_gj_sjpbxx_d(com.tongtech.ti.esbcore.tongutil.InterfaceComponent ic) {
		this.ic = ic;
		myServiceName = ic.getName() + com.tongtech.ti.esbcore.tongutil.Constants.SERVICENAME_ISONAME_SPLIT + "_fss91f_i1hdv1uc__p71_121594";
	}
/*METHODS END*/
public class Z_gj_sjpbxx_d_onZ_gj_sjpbxx_d extends ISSOOperation{
	private zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD input = null;
	private java.lang.String invokedOperationName = "onZ_gj_sjpbxx_d";
	

	public zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD getInput(){
		return input;
	}
	public void setInput(zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD input){
		this.input=input;
	}
	

	public java.lang.String getInvokedOperationName(){
		return invokedOperationName;
	}
	public void setInvokedOperationName(java.lang.String invokedOperationName){
		this.invokedOperationName=invokedOperationName;
	}


/*METHODS BEGIN*/
	public  void setInputMessage(DataObject input) {
		if(input instanceof zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD){
		setInput((zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD)input);
		}
		else{ 
		   throw  new java.lang.IllegalArgumentException("���������������ݶ��������Ӧ���ǣ�zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD������������������ǣ�"+input.getClass().getName());
		}
	}
	public  org.apache.ws.jaxme.generator.sg.DataObject getInputMessage() {
		 return getInput();
	}
	public  int invoke() throws com.tongtech.ti.esbcore.tongutil.TongESBException{
			com.tongtech.ti.esbcore.tongesb.ESBRequestImpl request = new com.tongtech.ti.esbcore.tongesb.ESBRequestImpl();
			request.setESBOperation(invokedOperationName);
			request.setProcessTraceInfo(ic.getProcessTraceInfo());
			request.setDBOperationType(ic.getDBOperationType());
			request.setAttributes(ic.getAttributes());
			request.setInputMessage(input);
			try{ 
			com.tongtech.ti.esbcore.tongesb.ESBReplyFault rtn = com.tongtech.ti.esbcore.tongesb.TongESB.esbHandleRequest(myServiceName,request);
			int result = rtn.getReplyCode();
			if (result != 0) {
				return result;
			} else {
			    return 0;
			}
			}catch(com.tongtech.ti.esbcore.tongutil.TongESBException e) {
				ic.alert("�������ʧ��", e);
				throw e;
			}
	}
	public  int invoke(String labelName) throws com.tongtech.ti.esbcore.tongutil.TongESBException{
			com.tongtech.ti.esbcore.tongesb.ESBRequestImpl request = new com.tongtech.ti.esbcore.tongesb.ESBRequestImpl();
			request.setESBOperation(invokedOperationName);
			request.setProcessTraceInfo(ic.getProcessTraceInfo());
			request.setDBOperationType(ic.getDBOperationType());
			request.setAttributes(ic.getAttributes());
			request.setInputMessage(input);
			try{ 
			com.tongtech.ti.esbcore.tongesb.ESBReplyFault rtn = com.tongtech.ti.esbcore.tongesb.TongESB.esbHandleRequest(myServiceName+com.tongtech.ti.esbcore.tongutil.Constants.SERVICENAME_LABELNAME_SPLIT+labelName,request);
			int result = rtn.getReplyCode();
			if (result != 0) {
				return result;
			} else {
			    return 0;
			}
			}catch(com.tongtech.ti.esbcore.tongutil.TongESBException e) {
				ic.alert("�������ʧ��", e);
				throw e;
			}
	}
/*METHODS END*/
}
}
