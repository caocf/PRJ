package zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_iu;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getBH();

  public void setBH(java.math.BigDecimal pBH);

  public java.math.BigDecimal getZDBH();

  public void setZDBH(java.math.BigDecimal pZDBH);

  public java.math.BigDecimal getXLBH();

  public void setXLBH(java.math.BigDecimal pXLBH);

  public java.math.BigDecimal getZDCX();

  public void setZDCX(java.math.BigDecimal pZDCX);

  public java.math.BigDecimal getXLFX();

  public void setXLFX(java.math.BigDecimal pXLFX);

}
