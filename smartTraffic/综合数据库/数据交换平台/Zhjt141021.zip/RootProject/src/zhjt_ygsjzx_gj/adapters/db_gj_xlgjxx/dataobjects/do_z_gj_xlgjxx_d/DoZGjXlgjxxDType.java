package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d;

public interface DoZGjXlgjxxDType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d.Record[] getRecordAsArray();

  public zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d.Record[] valuesInArray);

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d.Record value);

}
