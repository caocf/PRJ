package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.RecordType {
  private java.math.BigDecimal _xLBH;

  private java.math.BigDecimal _fX;

  private java.math.BigDecimal _gJXH;

  private java.math.BigDecimal _qDJL;

  private java.lang.String _jD;

  private java.lang.String _wD;


  public java.math.BigDecimal getXLBH() {
    return _xLBH;
  }

  public void setXLBH(java.math.BigDecimal pXLBH) {
    _xLBH = pXLBH;
  }

  public java.math.BigDecimal getFX() {
    return _fX;
  }

  public void setFX(java.math.BigDecimal pFX) {
    _fX = pFX;
  }

  public java.math.BigDecimal getGJXH() {
    return _gJXH;
  }

  public void setGJXH(java.math.BigDecimal pGJXH) {
    _gJXH = pGJXH;
  }

  public java.math.BigDecimal getQDJL() {
    return _qDJL;
  }

  public void setQDJL(java.math.BigDecimal pQDJL) {
    _qDJL = pQDJL;
  }

  public java.lang.String getJD() {
    return _jD;
  }

  public void setJD(java.lang.String pJD) {
    _jD = pJD;
  }

  public java.lang.String getWD() {
    return _wD;
  }

  public void setWD(java.lang.String pWD) {
    _wD = pWD;
  }

}
