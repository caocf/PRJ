package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.RecordType _1 = (zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu.RecordType) pObject;
    java.math.BigDecimal _2 = _1.getXLBH();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "XLBH", pController.getDatatypeConverter().printDecimal(_1.getXLBH()));
    }
    java.lang.String _3 = _1.getXLMC();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "XLMC", _1.getXLMC());
    }
    java.lang.String _4 = _1.getXLJC();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "XLJC", _1.getXLJC());
    }
    java.lang.String _5 = _1.getXLLX();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "XLLX", _1.getXLLX());
    }
    java.math.BigDecimal _6 = _1.getXLTDLX();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "XLTDLX", pController.getDatatypeConverter().printDecimal(_1.getXLTDLX()));
    }
    java.math.BigDecimal _7 = _1.getXLKTLX();
    if (_7 != null) {
      pController.marshalSimpleChild(this, "", "XLKTLX", pController.getDatatypeConverter().printDecimal(_1.getXLKTLX()));
    }
    java.math.BigDecimal _8 = _1.getXLSPLX();
    if (_8 != null) {
      pController.marshalSimpleChild(this, "", "XLSPLX", pController.getDatatypeConverter().printDecimal(_1.getXLSPLX()));
    }
    java.math.BigDecimal _9 = _1.getSFHX();
    if (_9 != null) {
      pController.marshalSimpleChild(this, "", "SFHX", pController.getDatatypeConverter().printDecimal(_1.getSFHX()));
    }
    java.lang.String _10 = _1.getKTJG();
    if (_10 != null) {
      pController.marshalSimpleChild(this, "", "KTJG", _1.getKTJG());
    }
    java.lang.String _11 = _1.getIC();
    if (_11 != null) {
      pController.marshalSimpleChild(this, "", "IC", _1.getIC());
    }
    java.lang.String _12 = _1.getSXSBSJ();
    if (_12 != null) {
      pController.marshalSimpleChild(this, "", "SXSBSJ", _1.getSXSBSJ());
    }
    java.lang.String _13 = _1.getSXMBSJ();
    if (_13 != null) {
      pController.marshalSimpleChild(this, "", "SXMBSJ", _1.getSXMBSJ());
    }
    java.lang.String _14 = _1.getXXSBSJ();
    if (_14 != null) {
      pController.marshalSimpleChild(this, "", "XXSBSJ", _1.getXXSBSJ());
    }
    java.lang.String _15 = _1.getXXMBSJ();
    if (_15 != null) {
      pController.marshalSimpleChild(this, "", "XXMBSJ", _1.getXXMBSJ());
    }
    java.math.BigDecimal _16 = _1.getPZLX();
    if (_16 != null) {
      pController.marshalSimpleChild(this, "", "PZLX", pController.getDatatypeConverter().printDecimal(_1.getPZLX()));
    }
    java.math.BigDecimal _17 = _1.getGS();
    if (_17 != null) {
      pController.marshalSimpleChild(this, "", "GS", pController.getDatatypeConverter().printDecimal(_1.getGS()));
    }
    java.math.BigDecimal _18 = _1.getQY();
    if (_18 != null) {
      pController.marshalSimpleChild(this, "", "QY", pController.getDatatypeConverter().printDecimal(_1.getQY()));
    }
    java.math.BigDecimal _19 = _1.getXLJPLX();
    if (_19 != null) {
      pController.marshalSimpleChild(this, "", "XLJPLX", pController.getDatatypeConverter().printDecimal(_1.getXLJPLX()));
    }
  }

}
