package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d;

public interface DoZGjZdjbxxDType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.Record[] getRecordAsArray();

  public zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.Record[] valuesInArray);

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.Record value);

}
