package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getBH();

  public void setBH(java.math.BigDecimal pBH);

}
