package zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_iu.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_iu.RecordType {
  private java.math.BigDecimal _bH;

  private java.math.BigDecimal _zDBH;

  private java.math.BigDecimal _xLBH;

  private java.math.BigDecimal _zDCX;

  private java.math.BigDecimal _xLFX;


  public java.math.BigDecimal getBH() {
    return _bH;
  }

  public void setBH(java.math.BigDecimal pBH) {
    _bH = pBH;
  }

  public java.math.BigDecimal getZDBH() {
    return _zDBH;
  }

  public void setZDBH(java.math.BigDecimal pZDBH) {
    _zDBH = pZDBH;
  }

  public java.math.BigDecimal getXLBH() {
    return _xLBH;
  }

  public void setXLBH(java.math.BigDecimal pXLBH) {
    _xLBH = pXLBH;
  }

  public java.math.BigDecimal getZDCX() {
    return _zDCX;
  }

  public void setZDCX(java.math.BigDecimal pZDCX) {
    _zDCX = pZDCX;
  }

  public java.math.BigDecimal getXLFX() {
    return _xLFX;
  }

  public void setXLFX(java.math.BigDecimal pXLFX) {
    _xLFX = pXLFX;
  }

}
