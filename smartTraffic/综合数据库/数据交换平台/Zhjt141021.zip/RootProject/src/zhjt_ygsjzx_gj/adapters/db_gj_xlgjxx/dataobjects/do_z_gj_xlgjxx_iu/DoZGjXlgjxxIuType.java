package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu;

public interface DoZGjXlgjxxIuType extends java.io.Serializable {
  


  public java.util.List getRecord();

  public int getRecordCount();

  public zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.Record[] getRecordAsArray();

  public zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.Record getRecord(int index) throws java.lang.IndexOutOfBoundsException;

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.Record[] valuesInArray);

  public void setRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.Record value, int index) throws java.lang.IndexOutOfBoundsException;

  public void addRecord(zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu.Record value);

}
