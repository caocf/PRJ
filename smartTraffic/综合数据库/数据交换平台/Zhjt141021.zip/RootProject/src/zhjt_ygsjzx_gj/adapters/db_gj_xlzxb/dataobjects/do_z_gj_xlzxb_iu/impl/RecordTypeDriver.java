package zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_iu.impl;

public class RecordTypeDriver implements org.apache.ws.jaxme.impl.JMSAXDriver {
  public org.xml.sax.helpers.AttributesImpl getAttributes(org.apache.ws.jaxme.impl.JMSAXDriverController pController, java.lang.Object pObject) throws org.xml.sax.SAXException {
    org.xml.sax.helpers.AttributesImpl _1 = new org.xml.sax.helpers.AttributesImpl();
    return _1;
  }

  public java.lang.String getPreferredPrefix(java.lang.String pURI) {
    return null;
  }

  public void marshalChilds(org.apache.ws.jaxme.impl.JMSAXDriverController pController, org.xml.sax.ContentHandler pHandler, java.lang.Object pObject) throws org.xml.sax.SAXException {
    zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_iu.RecordType _1 = (zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_iu.RecordType) pObject;
    java.math.BigDecimal _2 = _1.getBH();
    if (_2 != null) {
      pController.marshalSimpleChild(this, "", "BH", pController.getDatatypeConverter().printDecimal(_1.getBH()));
    }
    java.math.BigDecimal _3 = _1.getZDBH();
    if (_3 != null) {
      pController.marshalSimpleChild(this, "", "ZDBH", pController.getDatatypeConverter().printDecimal(_1.getZDBH()));
    }
    java.math.BigDecimal _4 = _1.getXLBH();
    if (_4 != null) {
      pController.marshalSimpleChild(this, "", "XLBH", pController.getDatatypeConverter().printDecimal(_1.getXLBH()));
    }
    java.math.BigDecimal _5 = _1.getZDCX();
    if (_5 != null) {
      pController.marshalSimpleChild(this, "", "ZDCX", pController.getDatatypeConverter().printDecimal(_1.getZDCX()));
    }
    java.math.BigDecimal _6 = _1.getXLFX();
    if (_6 != null) {
      pController.marshalSimpleChild(this, "", "XLFX", pController.getDatatypeConverter().printDecimal(_1.getXLFX()));
    }
  }

}
