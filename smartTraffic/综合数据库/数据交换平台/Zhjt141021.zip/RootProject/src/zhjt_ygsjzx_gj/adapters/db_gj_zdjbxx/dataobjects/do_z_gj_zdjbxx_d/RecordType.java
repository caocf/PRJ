package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getZDBH();

  public void setZDBH(java.math.BigDecimal pZDBH);

}
