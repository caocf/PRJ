package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu;

public interface DoZGjZdjbxxIu extends javax.xml.bind.Element , zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.DoZGjZdjbxxIuType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject , org.apache.ws.jaxme.generator.sg.CalculateRecordCount {
}
