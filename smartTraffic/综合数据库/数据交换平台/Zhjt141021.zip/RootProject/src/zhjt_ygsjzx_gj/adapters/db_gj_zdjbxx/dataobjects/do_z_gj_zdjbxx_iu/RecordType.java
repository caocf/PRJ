package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getZDBH();

  public void setZDBH(java.math.BigDecimal pZDBH);

  public java.lang.String getZDMC();

  public void setZDMC(java.lang.String pZDMC);

  public java.lang.String getZDBM();

  public void setZDBM(java.lang.String pZDBM);

  public java.math.BigDecimal getZDLX();

  public void setZDLX(java.math.BigDecimal pZDLX);

  public java.lang.String getFWJ();

  public void setFWJ(java.lang.String pFWJ);

  public java.lang.String getZDEWM();

  public void setZDEWM(java.lang.String pZDEWM);

  public java.lang.String getBZ();

  public void setBZ(java.lang.String pBZ);

  public java.math.BigDecimal getGS();

  public void setGS(java.math.BigDecimal pGS);

  public java.math.BigDecimal getQY();

  public void setQY(java.math.BigDecimal pQY);

  public java.lang.String getGYZT();

  public void setGYZT(java.lang.String pGYZT);

  public java.lang.String getJD();

  public void setJD(java.lang.String pJD);

  public java.lang.String getWD();

  public void setWD(java.lang.String pWD);

}
