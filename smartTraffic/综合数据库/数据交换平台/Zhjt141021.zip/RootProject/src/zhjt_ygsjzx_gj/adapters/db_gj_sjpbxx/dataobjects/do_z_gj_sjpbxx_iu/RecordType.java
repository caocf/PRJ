package zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getBH();

  public void setBH(java.math.BigDecimal pBH);

  public java.lang.String getCPH();

  public void setCPH(java.lang.String pCPH);

  public java.math.BigDecimal getCPYS();

  public void setCPYS(java.math.BigDecimal pCPYS);

  public java.math.BigDecimal getXLBH();

  public void setXLBH(java.math.BigDecimal pXLBH);

  public java.math.BigDecimal getFX();

  public void setFX(java.math.BigDecimal pFX);

  public java.math.BigDecimal getRQ();

  public void setRQ(java.math.BigDecimal pRQ);

  public java.util.Calendar getFCSJ();

  public void setFCSJ(java.util.Calendar pFCSJ);

  public java.util.Calendar getDZSJ();

  public void setDZSJ(java.util.Calendar pDZSJ);

  public java.math.BigDecimal getJHBH();

  public void setJHBH(java.math.BigDecimal pJHBH);

}
