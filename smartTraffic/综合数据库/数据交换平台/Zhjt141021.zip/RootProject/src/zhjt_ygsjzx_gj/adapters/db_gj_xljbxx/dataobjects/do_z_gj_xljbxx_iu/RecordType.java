package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_iu;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getXLBH();

  public void setXLBH(java.math.BigDecimal pXLBH);

  public java.lang.String getXLMC();

  public void setXLMC(java.lang.String pXLMC);

  public java.lang.String getXLJC();

  public void setXLJC(java.lang.String pXLJC);

  public java.lang.String getXLLX();

  public void setXLLX(java.lang.String pXLLX);

  public java.math.BigDecimal getXLTDLX();

  public void setXLTDLX(java.math.BigDecimal pXLTDLX);

  public java.math.BigDecimal getXLKTLX();

  public void setXLKTLX(java.math.BigDecimal pXLKTLX);

  public java.math.BigDecimal getXLSPLX();

  public void setXLSPLX(java.math.BigDecimal pXLSPLX);

  public java.math.BigDecimal getSFHX();

  public void setSFHX(java.math.BigDecimal pSFHX);

  public java.lang.String getKTJG();

  public void setKTJG(java.lang.String pKTJG);

  public java.lang.String getIC();

  public void setIC(java.lang.String pIC);

  public java.lang.String getSXSBSJ();

  public void setSXSBSJ(java.lang.String pSXSBSJ);

  public java.lang.String getSXMBSJ();

  public void setSXMBSJ(java.lang.String pSXMBSJ);

  public java.lang.String getXXSBSJ();

  public void setXXSBSJ(java.lang.String pXXSBSJ);

  public java.lang.String getXXMBSJ();

  public void setXXMBSJ(java.lang.String pXXMBSJ);

  public java.math.BigDecimal getPZLX();

  public void setPZLX(java.math.BigDecimal pPZLX);

  public java.math.BigDecimal getGS();

  public void setGS(java.math.BigDecimal pGS);

  public java.math.BigDecimal getQY();

  public void setQY(java.math.BigDecimal pQY);

  public java.math.BigDecimal getXLJPLX();

  public void setXLJPLX(java.math.BigDecimal pXLJPLX);

}
