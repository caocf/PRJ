package zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_d.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_xljbxx.dataobjects.do_z_gj_xljbxx_d.RecordType {
  private java.math.BigDecimal _xLBH;


  public java.math.BigDecimal getXLBH() {
    return _xLBH;
  }

  public void setXLBH(java.math.BigDecimal pXLBH) {
    _xLBH = pXLBH;
  }

}
