package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_iu;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getXLBH();

  public void setXLBH(java.math.BigDecimal pXLBH);

  public java.math.BigDecimal getFX();

  public void setFX(java.math.BigDecimal pFX);

  public java.math.BigDecimal getGJXH();

  public void setGJXH(java.math.BigDecimal pGJXH);

  public java.math.BigDecimal getQDJL();

  public void setQDJL(java.math.BigDecimal pQDJL);

  public java.lang.String getJD();

  public void setJD(java.lang.String pJD);

  public java.lang.String getWD();

  public void setWD(java.lang.String pWD);

}
