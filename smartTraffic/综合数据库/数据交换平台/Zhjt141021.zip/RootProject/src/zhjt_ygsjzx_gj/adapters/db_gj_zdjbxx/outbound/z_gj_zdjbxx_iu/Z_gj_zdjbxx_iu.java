/*******************************************************************************
 * Copyright (c) 2008  TONGTECH CO., LTD.All Rights Reserved.
 *******************************************************************************/
package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.outbound.z_gj_zdjbxx_iu;

import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
import java.sql.Connection;
import javax.naming.NamingException;
import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterService;

import com.tongtech.ti.management.jms.AlertConstants;

/**
 * ���³�վ����������
 */
public class Z_gj_zdjbxx_iu extends JdbcAdapterService{

	/**
	 * ���캯��
	 * 
	 * @param ic,
	 */
	public Z_gj_zdjbxx_iu(InterfaceComponent ic) {
		super(ic);
	}
	
	/**
	 * ���³�վ�Ĳ�������
	 */	
	public int z_gj_zdjbxx(zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.DoZGjZdjbxxIu doZGjZdjbxxIu,default_project.adaptors.database.dataobjects.opresult.OPResultDO oPResultDO,default_project.adaptors.database.dataobjects.dbfault.DBFaultDO dBFaultDO) throws java.lang.Exception{
	
		zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.outbound.z_gj_zdjbxx_iu.Z_gj_zdjbxx_iuBase base = null;
		
		try {
		
			startProcessInfo("z_gj_zdjbxx", "update", "z_gj_zdjbxx", doZGjZdjbxxIu);
			
			base = new zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.outbound.z_gj_zdjbxx_iu.Z_gj_zdjbxx_iuBase(ic);
			base.init();
			base.connect();
			   base.setAutoCommit(false);
			boolean baseResult = base.z_gj_zdjbxx(doZGjZdjbxxIu);
			if (baseResult){
				base.commit();
				oPResultDO.setSuccess(true);
				
				endProcessInfo("z_gj_zdjbxx", "update", "z_gj_zdjbxx", 0, 0, true);
				return 0;//�ɹ�
			} else {
				int errorCode = base.getFaultCode();
				base.rollback();
				oPResultDO.setSuccess(false);
				dBFaultDO.setFaultMessage(base.getFaultMsg());
				
				//endProcessInfo("z_gj_zdjbxx", "update", "z_gj_zdjbxx", 0, 0, false);
				Exception exception = new Exception(base.getFaultMsg());
				errorProcessInfo("z_gj_zdjbxx", "update", "z_gj_zdjbxx", exception);
				
				return errorCode;//ʧ��
			}
		} catch (Exception e) {
			//alert
			ic.alert(AlertConstants.ALERT_TYPE_ADAPTER_DB, AlertConstants.ALERT_LEVEL_CRITICAL, "���³�վ����ʧ��",e);
			
			ic.getLogger().error(e.getMessage(),e);
			oPResultDO.setSuccess(false);
			dBFaultDO.setFaultMessage(e.toString());
			ic.getLogger().error(e.getMessage(),e);
			
			errorProcessInfo("z_gj_zdjbxx", "update", "z_gj_zdjbxx", e);
			
			return -1;//�쳣��ʧ�ܷ���-1
		} finally {
			try {
				base.closeConn();
			} catch (Exception e) {
				ic.getLogger().error(e.getMessage(),e);
			}
		}
	}
	
}
