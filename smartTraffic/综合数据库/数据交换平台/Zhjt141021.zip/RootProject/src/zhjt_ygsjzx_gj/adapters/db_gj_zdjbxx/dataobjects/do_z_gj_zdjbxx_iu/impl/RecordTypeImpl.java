package zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.impl;

public class RecordTypeImpl implements zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.RecordType {
  private java.math.BigDecimal _zDBH;

  private java.lang.String _zDMC;

  private java.lang.String _zDBM;

  private java.math.BigDecimal _zDLX;

  private java.lang.String _fWJ;

  private java.lang.String _zDEWM;

  private java.lang.String _bZ;

  private java.math.BigDecimal _gS;

  private java.math.BigDecimal _qY;

  private java.lang.String _gYZT;

  private java.lang.String _jD;

  private java.lang.String _wD;


  public java.math.BigDecimal getZDBH() {
    return _zDBH;
  }

  public void setZDBH(java.math.BigDecimal pZDBH) {
    _zDBH = pZDBH;
  }

  public java.lang.String getZDMC() {
    return _zDMC;
  }

  public void setZDMC(java.lang.String pZDMC) {
    _zDMC = pZDMC;
  }

  public java.lang.String getZDBM() {
    return _zDBM;
  }

  public void setZDBM(java.lang.String pZDBM) {
    _zDBM = pZDBM;
  }

  public java.math.BigDecimal getZDLX() {
    return _zDLX;
  }

  public void setZDLX(java.math.BigDecimal pZDLX) {
    _zDLX = pZDLX;
  }

  public java.lang.String getFWJ() {
    return _fWJ;
  }

  public void setFWJ(java.lang.String pFWJ) {
    _fWJ = pFWJ;
  }

  public java.lang.String getZDEWM() {
    return _zDEWM;
  }

  public void setZDEWM(java.lang.String pZDEWM) {
    _zDEWM = pZDEWM;
  }

  public java.lang.String getBZ() {
    return _bZ;
  }

  public void setBZ(java.lang.String pBZ) {
    _bZ = pBZ;
  }

  public java.math.BigDecimal getGS() {
    return _gS;
  }

  public void setGS(java.math.BigDecimal pGS) {
    _gS = pGS;
  }

  public java.math.BigDecimal getQY() {
    return _qY;
  }

  public void setQY(java.math.BigDecimal pQY) {
    _qY = pQY;
  }

  public java.lang.String getGYZT() {
    return _gYZT;
  }

  public void setGYZT(java.lang.String pGYZT) {
    _gYZT = pGYZT;
  }

  public java.lang.String getJD() {
    return _jD;
  }

  public void setJD(java.lang.String pJD) {
    _jD = pJD;
  }

  public java.lang.String getWD() {
    return _wD;
  }

  public void setWD(java.lang.String pWD) {
    _wD = pWD;
  }

}
