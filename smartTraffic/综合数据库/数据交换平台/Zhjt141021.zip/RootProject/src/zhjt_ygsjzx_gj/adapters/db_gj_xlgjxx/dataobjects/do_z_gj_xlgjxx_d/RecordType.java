package zhjt_ygsjzx_gj.adapters.db_gj_xlgjxx.dataobjects.do_z_gj_xlgjxx_d;

public interface RecordType extends java.io.Serializable {
  public java.math.BigDecimal getXLBH();

  public void setXLBH(java.math.BigDecimal pXLBH);

  public java.math.BigDecimal getFX();

  public void setFX(java.math.BigDecimal pFX);

  public java.math.BigDecimal getGJXH();

  public void setGJXH(java.math.BigDecimal pGJXH);

}
