package zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d;

public interface DoZGjXlzxbD extends javax.xml.bind.Element , zhjt_ygsjzx_gj.adapters.db_gj_xlzxb.dataobjects.do_z_gj_xlzxb_d.DoZGjXlzxbDType , org.apache.ws.jaxme.generator.sg.DataObject , org.apache.ws.jaxme.generator.sg.CalculateSize , org.apache.ws.jaxme.generator.sg.JMUnmarshalDataObject , org.apache.ws.jaxme.generator.sg.CalculateRecordCount {
}
