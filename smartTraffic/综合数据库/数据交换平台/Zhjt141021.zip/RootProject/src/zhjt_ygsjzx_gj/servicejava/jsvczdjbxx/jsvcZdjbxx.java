package zhjt_ygsjzx_gj.servicejava.jsvczdjbxx;

import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject;
import zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.DoZGjZdjbxxIu;
import zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.outbound.ao_z_gj_zdjbxx_iu.AOZ_gj_zdjbxx_iu;
import zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.DoZGjZdjbxxD;
import zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.outbound.ao_out_gj_zdjbxx_d.AOOut_gj_zdjbxx_d;
import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
public class jsvcZdjbxx extends BaseService{
	private InterfaceComponent ic = null;
	private String errorMsg = null;
	

	public String getErrorMsg(){
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg){
		this.errorMsg=errorMsg;
	}


	private static java.text.SimpleDateFormat dateFormater = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*METHODS BEGIN*/
	public jsvcZdjbxx(InterfaceComponent ic) {
		this.ic = ic;
	}
	public  int onZ_gj_zdjbxx_iu(DoZGjZdjbxxIu inDo,AOZ_gj_zdjbxx_iu aOZ_gj_zdjbxx_iu) {
				boolean result = true;
		boolean needRollback = false;
		com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject currentAO = null;
		zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_iu.DoZGjZdjbxxIu currentDO = null;
		java.util.List<JdbcAdapterObject> inTransAOs = new java.util.ArrayList<JdbcAdapterObject>();
		java.util.List<JdbcAdapterObject> connectionedAOs = new java.util.ArrayList<JdbcAdapterObject>();
		try {

			currentAO = aOZ_gj_zdjbxx_iu;
			currentAO.connectToDB();
			connectionedAOs.add(currentAO);
			currentAO.setAutoCommit(false);
			//ִ�����ݿ�AO����
			currentDO = inDo;
			result = currentAO.executeUpdate("z_gj_zdjbxx",currentDO);
			if (!inTransAOs.contains(currentAO)){
				inTransAOs.add(currentAO);
			}
			if (!result){
				needRollback = true;
				return currentAO.getFaultCode();
			}
			return 0;
		} catch (java.lang.Exception e){
			ic.getLogger().error("["+currentAO.getClass().getName()+"] execute error:" + e.toString());
			ic.alert("["+currentAO.getClass().getName()+"] execute error:",e);
			return -1;
		} finally {
			if (needRollback){
				//rollback all operation
				if (!inTransAOs.isEmpty()){
					//���������־
					ic.getLogger().error(currentAO.getFaultMsg());
					ic.alert("["+currentAO.getClass().getName()+"] execute error:" + currentAO.getFaultMsg(),null);
					//�ع�����
					for (JdbcAdapterObject ao : inTransAOs){
						try {
							ao.rollback();
						}catch(Exception e){
							ic.getLogger().error(e);
						}
					}
				}
			} else {
				//�ύ����
				for (JdbcAdapterObject ao : inTransAOs){
					try {
						ao.commit();
					} catch (Exception e){
						ic.getLogger().error(e);
					}
				}
			}
			//�ͷ�����
			for (JdbcAdapterObject ao : connectionedAOs){
				try {
					ao.closeConnection();
				}catch(Exception e){
					ic.getLogger().error(e);
				}
			}
		}//end try

	}
	public  int onZ_gj_zdjbxx_d(DoZGjZdjbxxD inDo,AOOut_gj_zdjbxx_d aOOut_gj_zdjbxx_d) {
				boolean result = true;
		boolean needRollback = false;
		com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject currentAO = null;
		zhjt_ygsjzx_gj.adapters.db_gj_zdjbxx.dataobjects.do_z_gj_zdjbxx_d.DoZGjZdjbxxD currentDO = null;
		java.util.List<JdbcAdapterObject> inTransAOs = new java.util.ArrayList<JdbcAdapterObject>();
		java.util.List<JdbcAdapterObject> connectionedAOs = new java.util.ArrayList<JdbcAdapterObject>();
		try {

			currentAO = aOOut_gj_zdjbxx_d;
			currentAO.connectToDB();
			connectionedAOs.add(currentAO);
			currentAO.setAutoCommit(false);
			//ִ�����ݿ�AO����
			currentDO = inDo;
			result = currentAO.executeDelete("z_gj_zdjbxx",currentDO);
			if (!inTransAOs.contains(currentAO)){
				inTransAOs.add(currentAO);
			}
			if (!result){
				needRollback = true;
				return currentAO.getFaultCode();
			}
			return 0;
		} catch (java.lang.Exception e){
			ic.getLogger().error("["+currentAO.getClass().getName()+"] execute error:" + e.toString());
			ic.alert("["+currentAO.getClass().getName()+"] execute error:",e);
			return -1;
		} finally {
			if (needRollback){
				//rollback all operation
				if (!inTransAOs.isEmpty()){
					//���������־
					ic.getLogger().error(currentAO.getFaultMsg());
					ic.alert("["+currentAO.getClass().getName()+"] execute error:" + currentAO.getFaultMsg(),null);
					//�ع�����
					for (JdbcAdapterObject ao : inTransAOs){
						try {
							ao.rollback();
						}catch(Exception e){
							ic.getLogger().error(e);
						}
					}
				}
			} else {
				//�ύ����
				for (JdbcAdapterObject ao : inTransAOs){
					try {
						ao.commit();
					} catch (Exception e){
						ic.getLogger().error(e);
					}
				}
			}
			//�ͷ�����
			for (JdbcAdapterObject ao : connectionedAOs){
				try {
					ao.closeConnection();
				}catch(Exception e){
					ic.getLogger().error(e);
				}
			}
		}//end try

	}
/*METHODS END*/
}
