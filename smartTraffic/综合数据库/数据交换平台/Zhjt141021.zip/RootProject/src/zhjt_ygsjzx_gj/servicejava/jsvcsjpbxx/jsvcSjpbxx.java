package zhjt_ygsjzx_gj.servicejava.jsvcsjpbxx;

import com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject;
import zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu.DoZGjSjpbxxIu;
import zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.outbound.ao_out_gj_sjpbxx_iu.AOOut_gj_sjpbxx_iu;
import zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD;
import zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.outbound.ao_out_gj_sjpbxx_d.AOOut_gj_sjpbxx_d;
import com.tongtech.ti.javaservice.BaseService;
import com.tongtech.ti.esbcore.tongutil.InterfaceComponent;
public class jsvcSjpbxx extends BaseService{
	private InterfaceComponent ic = null;
	private String errorMsg = null;
	

	public String getErrorMsg(){
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg){
		this.errorMsg=errorMsg;
	}


	private static java.text.SimpleDateFormat dateFormater = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*METHODS BEGIN*/
	public jsvcSjpbxx(InterfaceComponent ic) {
		this.ic = ic;
	}
	public  int onZ_gj_sjpbxx_iu(DoZGjSjpbxxIu inDo,AOOut_gj_sjpbxx_iu aOOut_gj_sjpbxx_iu) {
				boolean result = true;
		boolean needRollback = false;
		com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject currentAO = null;
		zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_iu.DoZGjSjpbxxIu currentDO = null;
		java.util.List<JdbcAdapterObject> inTransAOs = new java.util.ArrayList<JdbcAdapterObject>();
		java.util.List<JdbcAdapterObject> connectionedAOs = new java.util.ArrayList<JdbcAdapterObject>();
		try {

			currentAO = aOOut_gj_sjpbxx_iu;
			currentAO.connectToDB();
			connectionedAOs.add(currentAO);
			currentAO.setAutoCommit(false);
			//ִ�����ݿ�AO����
			currentDO = inDo;
			result = currentAO.executeUpdate("gj_sjpbxx",currentDO);
			if (!inTransAOs.contains(currentAO)){
				inTransAOs.add(currentAO);
			}
			if (!result){
				needRollback = true;
				return currentAO.getFaultCode();
			}
			return 0;
		} catch (java.lang.Exception e){
			ic.getLogger().error("["+currentAO.getClass().getName()+"] execute error:" + e.toString());
			ic.alert("["+currentAO.getClass().getName()+"] execute error:",e);
			return -1;
		} finally {
			if (needRollback){
				//rollback all operation
				if (!inTransAOs.isEmpty()){
					//���������־
					ic.getLogger().error(currentAO.getFaultMsg());
					ic.alert("["+currentAO.getClass().getName()+"] execute error:" + currentAO.getFaultMsg(),null);
					//�ع�����
					for (JdbcAdapterObject ao : inTransAOs){
						try {
							ao.rollback();
						}catch(Exception e){
							ic.getLogger().error(e);
						}
					}
				}
			} else {
				//�ύ����
				for (JdbcAdapterObject ao : inTransAOs){
					try {
						ao.commit();
					} catch (Exception e){
						ic.getLogger().error(e);
					}
				}
			}
			//�ͷ�����
			for (JdbcAdapterObject ao : connectionedAOs){
				try {
					ao.closeConnection();
				}catch(Exception e){
					ic.getLogger().error(e);
				}
			}
		}//end try

	}
	public  int onZ_gj_sjpbxx_d(DoZGjSjpbxxD inDo,AOOut_gj_sjpbxx_d aOOut_gj_sjpbxx_d) {
				boolean result = true;
		boolean needRollback = false;
		com.tongtech.ti.adapter.jdbc.common.JdbcAdapterObject currentAO = null;
		zhjt_ygsjzx_gj.adapters.db_gj_sjpbxx.dataobjects.do_z_gj_sjpbxx_d.DoZGjSjpbxxD currentDO = null;
		java.util.List<JdbcAdapterObject> inTransAOs = new java.util.ArrayList<JdbcAdapterObject>();
		java.util.List<JdbcAdapterObject> connectionedAOs = new java.util.ArrayList<JdbcAdapterObject>();
		try {

			currentAO = aOOut_gj_sjpbxx_d;
			currentAO.connectToDB();
			connectionedAOs.add(currentAO);
			currentAO.setAutoCommit(false);
			//ִ�����ݿ�AO����
			currentDO = inDo;
			result = currentAO.executeDelete("gj_sjpbxx",currentDO);
			if (!inTransAOs.contains(currentAO)){
				inTransAOs.add(currentAO);
			}
			if (!result){
				needRollback = true;
				return currentAO.getFaultCode();
			}
			return 0;
		} catch (java.lang.Exception e){
			ic.getLogger().error("["+currentAO.getClass().getName()+"] execute error:" + e.toString());
			ic.alert("["+currentAO.getClass().getName()+"] execute error:",e);
			return -1;
		} finally {
			if (needRollback){
				//rollback all operation
				if (!inTransAOs.isEmpty()){
					//���������־
					ic.getLogger().error(currentAO.getFaultMsg());
					ic.alert("["+currentAO.getClass().getName()+"] execute error:" + currentAO.getFaultMsg(),null);
					//�ع�����
					for (JdbcAdapterObject ao : inTransAOs){
						try {
							ao.rollback();
						}catch(Exception e){
							ic.getLogger().error(e);
						}
					}
				}
			} else {
				//�ύ����
				for (JdbcAdapterObject ao : inTransAOs){
					try {
						ao.commit();
					} catch (Exception e){
						ic.getLogger().error(e);
					}
				}
			}
			//�ͷ�����
			for (JdbcAdapterObject ao : connectionedAOs){
				try {
					ao.closeConnection();
				}catch(Exception e){
					ic.getLogger().error(e);
				}
			}
		}//end try

	}
/*METHODS END*/
}
